import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav style={{ padding: '10px 20px', background: '#333', color: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <h2 style={{color:'white'}}>SceneApp</h2>
      <div style={{ display: 'flex', gap: '15px' }}>
        <Link to="/" style={{ color: '#fff', textDecoration: 'none' }}>Események</Link>
        {user ? (
          <>
            <Link to="/profile" style={{ color: '#fff', textDecoration: 'none' }}>Profil ({user.name || 'Felhasználó'})</Link>
            <button onClick={logout} style={{ background: '#ff4d4d', color: '#fff', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>Kijelentkezés</button>
          </>
        ) : (
          <Link to="/login" style={{ color: '#fff', textDecoration: 'none' }}>Bejelentkezés</Link>
        )}
      </div>
    </nav>
  );
}