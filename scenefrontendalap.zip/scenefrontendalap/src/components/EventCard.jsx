import { Link } from 'react-router-dom';

export default function EventCard({ event }) {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString('hu-HU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div style={{ 
      border: '1px solid #ddd', 
      borderRadius: '8px', 
      overflow: 'hidden', 
      display: 'flex', 
      background: '#fff',
      boxShadow: '0 2px 5px rgba(0,0,0,0.05)'
    }}>
      {event.CoverImageUrl && (
        <img 
          src={event.CoverImageUrl} 
          alt={event.Name} 
          style={{ width: '200px', objectFit: 'cover' }} 
        />
      )}
      <div style={{ padding: '15px', flex: 1 }}>
        <span style={{ fontSize: '12px', background: '#e0f0ff', color: '#0066cc', padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold' }}>
          {event.Category}
        </span>
        <h3 style={{ margin: '10px 0 5px 0' }}>{event.Name}</h3>
        <p style={{ color: '#555', fontSize: '14px', margin: '5px 0' }}>{event.Description}</p>
        <p style={{ fontSize: '13px', color: '#777', margin: '5px 0' }}>
          📍 {event.Location} | 📅 {formatDate(event.StartDate)}
        </p>
        <Link 
          to={`/events/${event.EventId}`} 
          style={{ display: 'inline-block', marginTop: '10px', color: '#007bff', fontWeight: 'bold', textDecoration: 'none' }}
        >
          Részletek megtekintése →
        </Link>
      </div>
    </div>
  );
}