import { useAuth } from '../context/AuthContext';

export default function ProfilePage() {
  const { user } = useAuth();

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '20px auto', border: '1px solid #ddd', borderRadius: '8px', background: '#fff' }}>
      <h1>Profilom</h1>
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '20px' }}>
        <img 
          src={user?.AvatarImageUrl || 'https://via.placeholder.com/100'} 
          alt="Avatar" 
          style={{ width: '100px', height: '100px', borderRadius: '50%', objectFit: 'cover' }}
        />
        <div>
          <h2>{user?.DisplayName || user?.Username}</h2>
          <p style={{ color: '#666', margin: 0 }}>{user?.Email}</p>
          <span style={{ fontSize: '12px', background: '#eee', padding: '2px 6px', borderRadius: '4px' }}>
            Szerepkör: {user?.Role}
          </span>
        </div>
      </div>

      <div style={{ background: '#f8f9fa', padding: '15px', borderRadius: '6px', marginBottom: '15px' }}>
        <h3>Avatar Szint & XP</h3>
        <p><strong>Szint (AvatarLevel):</strong> {user?.AvatarLevel || 1}</p>
        <p><strong>Jelenlegi XP (CurrentXP):</strong> {user?.CurrentXP || 0} XP</p>
      </div>

      <div>
        <h3>Bio</h3>
        <p>{user?.Bio || 'Még nincs megadva bemutatkozás.'}</p>
      </div>
    </div>
  );
}