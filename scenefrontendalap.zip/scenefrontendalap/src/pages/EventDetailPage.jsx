import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const MOCK_EVENTS_DETAIL = {
  "1": {
    EventId: 1,
    Name: 'Nyári Fesztivál & Rock Est',
    Description: 'Hatalmas szabadtéri koncert a legnépszerűbb hazai előadókkal és ételstandokkal! Gyere el és bulizz velünk egész este.',
    Location: 'Budapest, Margitszigeti Szabadtéri Színpad',
    StartDate: '2026-07-15T18:00:00',
    EndDate: '2026-07-15T23:00:00',
    Category: 'Koncert',
    CoverImageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800',
    Performances: [
      { PerformanceId: 101, StageName: 'Nagyszínpad', ArtistName: 'Kovács Péter', Genre: 'Musician', StartTime: '19:00', EndTime: '20:30' },
      { PerformanceId: 102, StageName: 'Nagyszínpad', ArtistName: 'RockBand Reborn', Genre: 'Musician', StartTime: '21:00', EndTime: '23:00' }
    ]
  },
  "2": {
    EventId: 2,
    Name: 'Zöld Város Jótékonysági Gyűjtés',
    Description: 'Csatlakozz a faültetési akciónkhoz és segíts szebbé tenni a parkjainkat!',
    Location: 'Debrecen, Nagyerdő',
    StartDate: '2026-08-02T10:00:00',
    EndDate: '2026-08-02T16:00:00',
    Category: 'Jótékonyság',
    CoverImageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800',
    Performances: [
      { PerformanceId: 201, StageName: 'Közösségi Sátor', ArtistName: 'Tiszta Jövő Alapítvány', Genre: 'Organization', StartTime: '11:00', EndTime: '12:00' }
    ]
  },
  "3": {
    EventId: 3,
    Name: 'SceneApp Rendszergazda Találkozó',
    Description: 'Hivatalos platform-találkozó az adminisztrátorok és fejlesztők számára.',
    Location: 'Online / Zoom link',
    StartDate: '2026-09-10T16:00:00',
    EndDate: '2026-09-10T18:00:00',
    Category: 'Közösség',
    CoverImageUrl: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=800',
    Performances: []
  }
};

export default function EventDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  
  const eventData = MOCK_EVENTS_DETAIL[id];

  const [bookingStatus, setBookingStatus] = useState(null); // 'Going' | 'Interested' | 'Cancelled'
  const [photoUrl, setPhotoUrl] = useState('');

  const handleBooking = (newStatus) => {
    setBookingStatus(newStatus);
    alert(`Foglalás állapota frissítve: ${newStatus}`);
  };

  const handlePhotoUpload = (e) => {
    e.preventDefault();
    alert('Kép sikeresen beküldve! Státusz: Pending (Admin jóváhagyásra vár az XP-ért).');
    setPhotoUrl('');
  };

  if (!eventData) {
    return (
      <div style={{ padding: '40px', textAlign: 'center' }}>
        <h2>A keresett esemény nem található!</h2>
        <Link to="/">Vissza az eseményekhez</Link>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <Link to="/" style={{ textDecoration: 'none', color: '#007bff' }}>← Vissza az eseményekhez</Link>
      
      {eventData.CoverImageUrl && (
        <img 
          src={eventData.CoverImageUrl} 
          alt={eventData.Name} 
          style={{ width: '100%', height: '250px', objectFit: 'cover', borderRadius: '8px', marginTop: '15px' }} 
        />
      )}

      <h1 style={{ marginTop: '15px', marginBottom: '5px' }}>{eventData.Name}</h1>
      <p style={{ color: '#666', fontWeight: 'bold' }}>
        📍 {eventData.Location} | 📅 {new Date(eventData.StartDate).toLocaleString('hu-HU')}
      </p>
      <p style={{ fontSize: '16px', lineHeight: '1.6' }}>{eventData.Description}</p>
      
      {/* Bookings (Foglalások / Részvétel) */}
      {user ? (
        <div style={{ margin: '20px 0', padding: '15px', background: '#eef6ff', borderRadius: '8px' }}>
          <h3 style={{ margin: '0 0 10px 0' }}>Részvételi szándék (Bookings):</h3>
          <button 
            onClick={() => handleBooking('Going')} 
            style={{ 
              marginRight: '10px', 
              padding: '8px 15px', 
              background: bookingStatus === 'Going' ? '#28a745' : '#007bff', 
              color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' 
            }}
          >
            {bookingStatus === 'Going' ? '✓ Ott leszek! (Going)' : 'Itt leszek (Going)'}
          </button>
          <button 
            onClick={() => handleBooking('Interested')}
            style={{ 
              padding: '8px 15px', 
              background: bookingStatus === 'Interested' ? '#ffc107' : '#6c757d', 
              color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' 
            }}
          >
            {bookingStatus === 'Interested' ? '✓ Érdekel (Interested)' : 'Érdekel (Interested)'}
          </button>
        </div>
      ) : (
        <p style={{ color: '#d9534f', fontStyle: 'italic' }}>A részvétel jelöléséhez be kell jelentkezned!</p>
      )}

      {/* Performances (Fellépők) */}
      <h2>Fellépők és Programok (Performances)</h2>
      {eventData.Performances.length === 0 ? (
        <p style={{ color: '#777' }}>Nincsenek rögzített fellépők ehhez az eseményhez.</p>
      ) : (
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {eventData.Performances.map((p) => (
            <li key={p.PerformanceId} style={{ padding: '10px', borderBottom: '1px solid #eee' }}>
              <strong>{p.StageName}</strong>: {p.ArtistName} ({p.Genre}) — <small>{p.StartTime} - {p.EndTime}</small>
            </li>
          ))}
        </ul>
      )}

      {/* EventPhotos (Fotó feltöltés XP-ért) */}
      {user && (
        <div style={{ marginTop: '30px', padding: '20px', background: '#f9f9f9', borderRadius: '8px', border: '1px solid #ddd' }}>
          <h3 style={{ margin: '0 0 10px 0' }}>📸 Tölts fel egy fotót az eseményről (+XP)!</h3>
          <p style={{ fontSize: '13px', color: '#666' }}>A kép jóváhagyása után (Approved) jóváírjuk az XP-t a profilodon.</p>
          <form onSubmit={handlePhotoUpload} style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
            <input 
              type="url" 
              placeholder="Kép URL címe (ImageUrl)..." 
              value={photoUrl} 
              onChange={(e) => setPhotoUrl(e.target.value)} 
              required 
              style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}
            />
            <button type="submit" style={{ padding: '8px 15px', background: '#28a745', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>
              Feltöltés
            </button>
          </form>
        </div>
      )}
    </div>
  );
}