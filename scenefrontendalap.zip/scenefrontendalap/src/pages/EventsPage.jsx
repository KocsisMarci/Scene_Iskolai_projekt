import EventCard from '../components/EventCard';

const DUMMY_EVENTS = [
  {
    EventId: 1,
    Name: 'Nyári Fesztivál & Rock Est',
    Description: 'Hatalmas szabadtéri koncert a legnépszerűbb hazai előadókkal és ételstandokkal!',
    Location: 'Budapest, Margitszigeti Szabadtéri Színpad',
    StartDate: '2026-07-15T18:00:00',
    EndDate: '2026-07-15T23:00:00',
    Category: 'Koncert',
    CoverImageUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=500',
    Status: 'Published'
  },
  {
    EventId: 2,
    Name: 'Zöld Város Jótékonysági Gyűjtés',
    Description: 'Csatlakozz a faültetési akciónkhoz és segíts szebbé tenni a parkjainkat!',
    Location: 'Debrecen, Nagyerdő',
    StartDate: '2026-08-02T10:00:00',
    EndDate: '2026-08-02T16:00:00',
    Category: 'Jótékonyság',
    CoverImageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=500',
    Status: 'Published'
  },
  {
    EventId: 3,
    Name: 'SceneApp Rendszergazda Találkozó',
    Description: 'Hivatalos platform-találkozó az adminisztrátorok és fejlesztők számára.',
    Location: 'Online / Zoom link',
    StartDate: '2026-09-10T16:00:00',
    EndDate: '2026-09-10T18:00:00',
    Category: 'Közösség',
    CoverImageUrl: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=500',
    Status: 'Published'
  }
];

export default function EventsPage() {
  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px' }}>Események</h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
        {DUMMY_EVENTS.map((event) => (
          <EventCard key={event.EventId} event={event} />
        ))}
      </div>
    </div>
  );
}