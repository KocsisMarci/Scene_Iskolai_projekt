import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Beégetett tesztfiókok
const MOCK_USERS = [
  { name: 'Nagy Anna', email: 'anna@szena.hu', role: 'Participant', title: 'Sima Résztvevő' },
  { name: 'Kovács Péter', email: 'peter@music.hu', role: 'Performer', title: 'Énekes / Előadó' },
  { name: 'Tiszta Jövő Alapítvány', email: 'info@tisztojovo.hu', role: 'NGO', title: 'Civil Szervezet' },
  { name: 'Scene Admin', email: 'admin@scene.hu', role: 'Admin', title: 'Rendszergazda (Admin)' },
];

export default function LoginPage() {
  const [selectedEmail, setSelectedEmail] = useState(MOCK_USERS[0].email);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (userToLogin) => {
    // Elmentjük a szimulált usert a contextbe és localStorage-ba
    login({
      name: userToLogin.name,
      email: userToLogin.email,
      role: userToLogin.role,
      token: 'mock-jwt-token-12345'
    });
    navigate('/profile');
  };

  return (
    <div style={{ padding: '30px', maxWidth: '450px', margin: '40px auto', border: '1px solid #ddd', borderRadius: '8px', background: '#fff' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px', color:"black" }}>Teszt Bejelentkezés</h2>
      <p style={{ fontSize: '14px', color: '#666', marginBottom: '20px' }}>
        Válassz egy beégetett tesztfiókot a felület kipróbálásához:
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {MOCK_USERS.map((u) => (
          <button
            key={u.email}
            onClick={() => handleLogin(u)}
            style={{
              padding: '12px',
              border: '1px solid #007bff',
              borderRadius: '5px',
              background: '#f0f7ff',
              cursor: 'pointer',
              textAlign: 'left',
              color:"black"
            }}
          >
            <strong>{u.title}</strong>
            <div style={{ fontSize: '12px', color: '#555' }}>{u.name} ({u.email})</div>
          </button>
        ))}
      </div>
    </div>
  );
}