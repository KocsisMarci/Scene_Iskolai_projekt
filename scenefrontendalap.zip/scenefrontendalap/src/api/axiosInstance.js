import axios from 'axios';

const api = axios.create({
  baseURL: 'https://localhost:7000/api', // vagy a backended pontos címe
  headers: {
    'Content-Type': 'application/json',
  },
});

// A kérések elé automatikusan betesszük a tokent, ha létezik
api.interceptors.request.use(
  (config) => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user && user.token) {
      config.headers.Authorization = `Bearer ${user.token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;