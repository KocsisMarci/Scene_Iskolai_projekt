import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const [language, setLanguage] = useState('HU');

  return (
    <nav style={{
      width: '100vw',
      position: 'relative',
      left: '50%',
      right: '50%',
      marginLeft: '-50vw',
      marginRight: '-50vw',
      boxSizing: 'border-box',
      top: 0,
      zIndex: 1000,
      background: 'rgba(15, 13, 24, 0.9)',
      backdropFilter: 'blur(12px)',
      borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
      padding: '18px 48px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }}>
      {/* Márkajelzés neon színátmenettel - Visszavisz a Kezdőlapra */}
      <Link to="/" style={{
        fontSize: '24px',
        fontWeight: 900,
        letterSpacing: '1px',
        textTransform: 'uppercase',
        background: 'linear-gradient(90deg, #ff007f, #0284c7)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
        textDecoration: 'none'
      }}>
        SCENE
      </Link>

      {/* Navigációs linkek, nyelvválasztó és gombok */}
      <div style={{ display: 'flex', gap: '28px', alignItems: 'center', fontWeight: 700, fontSize: '14px', textTransform: 'uppercase', letterSpacing: '1px' }}>
        <Link to="/" style={{ color: '#fff', textDecoration: 'none', transition: '0.2s' }}>
          Kezdőlap
        </Link>
        <Link to="/events" style={{ color: '#fff', textDecoration: 'none', transition: '0.2s' }}>
          Programok
        </Link>

        {/* Nyelvválasztó kapcsoló (HU / EN) */}
        <button
          onClick={() => setLanguage(language === 'HU' ? 'EN' : 'HU')}
          style={{
            background: 'transparent',
            color: '#b3acc7',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            padding: '6px 14px',
            borderRadius: '20px',
            fontSize: '11px',
            fontWeight: 800,
            cursor: 'pointer',
            letterSpacing: '1px',
            transition: '0.2s'
          }}
        >
          🌐 {language}
        </button>

        {user ? (
          <>
            <Link to="/profile" style={{ color: '#b3acc7', textDecoration: 'none' }}>
              Profil ({user.name || 'Felhasználó'})
            </Link>
            <button 
              onClick={logout} 
              style={{ 
                background: 'transparent', 
                color: '#ff007f', 
                border: '2px solid #ff007f', 
                padding: '8px 20px', 
                borderRadius: '50px', 
                cursor: 'pointer',
                fontWeight: 800,
                fontSize: '12px',
                textTransform: 'uppercase',
                letterSpacing: '1px',
                transition: '0.2s'
              }}
              onMouseEnter={e => {
                e.currentTarget.style.background = '#ff007f';
                e.currentTarget.style.color = '#fff';
                e.currentTarget.style.boxShadow = '0 0 15px rgba(255, 0, 127, 0.5)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#ff007f';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              Kijelentkezés
            </button>
          </>
        ) : (
          <Link to="/login" style={{
            background: '#ffe600',
            color: '#090612',
            padding: '10px 24px',
            borderRadius: '50px',
            fontWeight: 900,
            fontSize: '12px',
            textDecoration: 'none',
            boxShadow: '0 0 15px rgba(255, 230, 0, 0.4)',
            transition: '0.2s'
          }}
          onMouseEnter={e => {
            e.currentTarget.style.boxShadow = '0 0 25px rgba(255, 230, 0, 0.7)';
            e.currentTarget.style.transform = 'translateY(-1px)';
          }}
          onMouseLeave={e => {
            e.currentTarget.style.boxShadow = '0 0 15px rgba(255, 230, 0, 0.4)';
            e.currentTarget.style.transform = 'translateY(0)';
          }}
          >
            Bejelentkezés / Regisztráció
          </Link>
        )}
      </div>
    </nav>
  );
}