import { Link } from 'react-router-dom';

export default function EventCard({ event }) {
  const name = event.Name || event.name;
  const description = event.Description || event.description;
  const location = event.Location || event.location;
  const startDate = event.StartDate || event.startDate;
  const category = event.Category || event.category;
  const eventId = event.EventId || event.eventId;

  const findImageUrl = (obj) => {
    if (!obj) return null;
    const matchingKey = Object.keys(obj).find(k => {
      const val = obj[k];
      return typeof val === 'string' && val.startsWith('http');
    });
    return matchingKey ? obj[matchingKey] : null;
  };

  let coverImage = findImageUrl(event);

  if (!coverImage) {
    const catLower = (category || '').toLowerCase();
    if (catLower.includes('koncert')) {
      coverImage = 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80';
    } else if (catLower.includes('kiállítás')) {
      coverImage = 'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?auto=format&fit=crop&w=800&q=80';
    } else {
      coverImage = 'https://images.unsplash.com/photo-1585699324551-f6c309eedf7b?auto=format&fit=crop&w=800&q=80';
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Hamarosan';
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? 'Érvénytelen dátum' : date.toLocaleString('hu-HU', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).toUpperCase();
  };

  return (
    <div style={{ 
      background: '#151026',
      borderRadius: '16px', 
      overflow: 'hidden', 
      display: 'flex', 
      flexDirection: 'column', 
      border: '1px solid rgba(255, 255, 255, 0.08)',
      boxShadow: '0 10px 30px rgba(0,0,0,0.4)',
      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
      textAlign: 'left'
    }}
    onMouseEnter={e => {
      e.currentTarget.style.transform = 'translateY(-6px)';
      e.currentTarget.style.boxShadow = '0 15px 35px rgba(255, 0, 127, 0.25)';
    }}
    onMouseLeave={e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = '0 10px 30px rgba(0,0,0,0.4)';
    }}>
      
      <div style={{ position: 'relative', height: '200px', overflow: 'hidden' }}>
        <img 
          src={coverImage} 
          alt={name || 'Esemény kép'} 
          style={{ width: '100%', height: '100%', objectFit: 'cover' }} 
        />
        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(to top, #151026 5%, transparent 60%)'
        }} />
        {category && (
          <span style={{ 
            position: 'absolute',
            top: '12px',
            left: '12px',
            fontSize: '11px', 
            background: '#ffe600', 
            color: '#090612', 
            padding: '4px 12px', 
            borderRadius: '50px', 
            fontWeight: 900,
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}>
            {category}
          </span>
        )}
      </div>

      <div style={{ padding: '20px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          {/* Sötétebb, finomabb kék árnyalat a dátumnak és helyszínnek */}
          <div style={{ color: '#0284c7', fontSize: '12px', fontWeight: 800, letterSpacing: '1px', marginBottom: '6px' }}>
            📅 {formatDate(startDate)} • 📍 {location || 'Főszínpad'}
          </div>
          <h3 style={{ margin: '0 0 10px 0', fontSize: '20px', fontWeight: 900, color: '#fff', textTransform: 'uppercase', lineHeight: '1.2' }}>
            {name}
          </h3>
          <p style={{ color: '#b3acc7', fontSize: '14px', lineHeight: '1.5', margin: '0 0 20px 0' }}>
            {description}
          </p>
        </div>

        {eventId && (
          <Link 
            to={`/events/${eventId}`} 
            style={{ 
              display: 'block', 
              textAlign: 'center',
              background: 'transparent',
              border: '2px solid #ff007f',
              color: '#fff', 
              padding: '10px 16px',
              borderRadius: '50px', 
              fontWeight: 800, 
              textDecoration: 'none', 
              fontSize: '12px',
              textTransform: 'uppercase',
              letterSpacing: '1px',
              transition: '0.2s'
            }}
            onMouseEnter={e => {
              e.currentTarget.style.background = '#ff007f';
            }}
            onMouseLeave={e => {
              e.currentTarget.style.background = 'transparent';
            }}
          >
            Részletek & Jegyek →
          </Link>
        )}
      </div>
    </div>
  );
}