import React, { useState, useEffect } from 'react';
import EventCard from '../components/EventCard';
import axiosInstance from '../api/axiosInstance';

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('Összes');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await axiosInstance.get('/Event');
        setEvents(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Hiba az adatok lekérésekor:', err);
        setError('Nem sikerült betölteni az eseményeket a szerverről.');
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '80px', color: '#0284c7', fontSize: '18px', fontWeight: 800 }}>Események betöltése...</div>;
  }

  if (error) {
    return <div style={{ textAlign: 'center', padding: '80px', color: '#ff007f', fontSize: '18px', fontWeight: 800 }}>{error}</div>;
  }

  const categories = ['Összes', ...new Set(events.map(e => e.Category || e.category).filter(Boolean))];

  const filteredEvents = selectedCategory === 'Összes'
    ? events
    : events.filter(e => (e.Category || e.category) === selectedCategory);

  return (
    <div>
      {/* Látványos Fesztivál Hero Szekció */}
      <div style={{
        position: 'relative',
        padding: '70px 20px',
        textAlign: 'center',
        background: 'linear-gradient(180deg, rgba(255,0,127,0.15) 0%, rgba(9,6,18,0) 100%)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
        marginBottom: '40px'
      }}>
        <span style={{
          background: '#0284c7',
          color: '#ffffff',
          padding: '6px 16px',
          borderRadius: '50px',
          fontSize: '11px',
          fontWeight: 900,
          letterSpacing: '2px',
          textTransform: 'uppercase'
        }}>
          2026 • A ZENE ÉS KULTÚRA SZIGETE
        </span>
        <h1 style={{
          fontSize: 'clamp(36px, 5vw, 64px)',
          fontWeight: 900,
          textTransform: 'uppercase',
          margin: '20px auto 15px auto',
          maxWidth: '850px',
          lineHeight: '1.1',
          letterSpacing: '-1px',
          color: '#ffffff'
        }}>
          Fedezd fel a <span style={{ color: '#ff007f' }}>legjobb</span> programokat
        </h1>
        <p style={{ color: '#b3acc7', maxWidth: '600px', margin: '0 auto', fontSize: '15px', lineHeight: '1.6' }}>
          Koncertek, kiállítások és felejthetetlen élmények egy helyen. Válaszd ki a kedvenced!
        </p>
      </div>

      <div style={{ padding: '0 20px 60px 20px', maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '12px', marginBottom: '40px' }}>
          {categories.map(cat => {
            const active = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  background: active ? '#ff007f' : '#151026',
                  color: active ? '#fff' : '#b3acc7',
                  border: active ? '1px solid #ff007f' : '1px solid rgba(255,255,255,0.12)',
                  padding: '10px 22px',
                  borderRadius: '50px',
                  fontWeight: 800,
                  fontSize: '12px',
                  textTransform: 'uppercase',
                  letterSpacing: '1px',
                  cursor: 'pointer',
                  boxShadow: active ? '0 0 15px rgba(255, 0, 127, 0.5)' : 'none',
                  transition: '0.2s'
                }}
              >
                {cat}
              </button>
            );
          })}
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(330px, 1fr))',
          gap: '28px'
        }}>
          {filteredEvents.map((event, index) => (
            <EventCard key={event.EventId || event.eventId || index} event={event} />
          ))}
        </div>

        {filteredEvents.length === 0 && (
          <p style={{ textAlign: 'center', color: '#b3acc7', marginTop: '50px', fontSize: '16px' }}>
            Jelenleg nincsenek események ebben a kategóriában.
          </p>
        )}
      </div>
    </div>
  );
}