import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function HomePage() {
  const [featuredEvents, setFeaturedEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://localhost:5000/api/events')
      .then((res) => {
        if (!res.ok) throw new Error('Hiba');
        return res.json();
      })
      .then((data) => {
        setFeaturedEvents(data.slice(0, 3));
        setLoading(false);
      })
      .catch(() => {
        setFeaturedEvents([
          {
            id: 1,
            title: 'Nagyszínpad: Nyitó Show & Lézerparádé',
            date: '2026. Augusztus 12. • 21:00',
            location: 'Main Stage',
            category: 'Koncert',
            imageUrl: 'https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&w=800&q=80'
          },
          {
            id: 2,
            title: 'Electronic Arena: Midnight Rave',
            date: '2026. Augusztus 13. • 23:30',
            location: 'Colosseum',
            category: 'Elektronikus',
            imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80'
          },
          {
            id: 3,
            title: 'Fényinstallációk & Kortárs Művészeti Udvar',
            date: '2026. Augusztus 14. • 18:00',
            location: 'Art Zone',
            category: 'Kiállítás',
            imageUrl: 'https://images.unsplash.com/photo-1501281668745-f7f57925c3b4?auto=format&fit=crop&w=800&q=80'
          }
        ]);
        setLoading(false);
      });
  }, []);

  // Gyorselérés kártyák: Programok és Jegyek & Bérletek
  const navCards = [
    {
      title: 'Összes Program',
      desc: 'Böngéssz a koncertek, DJ szettek és workshopok teljes kínálatában.',
      path: '/events',
      badge: 'LINEUP',
      accent: '#ff007f',
      icon: '🎸'
    },
    {
      title: 'Jegyek & Bérletek',
      desc: 'Vásárold meg a napijegyedet vagy bérletedet a fesztiválra, és biztosítsd a helyed.',
      path: '/profile',
      badge: 'JEGYEK',
      accent: '#0284c7',
      icon: '🎟️'
    }
  ];

  return (
    <div style={{ width: '100%', backgroundColor: '#090612', color: '#ffffff' }}>
      
      {/* 1. HERO VIDEÓS SZEKCIÓ */}
      <div style={{
        width: '100%',
        height: 'calc(100vh - 70px)',
        minHeight: '600px',
        position: 'relative',
        overflow: 'hidden',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        backgroundColor: '#090612'
      }}>
        <video
          autoPlay
          loop
          muted
          playsInline
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            minWidth: '100%',
            minHeight: '100%',
            width: 'auto',
            height: 'auto',
            transform: 'translate(-50%, -50%)',
            objectFit: 'cover',
            zIndex: 0
          }}
        >
          <source src="/gemini_generated_video_50f263ba.mp4" type="video/mp4" />
        </video>

        <div style={{
          position: 'absolute',
          inset: 0,
          background: 'linear-gradient(180deg, rgba(9, 6, 18, 0.45) 0%, rgba(9, 6, 18, 0.75) 75%, #090612 100%)',
          zIndex: 1
        }} />

        <div style={{ position: 'relative', zIndex: 2, padding: '0 24px', maxWidth: '1000px' }}>
          <span style={{
            background: '#0284c7',
            color: '#ffffff',
            padding: '7px 18px',
            borderRadius: '50px',
            fontSize: '12px',
            fontWeight: 900,
            letterSpacing: '2px',
            textTransform: 'uppercase',
            boxShadow: '0 4px 20px rgba(2, 132, 199, 0.5)'
          }}>
            2026 • A ZENE ÉS A SZABADSÁG SZIGETE
          </span>

          <h1 style={{
            fontSize: 'clamp(42px, 7vw, 84px)',
            fontWeight: 900,
            textTransform: 'uppercase',
            margin: '24px auto 18px auto',
            lineHeight: '1.05',
            letterSpacing: '-1.5px',
            color: '#ffffff',
            textShadow: '0 6px 30px rgba(0,0,0,0.7)'
          }}>
            ÉLD ÁT A <span style={{ color: '#ff007f' }}>FESZTIVÁL</span> ÉLETÉRZÉST
          </h1>

          <p style={{
            color: '#e2dff0',
            maxWidth: '650px',
            margin: '0 auto 35px auto',
            fontSize: '18px',
            lineHeight: '1.6',
            fontWeight: 500
          }}>
            Világsztárok, lenyűgöző vizuális show-k, kiállítások és felejthetetlen éjszakák várnak rád.
          </p>

          <div style={{ display: 'flex', gap: '16px', justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link
              to="/events"
              style={{
                background: '#ff007f',
                color: '#ffffff',
                padding: '15px 36px',
                borderRadius: '50px',
                fontSize: '14px',
                fontWeight: 900,
                textTransform: 'uppercase',
                letterSpacing: '1.5px',
                textDecoration: 'none',
                boxShadow: '0 0 25px rgba(255, 0, 127, 0.6)'
              }}
            >
              Programok böngészése →
            </Link>
          </div>
        </div>
      </div>

      {/* 2. GYORS ELÉRÉS KÁRTYÁK */}
      <section style={{
        width: '100%',
        boxSizing: 'border-box',
        padding: '70px clamp(24px, 4vw, 64px) 40px clamp(24px, 4vw, 64px)',
        textAlign: 'left'
      }}>
        <div style={{ marginBottom: '32px' }}>
          <span style={{ color: '#ff007f', fontSize: '12px', fontWeight: 900, letterSpacing: '2px', textTransform: 'uppercase' }}>
            FEDEZD FEL AZ OLDALT
          </span>
          <h2 style={{ fontSize: '34px', marginTop: '6px', letterSpacing: '-0.5px' }}>
            GYORS ELÉRÉS
          </h2>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          gap: '28px',
          width: '100%'
        }}>
          {navCards.map((card, index) => (
            <Link
              key={index}
              to={card.path}
              style={{
                textDecoration: 'none',
                color: '#ffffff',
                background: 'rgba(21, 16, 38, 0.75)',
                backdropFilter: 'blur(12px)',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                borderRadius: '20px',
                padding: '32px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                transition: 'transform 0.25s ease, border-color 0.25s ease, box-shadow 0.25s ease',
                boxShadow: '0 10px 30px rgba(0,0,0,0.4)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-6px)';
                e.currentTarget.style.borderColor = card.accent;
                e.currentTarget.style.boxShadow = `0 12px 30px ${card.accent}33`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                e.currentTarget.style.boxShadow = '0 10px 30px rgba(0,0,0,0.4)';
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '18px' }}>
                  <span style={{ fontSize: '34px' }}>{card.icon}</span>
                  <span style={{
                    background: `${card.accent}22`,
                    color: card.accent,
                    border: `1px solid ${card.accent}55`,
                    padding: '4px 12px',
                    borderRadius: '50px',
                    fontSize: '11px',
                    fontWeight: 900,
                    letterSpacing: '1.5px'
                  }}>
                    {card.badge}
                  </span>
                </div>
                <h3 style={{ fontSize: '22px', fontWeight: 900, textTransform: 'uppercase', margin: '0 0 10px 0' }}>
                  {card.title}
                </h3>
                <p style={{ color: '#b3acc7', fontSize: '15px', lineHeight: '1.5', marginBottom: '24px' }}>
                  {card.desc}
                </p>
              </div>
              <span style={{ color: card.accent, fontSize: '13px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px' }}>
                Megnyitás →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* 3. KIEMELT ESEMÉNYEK SZEKCIÓ */}
      <section style={{
        width: '100%',
        boxSizing: 'border-box',
        padding: '40px clamp(24px, 4vw, 64px) 90px clamp(24px, 4vw, 64px)',
        textAlign: 'left'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: '16px', marginBottom: '32px' }}>
          <div>
            <span style={{ color: '#0284c7', fontSize: '12px', fontWeight: 900, letterSpacing: '2px', textTransform: 'uppercase' }}>
              NE MARADJ LE RÓLA
            </span>
            <h2 style={{ fontSize: '34px', marginTop: '6px', letterSpacing: '-0.5px' }}>
              KIEMELT ESEMÉNYEK
            </h2>
          </div>
          <Link
            to="/events"
            style={{
              color: '#ff007f',
              textDecoration: 'none',
              fontSize: '14px',
              fontWeight: 800,
              textTransform: 'uppercase',
              letterSpacing: '1px'
            }}
          >
            Összes esemény megtekintése →
          </Link>
        </div>

        {loading ? (
          <p style={{ color: '#b3acc7' }}>Programok betöltése...</p>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '28px',
            width: '100%'
          }}>
            {featuredEvents.map((event) => (
              <Link
                key={event.id}
                to={`/events/${event.id}`}
                style={{
                  textDecoration: 'none',
                  color: '#ffffff',
                  background: '#151026',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '20px',
                  overflow: 'hidden',
                  display: 'flex',
                  flexDirection: 'column',
                  transition: 'transform 0.25s ease, border-color 0.25s ease',
                  boxShadow: '0 10px 30px rgba(0,0,0,0.45)'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-6px)';
                  e.currentTarget.style.borderColor = '#ff007f';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.1)';
                }}
              >
                <div style={{ position: 'relative', height: '220px', width: '100%' }}>
                  <img
                    src={event.imageUrl || 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?auto=format&fit=crop&w=800&q=80'}
                    alt={event.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                  />
                  {event.category && (
                    <span style={{
                      position: 'absolute',
                      top: '14px',
                      left: '14px',
                      background: '#ff007f',
                      color: '#ffffff',
                      padding: '5px 12px',
                      borderRadius: '50px',
                      fontSize: '11px',
                      fontWeight: 900,
                      textTransform: 'uppercase',
                      letterSpacing: '1px'
                    }}>
                      {event.category}
                    </span>
                  )}
                </div>

                <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', flexGrow: 1, justifyContent: 'space-between' }}>
                  <div>
                    <div style={{ color: '#0ea5e9', fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>
                      {event.date} {event.location ? `• ${event.location}` : ''}
                    </div>
                    <h3 style={{ fontSize: '20px', fontWeight: 900, margin: '0 0 14px 0', lineHeight: '1.3' }}>
                      {event.title}
                    </h3>
                  </div>
                  <span style={{ color: '#ff007f', fontSize: '13px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px' }}>
                    Részletek & Jegy →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>

    </div>
  );
}