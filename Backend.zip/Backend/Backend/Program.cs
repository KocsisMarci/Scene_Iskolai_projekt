﻿using MySql.Data.MySqlClient;
using Backend.Services;
using Backend.Interfaces;
using Backend.Database;
using Backend.Models;
using System.Security.Cryptography;

namespace Backend
{
    internal class Program
    {

        public static MySqlCommand cmd;
        public static MySqlConnection conn;
        static void Main(string[] args)
        {
            DatabaseConnection creator = new DatabaseConnection( "SERVER = localhost;" + "DATABASE =scene_db;" + "UID=root;" + "PASSWORD=;");

            cmd = creator.CreateCommand();
            conn = creator.CreateConnection();



            List<Artist> artists = new ArtistService(creator).Read();

            Console.WriteLine(artists.Count);
        }
    }
}
