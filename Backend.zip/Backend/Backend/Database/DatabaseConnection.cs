﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace Backend.Database;

public class DatabaseConnection
{
    private  string _connectionString;
    private MySqlConnection conn=new MySqlConnection();

    public DatabaseConnection(string connectionString)
    {
        _connectionString = connectionString;
    }

    public MySqlCommand CreateCommand()
    {
        MySqlCommand cmd = new MySqlCommand();

        conn.ConnectionString = _connectionString;

        cmd.Connection = conn;
        return cmd;
    }

    public MySqlConnection CreateConnection() {
        return conn;
    }
}