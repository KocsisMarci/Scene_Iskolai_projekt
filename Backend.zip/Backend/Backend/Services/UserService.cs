using MySql.Data.MySqlClient;
using Backend.Database;
using Backend.Models;

namespace Backend.Services;

public class UserService
{
    private MySqlCommand cmd;
    private MySqlConnection conn;
    public UserService(DatabaseConnection db)
    {
        cmd = db.CreateCommand();

        conn = cmd.Connection;
    }

    public string Delete(uint id)
    {
        cmd.Parameters.Clear();
        conn.Open();
        try
        {
            cmd.CommandText = "DELETE FROM Users WHERE UserId=@m1;";

            cmd.Parameters.AddWithValue("@m1", id);

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres felhasználó törlés";

            else return "Sikertelen felhasználó törlés";
        }
        finally
        {
            conn.Close();
        }
    }

    public string Insert(User user)
    {
        cmd.Parameters.Clear();
        conn.Open();
        try
        {
            cmd.CommandText = "INSERT INTO Users(Username, Email, PasswordHash, DisplayName, AvatarLevel, CurrentXP, AvatarImageUrl, Bio, Role) " +
                              "VALUES(@m1, @m2, @m3, @m4, @m5, @m6, @m7, @m8, @m9)";

            cmd.Parameters.AddWithValue("@m1", user.Username);
            cmd.Parameters.AddWithValue("@m2", user.Email);
            cmd.Parameters.AddWithValue("@m3", user.PasswordHash);
            cmd.Parameters.AddWithValue("@m4", user.DisplayName);
            cmd.Parameters.AddWithValue("@m5", user.AvatarLevel);
            cmd.Parameters.AddWithValue("@m6", user.CurrentXP);
            cmd.Parameters.AddWithValue("@m7", user.AvatarImageUrl);
            cmd.Parameters.AddWithValue("@m8", user.Bio);
            cmd.Parameters.AddWithValue("@m9", user.Role.ToString());

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres felhasználó rögzítés";

            else return "Sikertelen felhasználó rögzítés";
        }
        finally
        {
            conn.Close();
        }
    }

    public List<User> Read()
    {
        cmd.Parameters.Clear();
        conn.Open();
        try
        {
            cmd.CommandText = "SELECT * FROM Users";

            List<User> felhasznalok = new List<User>();

            MySqlDataReader olvaso = cmd.ExecuteReader();

            while (olvaso.Read())
            {
                User user = new User();
                user.UserId = olvaso.GetUInt32("UserId");
                user.Username = olvaso.GetString("Username");
                user.Email = olvaso.GetString("Email");
                user.PasswordHash = olvaso.GetString("PasswordHash");
                user.DisplayName = olvaso.GetString("DisplayName");
                user.AvatarLevel = olvaso.GetUInt32("AvatarLevel");
                user.CurrentXP = olvaso.GetUInt32("CurrentXP");
                user.AvatarImageUrl = olvaso.GetString("AvatarImageUrl");
                user.Bio = olvaso.GetString("Bio");
                user.Role = Enum.Parse<UserRole>(olvaso.GetString("Role"));
                
                //user.CreatedAt = olvaso.GetDateTime("CreatedAt");
                //user.UpdatedAt = olvaso.GetDateTime("UpdatedAt");

                felhasznalok.Add(user);
            }

            olvaso.Close();

            return felhasznalok;
        }
        finally
        {
            conn.Close();
        }
    }

    public string Update(User user)
    {
        cmd.Parameters.Clear();
        conn.Open();
        try
        {
            cmd.CommandText = "UPDATE Users SET Username=@m1, Email=@m2, PasswordHash=@m3, DisplayName=@m4, " +
                              "AvatarLevel=@m5, CurrentXP=@m6, AvatarImageUrl=@m7, Bio=@m8, Role=@m9 WHERE UserId=@m10;";

            cmd.Parameters.AddWithValue("@m1", user.Username);
            cmd.Parameters.AddWithValue("@m2", user.Email);
            cmd.Parameters.AddWithValue("@m3", user.PasswordHash);
            cmd.Parameters.AddWithValue("@m4", user.DisplayName);
            cmd.Parameters.AddWithValue("@m5", user.AvatarLevel);
            cmd.Parameters.AddWithValue("@m6", user.CurrentXP);
            cmd.Parameters.AddWithValue("@m7", user.AvatarImageUrl);
            cmd.Parameters.AddWithValue("@m8", user.Bio);
            cmd.Parameters.AddWithValue("@m9", user.Role.ToString());
            cmd.Parameters.AddWithValue("@m10", user.UserId);

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres felhasználó szerkesztés";

            else return "Sikertelen felhasználó szerkesztés";
        }
        finally
        {
            conn.Close();
        }
    }
}