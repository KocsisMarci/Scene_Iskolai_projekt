using MySql.Data.MySqlClient;
using Backend.Database;
using Backend.Models;

namespace Backend.Services;

public class ArtistService
{
    private MySqlCommand cmd;
    private MySqlConnection conn;
    public ArtistService(DatabaseConnection db)
    {
        cmd = db.CreateCommand();

        conn = cmd.Connection;
    }

    public string Delete(int id)
    {
        cmd.Parameters.Clear();
        try
        {
            conn.Open();

            cmd.CommandText = "DELETE FROM Artists WHERE ArtistId=@m1;";

            cmd.Parameters.AddWithValue("@m1", id);

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres előadó törlés";

            else return "Sikertelen előadó törlés";
        }
        catch (MySqlException ex)
        {
            return "Adatbázis hiba az előadó törlésekor: " + ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }

    public string Insert(Artist artist)
    {
        cmd.Parameters.Clear();
        try
        {
            conn.Open();

            cmd.CommandText = "INSERT INTO Artists(Name, Genre, Bio, ImageUrl, SocialLinks) " +
                              "VALUES(@m1, @m2, @m3, @m4, @m5)";

            cmd.Parameters.AddWithValue("@m1", artist.Name);
            cmd.Parameters.AddWithValue("@m2", artist.Genre.ToString());
            cmd.Parameters.AddWithValue("@m3", artist.Bio);
            cmd.Parameters.AddWithValue("@m4", artist.ImageUrl);
            cmd.Parameters.AddWithValue("@m5", artist.SocialLinks);

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres előadó rögzítés";

            else return "Sikertelen előadó rögzítés";
        }
        catch (MySqlException ex)
        {
            return "Adatbázis hiba az előadó rögzítésekor: " + ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }

    public List<Artist> Read()
    {
        cmd.Parameters.Clear();
        try
        {
            conn.Open();

            cmd.CommandText = "SELECT * FROM Artists";

            List<Artist> eloadok = new List<Artist>();

            MySqlDataReader olvaso = cmd.ExecuteReader();

            while (olvaso.Read())
            {
                Artist artist = new Artist();
                artist.ArtistId = olvaso.GetInt32("ArtistId");
                artist.Name = olvaso.GetString("Name");
                artist.Genre = Enum.Parse<PerformerType>(olvaso.GetString("Genre"));

                // A Bio, ImageUrl és SocialLinks oszlopok NULL-ok is lehetnek az adatbázisban.
                artist.Bio = olvaso.IsDBNull(olvaso.GetOrdinal("Bio")) ? null : olvaso.GetString("Bio");
                artist.ImageUrl = olvaso.IsDBNull(olvaso.GetOrdinal("ImageUrl")) ? null : olvaso.GetString("ImageUrl");
                artist.SocialLinks = olvaso.IsDBNull(olvaso.GetOrdinal("SocialLinks")) ? null : olvaso.GetString("SocialLinks");

                eloadok.Add(artist);
            }

            olvaso.Close();

            return eloadok;
        }
        catch (MySqlException ex)
        {
            // A lista miatt itt nem lehet szöveget visszaadni, ezért új kivételt dobunk,
            // amelyet a hívó (Program.cs / felület) kezelhet.
            throw new InvalidOperationException("Adatbázis hiba az előadók lekérdezésekor: " + ex.Message, ex);
        }
        finally
        {
            conn.Close();
        }
    }

    public string Update(Artist artist)
    {
        cmd.Parameters.Clear();
        try
        {
            conn.Open();

            cmd.CommandText = "UPDATE Artists SET Name=@m1, Genre=@m2, Bio=@m3, ImageUrl=@m4, SocialLinks=@m5 " +
                              "WHERE ArtistId=@m6;";

            cmd.Parameters.AddWithValue("@m1", artist.Name);
            cmd.Parameters.AddWithValue("@m2", artist.Genre.ToString());
            cmd.Parameters.AddWithValue("@m3", artist.Bio);
            cmd.Parameters.AddWithValue("@m4", artist.ImageUrl);
            cmd.Parameters.AddWithValue("@m5", artist.SocialLinks);
            cmd.Parameters.AddWithValue("@m6", artist.ArtistId);

            int sorok = cmd.ExecuteNonQuery();

            if (sorok > 0) return "Sikeres előadó szerkesztés";

            else return "Sikertelen előadó szerkesztés";
        }
        catch (MySqlException ex)
        {
            return "Adatbázis hiba az előadó szerkesztésekor: " + ex.Message;
        }
        finally
        {
            conn.Close();
        }
    }
}
