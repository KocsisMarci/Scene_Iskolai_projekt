namespace Backend.Models;

/// <summary>
/// Közös ős a bejelentkezésre képes entitásoknak (felhasználónév, e-mail, jelszó hash, megjelenített név).
/// Jelenleg csak a User származik belőle; ha az Artist is kap fiókadatokat, ebből örökölhet.
/// </summary>
public abstract class Account // : AuditableEntity nem tudom, kell ez a származtatás nekünk?
{
    public string Username { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string? DisplayName { get; set; }

    public override string ToString() =>
        $"Username: {Username}, Email: {Email}, DisplayName: {DisplayName ?? "-"}, {base.ToString()}";
}
