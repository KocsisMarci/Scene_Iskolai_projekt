namespace Backend.Models;

public class Artist : NamedEntity 
{
    public int ArtistId { get; set; }

    public string? Bio { get; set; }
    public string? SocialLinks { get; set; }
    public PerformerType Genre { get; set; }

    public override string ToString() =>
        $"Artist [ArtistId: {ArtistId}, {base.ToString()}, Genre: {Genre}, " +
        $"Bio: {Bio ?? "-"}, SocialLinks: {SocialLinks ?? "-"}]";
}
