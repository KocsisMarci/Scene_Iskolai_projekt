namespace Backend.Models;

public enum UserRole  //Ez lényegében olyan, mintha egy csoport elemeit sorolnánk fel   
                       //pl Az enum Évszak, és van Tavasz, Nyár, Ősz, Tél.
{
    User,
    Admin
}

public enum BookingStatus
{
    Interested,
    Going,
    Cancelled
}

public enum PhotoStatus
{
    Pending,
    Approved,
    Rejected
}


public enum PerformerType
{
    Musician,      // zenész / zenekar
    DJ,
    Dancer,
    Comedian,
    Magician,
    Speaker,       // előadó, felszólaló, szakmai előadás
    Organization,  // egyesület, klub, szakszervezet, civil szervezet
    AnimalShow,    // kutyás bemutató, lovasbemutató stb.
    Workshop,      // közösségi, tanítós program
    Other
}