﻿namespace Backend.Models;

/// <summary>
/// Közös ős a névvel és képpel rendelkező entitásoknak (Artist, Vendor).
/// </summary>
public abstract class NamedEntity
{
    public string Name { get; set; } = string.Empty;
    public string? ImageUrl { get; set; }

    public override string ToString() => $"Name: {Name}, ImageUrl: {ImageUrl ?? "-"}";
}