namespace Backend.Models;

public class User : Account
{
    public uint UserId { get; set; }
    public uint AvatarLevel { get; set; } = 1;
    public uint CurrentXP { get; set; }
    public string? AvatarImageUrl { get; set; }
    public string? Bio { get; set; }
    public UserRole Role { get; set; } = UserRole.User;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    // A PasswordHash szándékosan nem szerepel a kimenetben.
    public override string ToString() =>
        $"User [UserId: {UserId}, {base.ToString()}, AvatarLevel: {AvatarLevel}, CurrentXP: {CurrentXP}, " +
        $"AvatarImageUrl: {AvatarImageUrl ?? "-"}, Bio: {Bio ?? "-"}, Role: {Role}, " +
        $"UpdatedAt: {UpdatedAt:yyyy-MM-dd HH:mm:ss}]";
}
