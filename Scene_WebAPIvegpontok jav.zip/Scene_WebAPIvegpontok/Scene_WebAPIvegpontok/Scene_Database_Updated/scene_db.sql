-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2026. Okt 28. 20:33
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `scene_db`
--
CREATE DATABASE IF NOT EXISTS `scene_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `scene_db`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `accounts`
--

DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `AccountId` int(10) UNSIGNED NOT NULL,
  `AccountName` varchar(50) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `DisplayName` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `accounts`
--

INSERT INTO `accounts` (`AccountId`, `AccountName`, `Email`, `PasswordHash`, `DisplayName`) VALUES
(1, 'admin_user', 'admin@scene.hu', '$2a$11$e87.gK/x...hash1', 'Scene Adminisztrátor'),
(2, 'user_teszt', 'teszt@scene.hu', '$2a$11$p98.hL/y...hash2', 'Teszt Felhasználó');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `artists`
--

DROP TABLE IF EXISTS `artists`;
CREATE TABLE `artists` (
  `ArtistId` int(10) UNSIGNED NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Bio` text DEFAULT NULL,
  `ImageUrl` varchar(255) DEFAULT NULL,
  `SocialLinks` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`SocialLinks`)),
  `Genre` enum('Musician','DJ','Dancer','Comedian','Magician','Speaker','Organization','AnimalShow','Workshop','Other') NOT NULL DEFAULT 'Other'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `artists`
--

INSERT INTO `artists` (`ArtistId`, `Name`, `Bio`, `ImageUrl`, `SocialLinks`, `Genre`) VALUES
(1, 'Példa Zenekar', 'Példa előadó biográfia: 2015-ben alakult akusztikus pop-rock együttes.', 'https://example.com/artists/pelda_band.jpg', '{\"instagram\": \"@pelda_band\", \"spotify\": \"artist_pelda_123\"}', 'Musician'),
(2, 'Példa DJ Beats', 'Példa lemezlovas leírása: Elekronikus zenei producer és DJ.', 'https://example.com/artists/pelda_dj.jpg', '{\"facebook\": \"peldadj\", \"soundcloud\": \"peldadj_official\"}', 'DJ');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
  `BookingId` int(10) UNSIGNED NOT NULL,
  `UserId` int(10) UNSIGNED NOT NULL,
  `EventId` int(10) UNSIGNED NOT NULL,
  `Status` enum('Interested','Going','Cancelled') NOT NULL DEFAULT 'Interested',
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `bookings`
--

INSERT INTO `bookings` (`BookingId`, `UserId`, `EventId`, `Status`, `CreatedAt`) VALUES
(1, 1, 1, 'Going', '2026-10-27 14:24:45'),
(2, 2, 2, 'Interested', '2026-10-27 14:24:45'),
(3, 3, 1, 'Going', '2026-10-28 19:38:00'),
(6, 3, 2, 'Going', '2026-10-28 18:57:08');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `eventphotos`
--

DROP TABLE IF EXISTS `eventphotos`;
CREATE TABLE `eventphotos` (
  `PhotoId` int(10) UNSIGNED NOT NULL,
  `UserId` int(10) UNSIGNED NOT NULL,
  `EventId` int(10) UNSIGNED NOT NULL,
  `ImageUrl` varchar(255) NOT NULL,
  `XPAwarded` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `UploadedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `eventphotos`
--

INSERT INTO `eventphotos` (`PhotoId`, `UserId`, `EventId`, `ImageUrl`, `XPAwarded`, `Status`, `UploadedAt`) VALUES
(1, 1, 1, 'https://example.com/photos/pelda_koncert_foto1.jpg', 50, 'Approved', '2026-10-27 14:24:45'),
(2, 1, 2, 'https://example.com/photos/pelda_workshop_foto2.jpg', 0, 'Pending', '2026-10-27 14:24:45');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `eventreviews`
--

DROP TABLE IF EXISTS `eventreviews`;
CREATE TABLE `eventreviews` (
  `ReviewId` int(10) UNSIGNED NOT NULL,
  `EventId` int(10) UNSIGNED NOT NULL,
  `UserId` int(10) UNSIGNED NOT NULL,
  `Rating` tinyint(3) UNSIGNED NOT NULL CHECK (`Rating` between 1 and 5),
  `Comment` text DEFAULT NULL,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `eventreviews`
--

INSERT INTO `eventreviews` (`ReviewId`, `EventId`, `UserId`, `Rating`, `Comment`, `CreatedAt`) VALUES
(1, 1, 1, 5, 'Példa értékelés: Fantasztikus volt a hangulat, nagyszerű teszt rendezvény!', '2026-10-27 14:24:45'),
(2, 2, 2, 4, 'Példa értékelés: Nagyon tanulságos workshop, jól szervezett minta esemény.', '2026-10-27 14:24:45');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `EventId` int(10) UNSIGNED NOT NULL,
  `OrganizerId` int(10) UNSIGNED NOT NULL,
  `Name` varchar(150) NOT NULL,
  `Description` text DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Latitude` decimal(9,6) DEFAULT NULL,
  `Longitude` decimal(9,6) DEFAULT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime NOT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `CoverImageUrl` varchar(255) DEFAULT NULL,
  `MaxCapacity` int(10) UNSIGNED DEFAULT NULL,
  `Status` enum('Published','Draft','Cancelled') NOT NULL DEFAULT 'Published',
  `CreatedByUserId` int(10) UNSIGNED DEFAULT NULL,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp(),
  `UpdatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `events`
--

INSERT INTO `events` (`EventId`, `OrganizerId`, `Name`, `Description`, `Location`, `Latitude`, `Longitude`, `StartDate`, `EndDate`, `Category`, `CoverImageUrl`, `MaxCapacity`, `Status`, `CreatedByUserId`, `CreatedAt`, `UpdatedAt`) VALUES
(1, 0, 'Példa Zenei Fesztivál 2026', 'Példa leírás: Nyári szabadtéri teszt fesztivál a Népkertben.', 'Miskolc, Népkert', 48.097500, 20.781100, '2026-07-15 14:00:00', '2026-07-17 23:00:00', 'Zene', 'https://example.com/events/pelda_fesztival.jpg', 500, 'Published', 2, '2026-10-27 14:24:45', '2026-10-27 14:24:45'),
(2, 0, 'Példa Művészeti Workshop', 'Példa leírás: Interaktív kreatív workshop és kiállítás.', 'Budapest, Akvárium Klub', 47.497900, 19.054400, '2026-09-10 10:00:00', '2026-09-10 18:00:00', 'Workshop', 'https://example.com/events/pelda_workshop.jpg', 100, 'Published', 2, '2026-10-27 14:24:45', '2026-10-27 14:24:45');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `eventvendors`
--

DROP TABLE IF EXISTS `eventvendors`;
CREATE TABLE `eventvendors` (
  `EventId` int(10) UNSIGNED NOT NULL,
  `VendorId` int(10) UNSIGNED NOT NULL,
  `SpotLabel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `eventvendors`
--

INSERT INTO `eventvendors` (`EventId`, `VendorId`, `SpotLabel`) VALUES
(1, 1, 'A-12 Gasztro Sátor'),
(1, 2, 'B-05 Ajándék Stand');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `performances`
--

DROP TABLE IF EXISTS `performances`;
CREATE TABLE `performances` (
  `PerformanceId` int(10) UNSIGNED NOT NULL,
  `EventId` int(10) UNSIGNED NOT NULL,
  `ArtistId` int(10) UNSIGNED NOT NULL,
  `StageName` varchar(100) DEFAULT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `performances`
--

INSERT INTO `performances` (`PerformanceId`, `EventId`, `ArtistId`, `StageName`, `StartTime`, `EndTime`) VALUES
(1, 1, 1, 'Nagyszínpad', '2026-07-15 18:00:00', '2026-07-15 20:00:00'),
(2, 1, 2, 'Electronic Stage', '2026-07-15 21:00:00', '2026-07-15 23:00:00');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `refreshtokens`
--

DROP TABLE IF EXISTS `refreshtokens`;
CREATE TABLE `refreshtokens` (
  `RefreshTokenId` int(10) UNSIGNED NOT NULL,
  `UserId` int(10) UNSIGNED NOT NULL,
  `Token` varchar(255) NOT NULL,
  `ExpiresAt` datetime NOT NULL,
  `IsRevoked` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `refreshtokens`
--

INSERT INTO `refreshtokens` (`RefreshTokenId`, `UserId`, `Token`, `ExpiresAt`, `IsRevoked`, `CreatedAt`) VALUES
(1, 3, 'Wkbuc8wRDD59VHctZUVeDEPSD/iLf55unVOlO01Cc5uk6/yrWvu+oo8dxAKgsddQL2wACUqDMDc+r4WLmMNVYg==', '2026-11-04 18:34:45', 0, '2026-10-28 18:34:45');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `UserId` int(10) UNSIGNED NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `DisplayName` varchar(100) DEFAULT NULL,
  `AvatarLevel` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `CurrentXP` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `AvatarImageUrl` varchar(255) DEFAULT NULL,
  `Bio` varchar(500) DEFAULT NULL,
  `Role` enum('User','Admin','Organizer','Vendor') DEFAULT 'User',
  `IsActive` tinyint(1) NOT NULL DEFAULT 1,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp(),
  `UpdatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`UserId`, `Username`, `Email`, `PasswordHash`, `DisplayName`, `AvatarLevel`, `CurrentXP`, `AvatarImageUrl`, `Bio`, `Role`, `IsActive`, `CreatedAt`, `UpdatedAt`) VALUES
(1, 'pelda_elek', 'pelda.elek@example.com', '$2a$12$PELDAPASSWORDHASH11111111111111111111111111111111111', 'Példa Elek', 1, 150, 'https://example.com/avatars/pelda_user1.jpg', 'Ez egy példa teszt felhasználói profil leírása.', 'User', 1, '2026-10-27 14:24:45', '2026-10-27 14:24:45'),
(2, 'pelda_admin', 'pelda.admin@example.com', '$2a$12$PELDAPASSWORDHASH22222222222222222222222222222222222', 'Példa Adminisztrátor', 5, 1200, 'https://example.com/avatars/pelda_admin.jpg', 'Ez egy példa adminisztrátori fiók leírása.', 'Admin', 1, '2026-10-27 14:24:45', '2026-10-27 14:24:45'),
(3, 'tesztadmin', 'tesztadmin@example.com', '$2a$11$96ndL6RymzRyUIRF5d1Lueu3dqK.kcdWdB5NEXH6.oXzikKBE6BXu', 'Teszt Admin', 1, 0, 'string', 'string', 'Admin', 1, '2026-10-28 18:33:34', '2026-10-28 18:33:34');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `vendors`
--

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `VendorId` int(10) UNSIGNED NOT NULL,
  `Name` varchar(150) NOT NULL,
  `VendorType` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `ContactEmail` varchar(150) DEFAULT NULL,
  `ContactPhone` varchar(30) DEFAULT NULL,
  `ImageUrl` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `vendors`
--

INSERT INTO `vendors` (`VendorId`, `Name`, `VendorType`, `Description`, `ContactEmail`, `ContactPhone`, `ImageUrl`) VALUES
(1, 'Példa Street Food Truck', 'Vendéglátás', 'Példa árus leírás: Kézműves hamburgerek és hűsítő italok.', 'pelda.foodtruck@example.com', '+36301234567', 'https://example.com/vendors/pelda_foodtruck.jpg'),
(2, 'Példa Merch & Souvenir', 'Kereskedelem', 'Példa árus leírás: Hivatalos fesztiválos ajándéktárgyak és pólók.', 'pelda.merch@example.com', '+36309876543', 'https://example.com/vendors/pelda_merch.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `xptransactions`
--

DROP TABLE IF EXISTS `xptransactions`;
CREATE TABLE `xptransactions` (
  `TransactionId` int(10) UNSIGNED NOT NULL,
  `UserId` int(10) UNSIGNED NOT NULL,
  `Amount` int(11) NOT NULL,
  `Reason` varchar(100) NOT NULL,
  `ReferenceId` int(10) UNSIGNED DEFAULT NULL,
  `CreatedAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `xptransactions`
--

INSERT INTO `xptransactions` (`TransactionId`, `UserId`, `Amount`, `Reason`, `ReferenceId`, `CreatedAt`) VALUES
(1, 1, 100, 'Példa XP: Profil adatok kitöltése', NULL, '2026-10-27 14:24:45'),
(2, 1, 50, 'Példa XP: Esemény fotó jóváhagyva', 1, '2026-10-27 14:24:45');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`AccountId`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- A tábla indexei `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`ArtistId`);

--
-- A tábla indexei `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`BookingId`),
  ADD UNIQUE KEY `uq_Booking` (`UserId`,`EventId`),
  ADD KEY `idx_Bookings_UserId` (`UserId`),
  ADD KEY `idx_Bookings_EventId` (`EventId`);

--
-- A tábla indexei `eventphotos`
--
ALTER TABLE `eventphotos`
  ADD PRIMARY KEY (`PhotoId`),
  ADD KEY `fk_EventPhotos_User` (`UserId`),
  ADD KEY `idx_EventPhotos_EventId` (`EventId`);

--
-- A tábla indexei `eventreviews`
--
ALTER TABLE `eventreviews`
  ADD PRIMARY KEY (`ReviewId`),
  ADD UNIQUE KEY `uq_User_Event_Review` (`EventId`,`UserId`),
  ADD KEY `fk_Reviews_User` (`UserId`);

--
-- A tábla indexei `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventId`),
  ADD KEY `fk_Events_CreatedBy` (`CreatedByUserId`),
  ADD KEY `idx_Events_StartDate` (`StartDate`),
  ADD KEY `idx_Events_Category` (`Category`);

--
-- A tábla indexei `eventvendors`
--
ALTER TABLE `eventvendors`
  ADD PRIMARY KEY (`EventId`,`VendorId`),
  ADD KEY `fk_EventVendors_Vendor` (`VendorId`);

--
-- A tábla indexei `performances`
--
ALTER TABLE `performances`
  ADD PRIMARY KEY (`PerformanceId`),
  ADD UNIQUE KEY `uq_Performance` (`EventId`,`ArtistId`,`StartTime`),
  ADD KEY `fk_Performances_Artist` (`ArtistId`);

--
-- A tábla indexei `refreshtokens`
--
ALTER TABLE `refreshtokens`
  ADD PRIMARY KEY (`RefreshTokenId`),
  ADD KEY `fk_RefreshTokens_User` (`UserId`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- A tábla indexei `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`VendorId`);

--
-- A tábla indexei `xptransactions`
--
ALTER TABLE `xptransactions`
  ADD PRIMARY KEY (`TransactionId`),
  ADD KEY `idx_XPTransactions_UserId` (`UserId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `accounts`
--
ALTER TABLE `accounts`
  MODIFY `AccountId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `artists`
--
ALTER TABLE `artists`
  MODIFY `ArtistId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `bookings`
--
ALTER TABLE `bookings`
  MODIFY `BookingId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `eventphotos`
--
ALTER TABLE `eventphotos`
  MODIFY `PhotoId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `eventreviews`
--
ALTER TABLE `eventreviews`
  MODIFY `ReviewId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `events`
--
ALTER TABLE `events`
  MODIFY `EventId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `performances`
--
ALTER TABLE `performances`
  MODIFY `PerformanceId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `refreshtokens`
--
ALTER TABLE `refreshtokens`
  MODIFY `RefreshTokenId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `vendors`
--
ALTER TABLE `vendors`
  MODIFY `VendorId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `xptransactions`
--
ALTER TABLE `xptransactions`
  MODIFY `TransactionId` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_Bookings_Event` FOREIGN KEY (`EventId`) REFERENCES `events` (`EventId`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Bookings_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `eventphotos`
--
ALTER TABLE `eventphotos`
  ADD CONSTRAINT `fk_EventPhotos_Event` FOREIGN KEY (`EventId`) REFERENCES `events` (`EventId`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_EventPhotos_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `eventreviews`
--
ALTER TABLE `eventreviews`
  ADD CONSTRAINT `fk_Reviews_Event` FOREIGN KEY (`EventId`) REFERENCES `events` (`EventId`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Reviews_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `fk_Events_CreatedBy` FOREIGN KEY (`CreatedByUserId`) REFERENCES `users` (`UserId`) ON DELETE SET NULL;

--
-- Megkötések a táblához `eventvendors`
--
ALTER TABLE `eventvendors`
  ADD CONSTRAINT `fk_EventVendors_Event` FOREIGN KEY (`EventId`) REFERENCES `events` (`EventId`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_EventVendors_Vendor` FOREIGN KEY (`VendorId`) REFERENCES `vendors` (`VendorId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `performances`
--
ALTER TABLE `performances`
  ADD CONSTRAINT `fk_Performances_Artist` FOREIGN KEY (`ArtistId`) REFERENCES `artists` (`ArtistId`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Performances_Event` FOREIGN KEY (`EventId`) REFERENCES `events` (`EventId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `refreshtokens`
--
ALTER TABLE `refreshtokens`
  ADD CONSTRAINT `fk_RefreshTokens_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE;

--
-- Megkötések a táblához `xptransactions`
--
ALTER TABLE `xptransactions`
  ADD CONSTRAINT `fk_XPTransactions_User` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
