﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize] // Alapértelmezetten minden végpont védett
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        // Csak Admin kérheti le az összes felhasználót
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAllUsers()
        {
            try
            {
                List<UserResponseDto> list = _userService.GetAllUsers();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a felhasználók lekérése során: {ex.Message}");
            }
        }

        // Admin bárkit lekérhet, bejelentkezett User pedig a saját adatait lekérheti
        [HttpGet("GetById/{id}")]
        [Authorize]
        public IActionResult GetUserById(uint id)
        {
            try
            {
                uint currentUserId = this.GetCurrentUserId();
                bool isAdmin = this.IsAdmin();

                if (!isAdmin && id != currentUserId)
                {
                    return StatusCode(StatusCodes.Status403Forbidden, "Nincs jogosultságod más felhasználó adatainak megtekintésére.");
                }

                UserResponseDto? dto = _userService.GetUserById(id);
                if (dto != null) return Ok(dto);
                return NotFound($"Nincs felhasználó a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // Csak az Admin hozhat létre közvetlenül felhasználót a UserControlleren keresztül
        // (A sima userek az /api/auth/register végponton regisztrálnak)
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult PostUser([FromBody] CreateUserDto dto)
        {
            try
            {
                bool siker = _userService.CreateUser(dto);
                if (siker) return Ok("A felhasználó sikeresen létrejött.");
                return BadRequest("Nem sikerült elmenteni a felhasználót.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a felhasználó létrehozása során: {ex.Message}");
            }
        }

        // Sima User csak a SAJÁT profilját módosíthatja, az Admin BÁRKIÉT
        [HttpPut("{id}")]
        [Authorize]
        public IActionResult PutUser(uint id, [FromBody] UpdateUserDto dto)
        {
            try
            {
                uint currentUserId = this.GetCurrentUserId();
                bool isAdmin = this.IsAdmin();

                if (!isAdmin && id != currentUserId)
                {
                    return StatusCode(StatusCodes.Status403Forbidden, "Nincs jogosultságod más felhasználó adatainak módosítására.");
                }

                bool siker = _userService.UpdateUser(id, dto);
                if (siker) return Ok("A felhasználó adatai frissültek.");
                return NotFound($"Nincs felhasználó a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        // Csak Admin törölhet felhasználót
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteUser(uint id)
        {
            try
            {
                bool siker = _userService.DeleteUser(id);
                if (siker) return Ok("A felhasználó sikeresen törölve lett.");
                return NotFound($"Nincs felhasználó a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}