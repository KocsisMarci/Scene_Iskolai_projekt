﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;
using static Scene_WebAPIvegpontok.DTOs.EventPhotoDtos;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventPhotoController : ControllerBase
    {
        private readonly EventPhotoService _eventPhotoService;

        public EventPhotoController(EventPhotoService eventPhotoService)
        {
            _eventPhotoService = eventPhotoService;
        }

        // GET: api/EventPhoto
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllEventPhotos()
        {
            try
            {
                List<EventPhotoResponseDto> photos = _eventPhotoService.GetAllEventPhotos();
                return Ok(photos);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba történt a képek lekérése során: {ex.Message}");
            }
        }

        // GET: api/EventPhoto/GetById/1
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetEventPhotoById(uint id)
        {
            try
            {
                EventPhotoResponseDto? photo = _eventPhotoService.GetEventPhotoById(id);
                if (photo != null)
                {
                    return Ok(photo);
                }
                return NotFound($"Nincs kép a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/EventPhoto
        [HttpPost]
        [Authorize]
        public IActionResult PostEventPhoto([FromBody] CreateEventPhotoDto dto)
        {
            try
            {
                bool siker = _eventPhotoService.CreateEventPhoto(dto);
                if (siker)
                {
                    return Ok("A kép feltöltése sikeresen megtörtént (jóváhagyásra vár).");
                }
                return BadRequest("Nem sikerült feltölteni a képet.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kép feltöltése során: {ex.Message}");
            }
        }

        // PUT: api/EventPhoto/1
        [HttpPut("{id}")]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult PutEventPhoto(uint id, [FromBody] UpdateEventPhotoDto dto)
        {
            try
            {
                bool siker = _eventPhotoService.UpdateEventPhoto(id, dto);
                if (siker)
                {
                    return Ok("A kép állapota és XP értéke sikeresen frissült.");
                }
                return NotFound($"Nincs kép a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kép módosítása során: {ex.Message}");
            }
        }

        // DELETE: api/EventPhoto/1
        [HttpDelete("{id}")]
        public IActionResult DeleteEventPhoto(uint id)
        {
            try
            {
                bool siker = _eventPhotoService.DeleteEventPhoto(id);
                if (siker)
                {
                    return Ok("A kép sikeresen törölve lett.");
                }
                return NotFound($"Nincs kép a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kép törlése során: {ex.Message}");
            }
        }
    }
}
