﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VendorController : ControllerBase
    {
        private readonly VendorService _vendorService;

        public VendorController(VendorService vendorService)
        {
            _vendorService = vendorService;
        }

        // GET: api/Vendor
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllVendors()
        {
            try
            {
                List<VendorResponseDto> list = _vendorService.GetAllVendors();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az árusok lekérése során: {ex.Message}");
            }
        }

        // GET: api/Vendor/GetById/1
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetVendorById(uint id)
        {
            try
            {
                VendorResponseDto? dto = _vendorService.GetVendorById(id);
                if (dto != null)
                {
                    return Ok(dto);
                }
                return NotFound($"Nincs árus a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/Vendor
        [HttpPost]
        public IActionResult PostVendor([FromBody] CreateVendorDto dto)
        {
            try
            {
                bool siker = _vendorService.CreateVendor(dto);
                if (siker)
                {
                    return Ok("Az árus/szolgáltató sikeresen létrejött.");
                }
                return BadRequest("Nem sikerült elmenteni az árus adatait.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az árus létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/Vendor/1
        [HttpPut("{id}")]
        public IActionResult PutVendor(uint id, [FromBody] UpdateVendorDto dto)
        {
            try
            {
                bool siker = _vendorService.UpdateVendor(id, dto);
                if (siker)
                {
                    return Ok("Az árus adatai frissültek.");
                }
                return NotFound($"Nincs árus a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        // DELETE: api/Vendor/1
        [HttpDelete("{id}")]
        public IActionResult DeleteVendor(uint id)
        {
            try
            {
                bool siker = _vendorService.DeleteVendor(id);
                if (siker)
                {
                    return Ok("Az árus sikeresen törölve lett.");
                }
                return NotFound($"Nincs árus a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}
