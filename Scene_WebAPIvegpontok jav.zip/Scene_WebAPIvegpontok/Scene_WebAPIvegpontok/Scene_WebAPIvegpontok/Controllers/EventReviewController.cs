﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventReviewController : ControllerBase
    {
        private readonly EventReviewService _eventReviewService;

        public EventReviewController(EventReviewService eventReviewService)
        {
            _eventReviewService = eventReviewService;
        }

        // GET: api/EventReview
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllEventReviews()
        {
            try
            {
                List<EventReviewResponseDto> reviews = _eventReviewService.GetAllEventReviews();
                return Ok(reviews);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba történt az értékelések lekérése során: {ex.Message}");
            }
        }

        // GET: api/EventReview/GetById/1
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetEventReviewById(uint id)
        {
            try
            {
                EventReviewResponseDto? review = _eventReviewService.GetEventReviewById(id);
                if (review != null)
                {
                    return Ok(review);
                }
                return NotFound($"Nincs értékelés a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/EventReview
        [HttpPost]
        [Authorize]
        public IActionResult PostEventReview([FromBody] CreateEventReviewDto dto)
        {
            try
            {
                bool siker = _eventReviewService.CreateEventReview(dto);
                if (siker)
                {
                    return Ok("Az értékelés sikeresen létrejött.");
                }
                return BadRequest("Nem sikerült elmenteni az értékelést.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az értékelés létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/EventReview/1
        [HttpPut("{id}")]
        public IActionResult PutEventReview(uint id, [FromBody] UpdateEventReviewDto dto)
        {
            try
            {
                bool siker = _eventReviewService.UpdateEventReview(id, dto);
                if (siker)
                {
                    return Ok("Az értékelés sikeresen frissült.");
                }
                return NotFound($"Nincs értékelés a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az értékelés módosítása során: {ex.Message}");
            }
        }

        // DELETE: api/EventReview/1
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteEventReview(uint id)
        {
            try
            {
                bool siker = _eventReviewService.DeleteEventReview(id);
                if (siker)
                {
                    return Ok("Az értékelés sikeresen törölve lett.");
                }
                return NotFound($"Nincs értékelés a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az értékelés törlése során: {ex.Message}");
            }
        }
    }
}
