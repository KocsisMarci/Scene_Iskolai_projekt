﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;

        public BookingController(BookingService bookingService)
        {
            _bookingService = bookingService;
        }

        // GET: api/Booking/my-bookings (Bejelentkezett felhasználó saját foglalásai)
        [HttpGet("my-bookings")]
        public IActionResult GetMyBookings()
        {
            try
            {
                uint currentUserId = this.GetCurrentUserId();
                return Ok(_bookingService.GetBookingsByUserId(currentUserId));
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a saját foglalások lekérése során: {ex.Message}");
            }
        }

        // GET: api/Booking/event/1 (Egy adott eseményhez tartozó foglalások - Admin & Szervező)
        [HttpGet("event/{eventId}")]
        [Authorize(Roles = "Admin,Organizer")]
        public IActionResult GetBookingsByEventId(uint eventId)
        {
            try
            {
                return Ok(_bookingService.GetBookingsByEventId(eventId));
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az esemény foglalásainak lekérése során: {ex.Message}");
            }
        }

        // GET: api/Booking (Összes foglalás lekérése - Csak Admin)
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAllBookings()
        {
            try
            {
                return Ok(_bookingService.GetAllBookings());
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a foglalások lekérése során: {ex.Message}");
            }
        }

        // POST: api/Booking (Új foglalás létrehozása)
        [HttpPost]
        public IActionResult CreateBooking([FromBody] CreateBookingDto dto)
        {
            try
            {
                uint currentUserId = this.GetCurrentUserId();

                bool siker = _bookingService.CreateBooking(currentUserId, dto, out string errorMessage, out bool isDuplicate);

                if (siker)
                {
                    return Ok(new { message = "Sikeres jelentkezés az eseményre!" });
                }

                // Ha már korábban jelentkezett: 409 Conflict
                if (isDuplicate)
                {
                    return Conflict(new { message = errorMessage });
                }

                // Ha nem létezik az esemény: 400 Bad Request
                return BadRequest(new { message = errorMessage });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = $"Szerver hiba történt: {ex.Message}" });
            }
        }

        // DELETE: api/Booking/1 (Foglalás törlése - Tulajdonos vagy Admin)
        [HttpDelete("{id}")]
        public IActionResult DeleteBooking(uint id)
        {
            try
            {
                var booking = _bookingService.GetBookingById(id);
                if (booking == null) return NotFound("A foglalás nem található.");

                uint currentUserId = this.GetCurrentUserId();
                bool isAdmin = this.IsAdmin();

                // Tulajdonosi és Admin ellenőrzés
                if (!isAdmin && booking.UserId != currentUserId)
                {
                    return StatusCode(StatusCodes.Status403Forbidden, "Nincs jogosultságod más foglalásának törlésére.");
                }

                bool siker = _bookingService.DeleteBooking(id);
                if (siker) return Ok("A foglalás törölve lett.");
                return BadRequest("A törlés nem sikerült.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}