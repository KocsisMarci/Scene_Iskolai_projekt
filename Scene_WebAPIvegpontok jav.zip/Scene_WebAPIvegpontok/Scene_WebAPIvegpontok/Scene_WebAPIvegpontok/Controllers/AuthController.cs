﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthController(AuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("register")]
        [AllowAnonymous]
        public IActionResult Register([FromBody] CreateUserDto dto)
        {
            bool siker = _authService.Register(dto, out string errorMessage);
            if (!siker)
            {
                return BadRequest(errorMessage);
            }
            return Ok("Sikeres regisztráció.");
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public IActionResult Login([FromBody] LoginDto dto)
        {
            var result = _authService.Login(dto, out string errorMessage);
            if (result == null)
            {
                return Unauthorized(errorMessage);
            }
            return Ok(result);
        }

        [HttpPost("refresh-token")]
        [AllowAnonymous]
        public IActionResult RefreshToken([FromBody] RefreshTokenRequestDto dto)
        {
            var result = _authService.RefreshAccessToken(dto.RefreshToken, out string errorMessage);
            if (result == null)
            {
                return BadRequest(errorMessage);
            }
            return Ok(result);
        }

        [HttpPost("revoke-token")]
        [AllowAnonymous]
        public IActionResult RevokeToken([FromBody] RefreshTokenRequestDto dto)
        {
            bool siker = _authService.RevokeRefreshToken(dto.RefreshToken);
            if (!siker)
            {
                return NotFound("A megadott Refresh Token nem található.");
            }
            return Ok("A Refresh Token sikeresen vissza lett vonva.");
        }
    }
}
