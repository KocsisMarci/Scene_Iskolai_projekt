﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventVendorController : ControllerBase
    {
        private readonly EventVendorService _eventVendorService;

        public EventVendorController(EventVendorService eventVendorService)
        {
            _eventVendorService = eventVendorService;
        }

        // GET: api/EventVendor
        [HttpGet]
        public IActionResult GetAllEventVendors()
        {
            try
            {
                List<EventVendorResponseDto> list = _eventVendorService.GetAllEventVendors();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a hozzárendelések lekérése során: {ex.Message}");
            }
        }

        // GET: api/EventVendor/GetByIds/1/2
        [HttpGet("GetByIds/{eventId}/{vendorId}")]
        public IActionResult GetEventVendorByIds(uint eventId, uint vendorId)
        {
            try
            {
                EventVendorResponseDto? dto = _eventVendorService.GetEventVendorByIds(eventId, vendorId);
                if (dto != null)
                {
                    return Ok(dto);
                }
                return NotFound($"Nincs hozzárendelés a megadott esemény ({eventId}) és árus ({vendorId}) között.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/EventVendor
        [HttpPost]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult PostEventVendor([FromBody] CreateEventVendorDto dto)
        {
            try
            {
                bool siker = _eventVendorService.CreateEventVendor(dto);
                if (siker)
                {
                    return Ok("Az árus sikeresen hozzá lett rendelve az eseményhez.");
                }
                return BadRequest("Nem sikerült elmenteni a hozzárendelést.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a hozzárendelés létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/EventVendor/1/2
        [HttpPut("{eventId}/{vendorId}")]
        public IActionResult PutEventVendor(uint eventId, uint vendorId, [FromBody] UpdateEventVendorDto dto)
        {
            try
            {
                bool siker = _eventVendorService.UpdateEventVendor(eventId, vendorId, dto);
                if (siker)
                {
                    return Ok("A hozzárendelés adatai (helyszín) frissültek.");
                }
                return NotFound($"Nincs hozzárendelés a megadott azonosítókkal ({eventId}, {vendorId}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        // DELETE: api/EventVendor/1/2
        [HttpDelete("{eventId}/{vendorId}")]
        public IActionResult DeleteEventVendor(uint eventId, uint vendorId)
        {
            try
            {
                bool siker = _eventVendorService.DeleteEventVendor(eventId, vendorId);
                if (siker)
                {
                    return Ok("A hozzárendelés sikeresen törölve lett.");
                }
                return NotFound($"Nincs hozzárendelés a megadott azonosítókkal: {eventId}, {vendorId}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}
