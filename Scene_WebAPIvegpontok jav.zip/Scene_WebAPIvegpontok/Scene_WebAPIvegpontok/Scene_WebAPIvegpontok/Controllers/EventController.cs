﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize] // Alapértelmezetten védett controller
    public class EventController : ControllerBase
    {
        private readonly EventService _eventService;

        public EventController(EventService eventService)
        {
            _eventService = eventService;
        }

        // GET: api/Event (Nyilvános - látogatók és böngészők számára)
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllEvents()
        {
            try
            {
                List<EventResponseDto> events = _eventService.GetAllEvents();
                return Ok(events);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba történt az események lekérése során: {ex.Message}");
            }
        }

        // GET: api/Event/GetById/1 (Nyilvános)
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetEventById(uint id)
        {
            try
            {
                EventResponseDto? eventDto = _eventService.GetEventById(id);
                if (eventDto != null)
                {
                    return Ok(eventDto);
                }
                return NotFound($"Nincs esemény a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/Event (Szervező és Admin hozhat létre eseményt)
        [HttpPost]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult PostEvent([FromBody] CreateEventDto dto)
        {
            try
            {
                // Biztonsági felülírás: az esemény szervezője a bejelentkezett felhasználó lesz
                uint currentUserId = this.GetCurrentUserId();
                dto.OrganizerId = currentUserId;

                bool siker = _eventService.CreateEvent(dto);
                if (siker)
                {
                    return Ok("A rendezvény sikeresen létrejött.");
                }
                return BadRequest("Nem sikerült létrehozni a rendezvényt.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az esemény létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/Event/1 (Szervező csak a SAJÁT eseményét, Admin BÁRMELYIKET módosíthatja)
        [HttpPut("{id}")]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult PutEvent(uint id, [FromBody] UpdateEventDto dto)
        {
            try
            {
                var existingEvent = _eventService.GetEventById(id);
                if (existingEvent == null)
                {
                    return NotFound($"Nincs esemény a megadott azonosítóval: {id}");
                }

                uint currentUserId = this.GetCurrentUserId();
                bool isAdmin = this.IsAdmin();

                // Tulajdonosi ellenőrzés
                if (!isAdmin && existingEvent.OrganizerId != currentUserId)
                {
                    return StatusCode(StatusCodes.Status403Forbidden, "Nincs jogosultságod más szervező eseményének módosítására.");
                }

                bool siker = _eventService.UpdateEvent(id, dto);
                if (siker)
                {
                    return Ok("Az esemény adatai sikeresen frissültek.");
                }
                return BadRequest("Nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az esemény módosítása során: {ex.Message}");
            }
        }

        // DELETE: api/Event/1 (Szervező csak a SAJÁT eseményét, Admin BÁRMELYIKET törölheti)
        [HttpDelete("{id}")]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult DeleteEvent(uint id)
        {
            try
            {
                var existingEvent = _eventService.GetEventById(id);
                if (existingEvent == null)
                {
                    return NotFound($"Nincs esemény a megadott azonosítóval: {id}");
                }

                uint currentUserId = this.GetCurrentUserId();
                bool isAdmin = this.IsAdmin();

                // Tulajdonosi ellenőrzés
                if (!isAdmin && existingEvent.OrganizerId != currentUserId)
                {
                    return StatusCode(StatusCodes.Status403Forbidden, "Nincs jogosultságod más szervező eseményének törlésére.");
                }

                bool siker = _eventService.DeleteEvent(id);
                if (siker)
                {
                    return Ok("Az esemény sikeresen törölve lett.");
                }
                return BadRequest("Nem sikerült a törlés.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az esemény törlése során: {ex.Message}");
            }
        }
    }
}