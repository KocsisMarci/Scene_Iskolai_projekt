﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AccountController : ControllerBase
    {
        private readonly AccountService _accountService;

        public AccountController(AccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAllAccounts()
        {
            try
            {
                List<AccountResponseDto> list = _accountService.GetAllAccounts();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fiókok lekérése során: {ex.Message}");
            }
        }

        [HttpGet("GetById/{id}")]
        [Authorize]
        public IActionResult GetAccountById(uint id)
        {
            try
            {
                AccountResponseDto? dto = _accountService.GetAccountById(id);
                if (dto != null) return Ok(dto);
                return NotFound($"Nincs fiók a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        [HttpPost]
        [Authorize]
        public IActionResult PostAccount([FromBody] CreateAccountDto dto)
        {
            try
            {
                bool siker = _accountService.CreateAccount(dto);
                if (siker) return Ok("A fiók sikeresen létrejött.");
                return BadRequest("Nem sikerült elmenteni a fiókot.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fiók létrehozása során: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        [Authorize]
        public IActionResult PutAccount(uint id, [FromBody] UpdateAccountDto dto)
        {
            try
            {
                bool siker = _accountService.UpdateAccount(id, dto);
                if (siker) return Ok("A fiók adatai frissültek.");
                return NotFound($"Nincs fiók a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        [Authorize]
        public IActionResult DeleteAccount(uint id)
        {
            try
            {
                bool siker = _accountService.DeleteAccount(id);
                if (siker) return Ok("A fiók sikeresen törölve lett.");
                return NotFound($"Nincs fiók a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}