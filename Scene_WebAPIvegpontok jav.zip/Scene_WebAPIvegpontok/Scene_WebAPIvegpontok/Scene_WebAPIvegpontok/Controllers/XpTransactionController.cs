﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;
using static Scene_WebAPIvegpontok.DTOs.XpTransactionDtos;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class XpTransactionController : ControllerBase
    {
        private readonly XpTransactionService _xpTransactionService;

        public XpTransactionController(XpTransactionService xpTransactionService)
        {
            _xpTransactionService = xpTransactionService;
        }

        // GET: api/XpTransaction
        [HttpGet]
        
        public IActionResult GetAllXpTransactions()
        {
            try
            {
                List<XpTransactionResponseDto> list = _xpTransactionService.GetAllXpTransactions();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az XP tranzakciók lekérése során: {ex.Message}");
            }
        }

        // GET: api/XpTransaction/GetById/1
        [HttpGet("GetById/{id}")]
        [Authorize]
        public IActionResult GetXpTransactionById(uint id)
        {
            try
            {
                XpTransactionResponseDto? dto = _xpTransactionService.GetXpTransactionById(id);
                if (dto != null)
                {
                    return Ok(dto);
                }
                return NotFound($"Nincs XP tranzakció a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/XpTransaction
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public IActionResult PostXpTransaction([FromBody] CreateXpTransactionDto dto)
        {
            try
            {
                bool siker = _xpTransactionService.CreateXpTransaction(dto);
                if (siker)
                {
                    return Ok("Az XP tranzakció sikeresen létrejött.");
                }
                return BadRequest("Nem sikerült elmenteni az XP tranzakciót.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az XP tranzakció létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/XpTransaction/1
        [HttpPut("{id}")]
        public IActionResult PutXpTransaction(uint id, [FromBody] UpdateXpTransactionDto dto)
        {
            try
            {
                bool siker = _xpTransactionService.UpdateXpTransaction(id, dto);
                if (siker)
                {
                    return Ok("Az XP tranzakció adatai frissültek.");
                }
                return NotFound($"Nincs XP tranzakció a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        // DELETE: api/XpTransaction/1
        [HttpDelete("{id}")]
        public IActionResult DeleteXpTransaction(uint id)
        {
            try
            {
                bool siker = _xpTransactionService.DeleteXpTransaction(id);
                if (siker)
                {
                    return Ok("Az XP tranzakció sikeresen törölve lett.");
                }
                return NotFound($"Nincs XP tranzakció a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}
