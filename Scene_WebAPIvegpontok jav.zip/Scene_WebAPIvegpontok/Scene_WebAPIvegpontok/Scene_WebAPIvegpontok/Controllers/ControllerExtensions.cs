﻿using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;

namespace Scene_WebAPIvegpontok.Controllers
{
    public static class ControllerExtensions
    {
        public static uint GetCurrentUserId(this ControllerBase controller)
        {
            var claim = controller.User.FindFirst(ClaimTypes.NameIdentifier);
            return claim != null ? uint.Parse(claim.Value) : 0;
        }

        public static string GetCurrentUserRole(this ControllerBase controller)
        {
            var claim = controller.User.FindFirst(ClaimTypes.Role);
            return claim != null ? claim.Value : string.Empty;
        }

        public static bool IsAdmin(this ControllerBase controller)
        {
            return controller.GetCurrentUserRole() == "Admin";
        }
    }
}