﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;
using System;
using System.Collections.Generic;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistController : ControllerBase
    {
        private readonly ArtistService _artistService;

        public ArtistController(ArtistService artistService)
        {
            _artistService = artistService;
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllArtists()
        {
            try
            {
                List<ArtistResponseDto> list = _artistService.GetAllArtists();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a előadók lekérése során: {ex.Message}");
            }
        }

        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetArtistById(uint id)
        {
            try
            {
                ArtistResponseDto? dto = _artistService.GetArtistById(id);
                if (dto != null) return Ok(dto);
                return NotFound($"Nincs előadó a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Organizer")]
        public IActionResult PostArtist([FromBody] CreateArtistDto dto)
        {
            try
            {
                bool siker = _artistService.CreateArtist(dto);
                if (siker) return Ok("Az előadó sikeresen létrejött.");
                return BadRequest("Nem sikerült elmenteni az előadót.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba az előadó létrehozása során: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin,Organizer")]
        public IActionResult PutArtist(uint id, [FromBody] UpdateArtistDto dto)
        {
            try
            {
                bool siker = _artistService.UpdateArtist(id, dto);
                if (siker) return Ok("Az előadó adatai frissültek.");
                return NotFound($"Nincs előadó a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteArtist(uint id)
        {
            try
            {
                bool siker = _artistService.DeleteArtist(id);
                if (siker) return Ok("Az előadó sikeresen törölve lett.");
                return NotFound($"Nincs előadó a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}
