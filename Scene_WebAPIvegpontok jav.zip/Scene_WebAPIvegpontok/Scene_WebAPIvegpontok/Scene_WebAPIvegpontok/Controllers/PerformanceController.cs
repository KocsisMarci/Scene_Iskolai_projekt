﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Services;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PerformanceController : ControllerBase
    {
        private readonly PerformanceService _performanceService;

        public PerformanceController(PerformanceService performanceService)
        {
            _performanceService = performanceService;
        }

        // GET: api/Performance
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetAllPerformances()
        {
            try
            {
                List<PerformanceResponseDto> list = _performanceService.GetAllPerformances();
                return Ok(list);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fellépések lekérése során: {ex.Message}");
            }
        }

        // GET: api/Performance/GetById/1
        [HttpGet("GetById/{id}")]
        [AllowAnonymous]
        public IActionResult GetPerformanceById(uint id)
        {
            try
            {
                PerformanceResponseDto? dto = _performanceService.GetPerformanceById(id);
                if (dto != null)
                {
                    return Ok(dto);
                }
                return NotFound($"Nincs fellépés a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/Performance
        [HttpPost]
        [Authorize(Roles = "Organizer,Admin")]
        public IActionResult PostPerformance([FromBody] CreatePerformanceDto dto)
        {
            try
            {
                bool siker = _performanceService.CreatePerformance(dto);
                if (siker)
                {
                    return Ok("A fellépés sikeresen létrejött.");
                }
                return BadRequest("Nem sikerült elmenteni a fellépést.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fellépés létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/Performance/1
        [HttpPut("{id}")]
        public IActionResult PutPerformance(uint id, [FromBody] UpdatePerformanceDto dto)
        {
            try
            {
                bool siker = _performanceService.UpdatePerformance(id, dto);
                if (siker)
                {
                    return Ok("A fellépés adatai frissültek.");
                }
                return NotFound($"Nincs fellépés a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a módosítás során: {ex.Message}");
            }
        }

        // DELETE: api/Performance/1
        [HttpDelete("{id}")]
        public IActionResult DeletePerformance(uint id)
        {
            try
            {
                bool siker = _performanceService.DeletePerformance(id);
                if (siker)
                {
                    return Ok("A fellépés sikeresen törölve lett.");
                }
                return NotFound($"Nincs fellépés a megadott azonosítóval: {id}");
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a törlés során: {ex.Message}");
            }
        }
    }
}
