﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Scene_WebAPIvegpontok
{
    public class SwaggerTagOrderFilter : IDocumentFilter
    {
        public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {
            // Meghatározzuk a controllerek kívánt sorrendjét
            var preferredOrder = new List<string> {
                                        "Account",
                                        "User",
                                        "Artist",
                                        "Vendor",
                                        "Event",
                                        "Performance",
                                        "EventVendor",
                                        "Booking",
                                        "EventPhoto",
                                        "EventReview",
                                        "XpTransaction"
                                    };

            if (swaggerDoc.Tags != null)
            {
                swaggerDoc.Tags = swaggerDoc.Tags
                    .OrderBy(tag =>
                    {
                        int index = preferredOrder.IndexOf(tag.Name);
                        // Ha olyan controller lenne, ami nincs a listában, az a végére kerül
                        return index == -1 ? int.MaxValue : index;
                    })
                    .ToList();
            }
        }
    }
}
