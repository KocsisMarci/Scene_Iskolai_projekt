﻿namespace Scene_WebAPIvegpontok.Models
{
    public class Account
    {
        public uint AccountId { get; set; }
        public string AccountName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string? DisplayName { get; set; }
    }
}
