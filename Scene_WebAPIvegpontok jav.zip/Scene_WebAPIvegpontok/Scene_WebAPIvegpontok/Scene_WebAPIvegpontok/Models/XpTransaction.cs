﻿namespace Scene_WebAPIvegpontok.Models
{
    public class XpTransaction
    {
        public uint TransactionId { get; set; }
        public uint UserId { get; set; }
        public int Amount { get; set; }
        public string Reason { get; set; } = null!;
        public uint? ReferenceId { get; set; }
        public DateTime CreatedAt { get; set; }

        public virtual User User { get; set; } = null!;
    }
}
