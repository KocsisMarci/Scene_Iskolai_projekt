﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class Performance
    {
        public uint PerformanceId { get; set; }
        public uint EventId { get; set; }
        public uint ArtistId { get; set; }
        public string? StageName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        public virtual Event Event { get; set; } = null!;
        public virtual Artist Artist { get; set; } = null!;
    }
}
