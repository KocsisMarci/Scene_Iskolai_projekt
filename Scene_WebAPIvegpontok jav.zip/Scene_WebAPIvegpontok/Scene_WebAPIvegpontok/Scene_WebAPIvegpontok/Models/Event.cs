﻿namespace Scene_WebAPIvegpontok.Models
{
    public class Event
    {
        public uint EventId { get; set; }
        public string Name { get; set; } = null!;
        public string? Description { get; set; }
        public string? Location { get; set; }
        public uint OrganizerId { get; set; }
        public virtual User? Organizer { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? Category { get; set; }
        public string? CoverImageUrl { get; set; }
        public uint? MaxCapacity { get; set; }
        public string Status { get; set; } = "Published";
        public uint? CreatedByUserId { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public virtual User? CreatedByUser { get; set; }
        public virtual ICollection<Performance> Performances { get; set; } = new List<Performance>();
        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
        public virtual ICollection<EventVendor> EventVendors { get; set; } = new List<EventVendor>();
        public virtual ICollection<EventPhoto> EventPhotos { get; set; } = new List<EventPhoto>();
        public virtual ICollection<EventReview> EventReviews { get; set; } = new List<EventReview>();
    }
}
