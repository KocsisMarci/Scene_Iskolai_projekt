﻿namespace Scene_WebAPIvegpontok.Models
{
    public class Vendor
    {
        public uint VendorId { get; set; }
        public string Name { get; set; } = null!;
        public string? VendorType { get; set; }
        public string? Description { get; set; }
        public string? ContactEmail { get; set; }
        public string? ContactPhone { get; set; }
        public string? ImageUrl { get; set; }

        public virtual ICollection<EventVendor> EventVendors { get; set; } = new List<EventVendor>();
    }
}
