﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class EventPhoto
    {
        public uint PhotoId { get; set; }
        public uint UserId { get; set; }
        public uint EventId { get; set; }
        public string ImageUrl { get; set; } = string.Empty;
        public int XPAwarded { get; set; } = 0;
        public string Status { get; set; } = "Pending";
        public DateTime UploadedAt { get; set; } = DateTime.Now;

        // Navigációs tulajdonságok az EF Core-hoz
        public virtual User? User { get; set; }
        public virtual Event? Event { get; set; }
    }
}
