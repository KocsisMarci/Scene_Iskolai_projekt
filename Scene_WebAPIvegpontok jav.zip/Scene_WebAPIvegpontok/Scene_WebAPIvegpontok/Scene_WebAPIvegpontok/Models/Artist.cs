﻿namespace Scene_WebAPIvegpontok.Models
{
    public class Artist
    {
        public uint ArtistId { get; set; }
        public string Name { get; set; } = null!;
        public string? Bio { get; set; }
        public string? ImageUrl { get; set; }
        public string? SocialLinks { get; set; }
        public string Genre { get; set; } = "Other";

        public virtual ICollection<Performance> Performances { get; set; } = new List<Performance>();
    }
}
