﻿using System;

namespace Scene_WebAPIvegpontok.Models
{
    public class RefreshToken
    {
        public uint RefreshTokenId { get; set; }
        public uint UserId { get; set; }
        public string Token { get; set; } = string.Empty;
        public DateTime ExpiresAt { get; set; }
        public bool IsRevoked { get; set; } = false;
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Navigációs tulajdonság a felhasználóhoz
        public virtual User User { get; set; } = null!;
    }
}
