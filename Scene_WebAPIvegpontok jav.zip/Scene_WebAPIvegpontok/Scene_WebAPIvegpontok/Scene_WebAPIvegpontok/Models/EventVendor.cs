﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class EventVendor
    {
        public uint EventId { get; set; }
        public uint VendorId { get; set; }
        public string? SpotLabel { get; set; }

        public virtual Event Event { get; set; } = null!;
        public virtual Vendor Vendor { get; set; } = null!;
    }
}
