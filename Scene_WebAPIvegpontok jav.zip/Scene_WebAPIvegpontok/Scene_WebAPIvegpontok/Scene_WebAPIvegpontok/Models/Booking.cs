﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class Booking
    {
        public uint BookingId { get; set; }
        public uint UserId { get; set; }
        public uint EventId { get; set; }
        public string Status { get; set; } = "Going";
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Navigációs tulajdonságok az EF Core relációkhoz
        public virtual User? User { get; set; }
        public virtual Event? Event { get; set; }
    }
}
