﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class User
    {
        public uint UserId { get; set; }
        public string Username { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string? DisplayName { get; set; }
        public uint AvatarLevel { get; set; } = 1;
        public uint CurrentXP { get; set; } = 0;
        public string? AvatarImageUrl { get; set; }
        public string? Bio { get; set; }
        public string Role { get; set; } = "User";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public virtual ICollection<Account> Accounts { get; set; } = new List<Account>();
        public virtual ICollection<Event> CreatedEvents { get; set; } = new List<Event>();
        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
        public virtual ICollection<EventPhoto> EventPhotos { get; set; } = new List<EventPhoto>();
        public virtual ICollection<XpTransaction> XpTransactions { get; set; } = new List<XpTransaction>();
        public virtual ICollection<EventReview> EventReviews { get; set; } = new List<EventReview>();
        public virtual ICollection<RefreshToken> RefreshTokens { get; set; } = new List<RefreshToken>();
    }
}
