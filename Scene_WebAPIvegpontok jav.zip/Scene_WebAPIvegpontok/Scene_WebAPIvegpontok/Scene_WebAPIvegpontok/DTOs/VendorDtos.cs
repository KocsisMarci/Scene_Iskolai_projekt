﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    // Ezt küldi a frontend új árus/szolgáltató regisztrációjakor
    public class CreateVendorDto
    {
        public string Name { get; set; } = string.Empty;
        public string? VendorType { get; set; }
        public string? Description { get; set; }
        public string? ContactEmail { get; set; }
        public string? ContactPhone { get; set; }
        public string? ImageUrl { get; set; }
    }

    // Ezt küldi a frontend az árus adatainak módosításakor
    public class UpdateVendorDto
    {
        public string Name { get; set; } = string.Empty;
        public string? VendorType { get; set; }
        public string? Description { get; set; }
        public string? ContactEmail { get; set; }
        public string? ContactPhone { get; set; }
        public string? ImageUrl { get; set; }
    }

    // Ezt kapja vissza a frontend az árusok lekérésekor
    public class VendorResponseDto
    {
        public uint VendorId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? VendorType { get; set; }
        public string? Description { get; set; }
        public string? ContactEmail { get; set; }
        public string? ContactPhone { get; set; }
        public string? ImageUrl { get; set; }
    }
}
