﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    public class CreateEventReviewDto
    {
        public uint EventId { get; set; }
        public uint UserId { get; set; }
        public byte Rating { get; set; }
        public string? Comment { get; set; }
    }

    // Ezt küldi a felhasználó az értékelése frissítésekor
    public class UpdateEventReviewDto
    {
        public byte Rating { get; set; }
        public string? Comment { get; set; }
    }

    // Ezt kapja vissza a frontend az értékelések lekérésekor
    public class EventReviewResponseDto
    {
        public uint ReviewId { get; set; }
        public uint EventId { get; set; }
        public string? EventName { get; set; }
        public uint UserId { get; set; }
        public string? Username { get; set; }
        public byte Rating { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
