﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    // Ezt küldi a frontend, amikor egy árust/szolgáltatót egy eseményhez rendelnek
    public class CreateEventVendorDto
    {
        public uint EventId { get; set; }
        public uint VendorId { get; set; }
        public string? SpotLabel { get; set; }
    }

    // Ezt küldi a frontend a helyszíni azonosító (SpotLabel) módosításakor
    public class UpdateEventVendorDto
    {
        public string? SpotLabel { get; set; }
    }

    // Ezt kapja vissza a frontend a lekérdezésekkor
    public class EventVendorResponseDto
    {
        public uint EventId { get; set; }
        public string? EventName { get; set; }
        public uint VendorId { get; set; }
        public string? VendorName { get; set; }
        public string? SpotLabel { get; set; }
    }
}
