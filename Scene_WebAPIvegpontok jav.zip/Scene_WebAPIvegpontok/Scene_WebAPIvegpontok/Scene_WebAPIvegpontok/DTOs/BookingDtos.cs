﻿using System;
using System.Text.Json.Serialization;

namespace Scene_WebAPIvegpontok.DTOs
{
    // Ezt küldi a frontend POST kéréskor (Új foglalás)
    public class CreateBookingDto
    {
        [JsonIgnore] // Elrejti a Swaggerben és a JSON törzsben
        public uint UserId { get; set; }

        public uint EventId { get; set; }
        public string Status { get; set; } = "Going";
    }

    // Ezt küldi a frontend PUT kéréskor (Módosítás)
    public class UpdateBookingDto
    {
        public string Status { get; set; } = "Going";
    }

    // Ezt kapja vissza a frontend GET kéréskor (Válasz objektum)
    public class BookingResponseDto
    {
        public uint BookingId { get; set; }
        public uint UserId { get; set; }
        public string? Username { get; set; }
        public uint EventId { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}