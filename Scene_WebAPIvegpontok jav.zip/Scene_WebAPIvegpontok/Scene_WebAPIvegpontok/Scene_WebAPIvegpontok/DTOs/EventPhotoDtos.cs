﻿namespace Scene_WebAPIvegpontok.DTOs
{
    public class EventPhotoDtos
    {
        public class CreateEventPhotoDto
        {
            public uint UserId { get; set; }
            public uint EventId { get; set; }
            public string ImageUrl { get; set; } = string.Empty;
        }

        // Adminisztrátori jóváhagyáskor/XP jóváírásakor használt DTO
        public class UpdateEventPhotoDto
        {
            public int XPAwarded { get; set; }
            public string Status { get; set; } = "Approved";
        }

        // A frontend ezt kapja vissza a képek lekérésekor
        public class EventPhotoResponseDto
        {
            public uint PhotoId { get; set; }
            public uint UserId { get; set; }
            public string? Username { get; set; }
            public uint EventId { get; set; }
            public string ImageUrl { get; set; } = string.Empty;
            public int XPAwarded { get; set; }
            public string Status { get; set; } = string.Empty;
            public DateTime UploadedAt { get; set; }
        }
    }
}
