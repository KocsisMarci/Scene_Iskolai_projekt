﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    public class XpTransactionDtos
    {
        // Ezt küldi a rendszer / admin, amikor XP-t ír jóvá vagy von le
        public class CreateXpTransactionDto
        {
            public uint UserId { get; set; }
            public int Amount { get; set; }
            public string Reason { get; set; } = string.Empty;
            public uint? ReferenceId { get; set; }
        }

        // Ezt küldi a frontend korrekció vagy módosítás esetén
        public class UpdateXpTransactionDto
        {
            public int Amount { get; set; }
            public string Reason { get; set; } = string.Empty;
            public uint? ReferenceId { get; set; }
        }

        // Ezt kapja vissza a frontend az XP tranzakciók lekérésekor
        public class XpTransactionResponseDto
        {
            public uint TransactionId { get; set; }
            public uint UserId { get; set; }
            public string? Username { get; set; }
            public int Amount { get; set; }
            public string Reason { get; set; } = string.Empty;
            public uint? ReferenceId { get; set; }
            public DateTime CreatedAt { get; set; }
        }
    }
}
