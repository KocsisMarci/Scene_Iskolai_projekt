﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    public class CreateArtistDto
    {
        public string Name { get; set; } = string.Empty;
        public string? Bio { get; set; }
        public string? ImageUrl { get; set; }
        public string? SocialLinks { get; set; }
        public string Genre { get; set; } = "Other";
    }

    public class UpdateArtistDto
    {
        public string Name { get; set; } = string.Empty;
        public string? Bio { get; set; }
        public string? ImageUrl { get; set; }
        public string? SocialLinks { get; set; }
        public string Genre { get; set; } = "Other";
    }

    public class ArtistResponseDto
    {
        public uint ArtistId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Bio { get; set; }
        public string? ImageUrl { get; set; }
        public string? SocialLinks { get; set; }
        public string Genre { get; set; } = string.Empty;
    }
}
