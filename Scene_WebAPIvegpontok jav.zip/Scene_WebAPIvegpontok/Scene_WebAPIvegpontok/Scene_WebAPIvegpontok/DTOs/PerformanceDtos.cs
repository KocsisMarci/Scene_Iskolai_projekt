﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    public class CreatePerformanceDto
    {
        public uint EventId { get; set; }
        public uint ArtistId { get; set; }
        public string? StageName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }

    // Ezt küldi a frontend az időpont vagy színpad módosításakor
    public class UpdatePerformanceDto
    {
        public string? StageName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }

    // Ezt kapja vissza a frontend a műsorrend lekérésekor
    public class PerformanceResponseDto
    {
        public uint PerformanceId { get; set; }
        public uint EventId { get; set; }
        public string? EventName { get; set; }
        public uint ArtistId { get; set; }
        public string? ArtistName { get; set; }
        public string? StageName { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
    }
}
