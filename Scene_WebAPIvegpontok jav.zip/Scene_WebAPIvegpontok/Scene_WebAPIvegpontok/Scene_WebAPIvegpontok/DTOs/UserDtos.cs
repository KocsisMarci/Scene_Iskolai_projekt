﻿using System;

namespace Scene_WebAPIvegpontok.DTOs
{
    // Új felhasználó regisztrációja / létrehozása
    public class CreateUserDto
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string? DisplayName { get; set; }
        public string? AvatarImageUrl { get; set; }
        public string? Bio { get; set; }
        public string Role { get; set; } = "User";
    }

    // Profil adatok frissítése
    public class UpdateUserDto
    {
        public string Email { get; set; } = string.Empty;
        public string? DisplayName { get; set; }
        public string? AvatarImageUrl { get; set; }
        public string? Bio { get; set; }
        public uint AvatarLevel { get; set; } = 1;
        public uint CurrentXP { get; set; } = 0;
        public string Role { get; set; } = "User";
        public bool IsActive { get; set; } = true;
    }

    // A külvilág felé visszaadott adat (A jelszó hash rejtve marad)
    public class UserResponseDto
    {
        public uint UserId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? DisplayName { get; set; }
        public uint AvatarLevel { get; set; }
        public uint CurrentXP { get; set; }
        public string? AvatarImageUrl { get; set; }
        public string? Bio { get; set; }
        public string Role { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
    }
}
