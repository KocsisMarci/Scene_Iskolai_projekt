﻿using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using static Scene_WebAPIvegpontok.DTOs.EventPhotoDtos;

namespace Scene_WebAPIvegpontok.Services
{
    public class EventPhotoService
    {
        private readonly SceneContext _context;

        public EventPhotoService(SceneContext context)
        {
            _context = context;
        }

        public List<EventPhotoResponseDto> GetAllEventPhotos()
        {
            return _context.EventPhotos
                .Include(p => p.User)
                .Select(p => new EventPhotoResponseDto
                {
                    PhotoId = p.PhotoId,
                    UserId = p.UserId,
                    Username = p.User != null ? p.User.Username : null,
                    EventId = p.EventId,
                    ImageUrl = p.ImageUrl,
                    XPAwarded = p.XPAwarded,
                    Status = p.Status,
                    UploadedAt = p.UploadedAt
                })
                .ToList();
        }

        public EventPhotoResponseDto? GetEventPhotoById(uint id)
        {
            return _context.EventPhotos
                .Include(p => p.User)
                .Where(p => p.PhotoId == id)
                .Select(p => new EventPhotoResponseDto
                {
                    PhotoId = p.PhotoId,
                    UserId = p.UserId,
                    Username = p.User != null ? p.User.Username : null,
                    EventId = p.EventId,
                    ImageUrl = p.ImageUrl,
                    XPAwarded = p.XPAwarded,
                    Status = p.Status,
                    UploadedAt = p.UploadedAt
                })
                .FirstOrDefault();
        }

        public bool CreateEventPhoto(CreateEventPhotoDto dto)
        {
            var eventPhoto = new EventPhoto
            {
                UserId = dto.UserId,
                EventId = dto.EventId,
                ImageUrl = dto.ImageUrl,
                XPAwarded = 0,
                Status = "Pending",
                UploadedAt = DateTime.Now
            };

            _context.EventPhotos.Add(eventPhoto);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateEventPhoto(uint id, UpdateEventPhotoDto dto)
        {
            var existingPhoto = _context.EventPhotos.FirstOrDefault(p => p.PhotoId == id);
            if (existingPhoto == null)
            {
                return false;
            }

            existingPhoto.XPAwarded = dto.XPAwarded;
            existingPhoto.Status = dto.Status;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteEventPhoto(uint id)
        {
            var photo = _context.EventPhotos.FirstOrDefault(p => p.PhotoId == id);
            if (photo == null)
            {
                return false;
            }

            _context.EventPhotos.Remove(photo);
            return _context.SaveChanges() > 0;
        }
    }
}
