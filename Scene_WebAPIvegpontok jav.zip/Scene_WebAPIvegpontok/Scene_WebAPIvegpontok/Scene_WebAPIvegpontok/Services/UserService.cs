﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class UserService
    {
        private readonly SceneContext _context;

        public UserService(SceneContext context)
        {
            _context = context;
        }

        public List<UserResponseDto> GetAllUsers()
        {
            return _context.Users
                .Select(u => new UserResponseDto
                {
                    UserId = u.UserId,
                    Username = u.Username,
                    Email = u.Email,
                    DisplayName = u.DisplayName,
                    AvatarLevel = u.AvatarLevel,
                    CurrentXP = u.CurrentXP,
                    AvatarImageUrl = u.AvatarImageUrl,
                    Bio = u.Bio,
                    Role = u.Role,
                    IsActive = u.IsActive,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt
                })
                .ToList();
        }

        public UserResponseDto? GetUserById(uint id)
        {
            return _context.Users
                .Where(u => u.UserId == id)
                .Select(u => new UserResponseDto
                {
                    UserId = u.UserId,
                    Username = u.Username,
                    Email = u.Email,
                    DisplayName = u.DisplayName,
                    AvatarLevel = u.AvatarLevel,
                    CurrentXP = u.CurrentXP,
                    AvatarImageUrl = u.AvatarImageUrl,
                    Bio = u.Bio,
                    Role = u.Role,
                    IsActive = u.IsActive,
                    CreatedAt = u.CreatedAt,
                    UpdatedAt = u.UpdatedAt
                })
                .FirstOrDefault();
        }

        public bool CreateUser(CreateUserDto dto)
        {
            var now = DateTime.Now;
            var user = new User
            {
                Username = dto.Username,
                Email = dto.Email,
                PasswordHash = dto.Password, // Éles környezetben hash-elendő!
                DisplayName = dto.DisplayName,
                AvatarImageUrl = dto.AvatarImageUrl,
                Bio = dto.Bio,
                Role = dto.Role,
                AvatarLevel = 1,
                CurrentXP = 0,
                IsActive = true,
                CreatedAt = now,
                UpdatedAt = now
            };

            _context.Users.Add(user);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateUser(uint id, UpdateUserDto dto)
        {
            var existing = _context.Users.FirstOrDefault(u => u.UserId == id);
            if (existing == null) return false;

            existing.Email = dto.Email;
            existing.DisplayName = dto.DisplayName;
            existing.AvatarImageUrl = dto.AvatarImageUrl;
            existing.Bio = dto.Bio;
            existing.AvatarLevel = dto.AvatarLevel;
            existing.CurrentXP = dto.CurrentXP;
            existing.Role = dto.Role;
            existing.IsActive = dto.IsActive;
            existing.UpdatedAt = DateTime.Now;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteUser(uint id)
        {
            var existing = _context.Users.FirstOrDefault(u => u.UserId == id);
            if (existing == null) return false;

            _context.Users.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
