﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class EventVendorService
    {
        private readonly SceneContext _context;

        public EventVendorService(SceneContext context)
        {
            _context = context;
        }

        public List<EventVendorResponseDto> GetAllEventVendors()
        {
            return _context.EventVendors
                .Include(ev => ev.Event)
                .Include(ev => ev.Vendor)
                .Select(ev => new EventVendorResponseDto
                {
                    EventId = ev.EventId,
                    EventName = ev.Event != null ? ev.Event.Name : null,
                    VendorId = ev.VendorId,
                    VendorName = ev.Vendor != null ? ev.Vendor.Name : null,
                    SpotLabel = ev.SpotLabel
                })
                .ToList();
        }

        public EventVendorResponseDto? GetEventVendorByIds(uint eventId, uint vendorId)
        {
            return _context.EventVendors
                .Include(ev => ev.Event)
                .Include(ev => ev.Vendor)
                .Where(ev => ev.EventId == eventId && ev.VendorId == vendorId)
                .Select(ev => new EventVendorResponseDto
                {
                    EventId = ev.EventId,
                    EventName = ev.Event != null ? ev.Event.Name : null,
                    VendorId = ev.VendorId,
                    VendorName = ev.Vendor != null ? ev.Vendor.Name : null,
                    SpotLabel = ev.SpotLabel
                })
                .FirstOrDefault();
        }

        public bool CreateEventVendor(CreateEventVendorDto dto)
        {
            var eventVendor = new EventVendor
            {
                EventId = dto.EventId,
                VendorId = dto.VendorId,
                SpotLabel = dto.SpotLabel
            };

            _context.EventVendors.Add(eventVendor);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateEventVendor(uint eventId, uint vendorId, UpdateEventVendorDto dto)
        {
            var existing = _context.EventVendors
                .FirstOrDefault(ev => ev.EventId == eventId && ev.VendorId == vendorId);

            if (existing == null)
            {
                return false;
            }

            existing.SpotLabel = dto.SpotLabel;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteEventVendor(uint eventId, uint vendorId)
        {
            var existing = _context.EventVendors
                .FirstOrDefault(ev => ev.EventId == eventId && ev.VendorId == vendorId);

            if (existing == null)
            {
                return false;
            }

            _context.EventVendors.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
