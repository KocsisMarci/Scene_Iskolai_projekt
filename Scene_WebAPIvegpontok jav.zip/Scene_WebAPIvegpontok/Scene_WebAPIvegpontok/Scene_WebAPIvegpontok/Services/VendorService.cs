﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class VendorService
    {
        private readonly SceneContext _context;

        public VendorService(SceneContext context)
        {
            _context = context;
        }

        public List<VendorResponseDto> GetAllVendors()
        {
            return _context.Vendors
                .Select(v => new VendorResponseDto
                {
                    VendorId = v.VendorId,
                    Name = v.Name,
                    VendorType = v.VendorType,
                    Description = v.Description,
                    ContactEmail = v.ContactEmail,
                    ContactPhone = v.ContactPhone,
                    ImageUrl = v.ImageUrl
                })
                .ToList();
        }

        public VendorResponseDto? GetVendorById(uint id)
        {
            return _context.Vendors
                .Where(v => v.VendorId == id)
                .Select(v => new VendorResponseDto
                {
                    VendorId = v.VendorId,
                    Name = v.Name,
                    VendorType = v.VendorType,
                    Description = v.Description,
                    ContactEmail = v.ContactEmail,
                    ContactPhone = v.ContactPhone,
                    ImageUrl = v.ImageUrl
                })
                .FirstOrDefault();
        }

        public bool CreateVendor(CreateVendorDto dto)
        {
            var vendor = new Vendor
            {
                Name = dto.Name,
                VendorType = dto.VendorType,
                Description = dto.Description,
                ContactEmail = dto.ContactEmail,
                ContactPhone = dto.ContactPhone,
                ImageUrl = dto.ImageUrl
            };

            _context.Vendors.Add(vendor);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateVendor(uint id, UpdateVendorDto dto)
        {
            var existing = _context.Vendors.FirstOrDefault(v => v.VendorId == id);
            if (existing == null)
            {
                return false;
            }

            existing.Name = dto.Name;
            existing.VendorType = dto.VendorType;
            existing.Description = dto.Description;
            existing.ContactEmail = dto.ContactEmail;
            existing.ContactPhone = dto.ContactPhone;
            existing.ImageUrl = dto.ImageUrl;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteVendor(uint id)
        {
            var existing = _context.Vendors.FirstOrDefault(v => v.VendorId == id);
            if (existing == null)
            {
                return false;
            }

            _context.Vendors.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
