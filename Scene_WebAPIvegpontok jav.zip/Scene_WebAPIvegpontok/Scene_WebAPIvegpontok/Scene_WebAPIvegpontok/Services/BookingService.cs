﻿using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Scene_WebAPIvegpontok.Services
{
    public class BookingService
    {
        private readonly SceneContext _context;

        public BookingService(SceneContext context)
        {
            _context = context;
        }

        public List<BookingResponseDto> GetAllBookings()
        {
            return _context.Bookings
                .Include(b => b.User)
                .Select(b => new BookingResponseDto
                {
                    BookingId = b.BookingId,
                    UserId = b.UserId,
                    Username = b.User != null ? b.User.Username : null,
                    EventId = b.EventId,
                    Status = b.Status,
                    CreatedAt = b.CreatedAt
                })
                .ToList();
        }

        public BookingResponseDto? GetBookingById(uint id)
        {
            return _context.Bookings
                .Include(b => b.User)
                .Where(b => b.BookingId == id)
                .Select(b => new BookingResponseDto
                {
                    BookingId = b.BookingId,
                    UserId = b.UserId,
                    Username = b.User != null ? b.User.Username : null,
                    EventId = b.EventId,
                    Status = b.Status,
                    CreatedAt = b.CreatedAt
                })
                .FirstOrDefault();
        }

        public List<BookingResponseDto> GetBookingsByUserId(uint userId)
        {
            return _context.Bookings
                .Include(b => b.User)
                .Where(b => b.UserId == userId)
                .Select(b => new BookingResponseDto
                {
                    BookingId = b.BookingId,
                    UserId = b.UserId,
                    Username = b.User != null ? b.User.Username : null,
                    EventId = b.EventId,
                    Status = b.Status,
                    CreatedAt = b.CreatedAt
                })
                .ToList();
        }

        // ÚJ: Esemény azonosító alapján történő lekérdezés (Szervezőknek / Adminnak)
        public List<BookingResponseDto> GetBookingsByEventId(uint eventId)
        {
            return _context.Bookings
                .Include(b => b.User)
                .Where(b => b.EventId == eventId)
                .Select(b => new BookingResponseDto
                {
                    BookingId = b.BookingId,
                    UserId = b.UserId,
                    Username = b.User != null ? b.User.Username : null,
                    EventId = b.EventId,
                    Status = b.Status,
                    CreatedAt = b.CreatedAt
                })
                .ToList();
        }

        public bool CreateBooking(uint userId, CreateBookingDto dto, out string errorMessage, out bool isDuplicate)
        {
            errorMessage = string.Empty;
            isDuplicate = false;

            // 1. Esemény létezésének ellenőrzése
            var eventExists = _context.Events.Any(e => e.EventId == dto.EventId);
            if (!eventExists)
            {
                errorMessage = "A megadott esemény nem található.";
                return false;
            }

            // 2. Duplikált jelentkezés megelőzése
            var alreadyBooked = _context.Bookings.Any(b => b.UserId == userId && b.EventId == dto.EventId);
            if (alreadyBooked)
            {
                isDuplicate = true;
                errorMessage = "Erre az eseményre már regisztráltál korábban!";
                return false;
            }

            // 3. Mentés az adatbázisba
            var booking = new Booking
            {
                UserId = userId,
                EventId = dto.EventId,
                Status = string.IsNullOrEmpty(dto.Status) ? "Going" : dto.Status,
                CreatedAt = DateTime.UtcNow
            };

            _context.Bookings.Add(booking);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateBooking(uint id, UpdateBookingDto dto)
        {
            var existingBooking = _context.Bookings.FirstOrDefault(b => b.BookingId == id);
            if (existingBooking == null)
            {
                return false;
            }

            existingBooking.Status = dto.Status;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteBooking(uint id)
        {
            var booking = _context.Bookings.FirstOrDefault(b => b.BookingId == id);
            if (booking == null)
            {
                return false;
            }

            _context.Bookings.Remove(booking);
            return _context.SaveChanges() > 0;
        }
    }
}