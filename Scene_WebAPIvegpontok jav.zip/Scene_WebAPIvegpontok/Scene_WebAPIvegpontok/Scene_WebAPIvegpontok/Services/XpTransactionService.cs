﻿using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using static Scene_WebAPIvegpontok.DTOs.XpTransactionDtos;

namespace Scene_WebAPIvegpontok.Services
{
    public class XpTransactionService
    {
        private readonly SceneContext _context;

        public XpTransactionService(SceneContext context)
        {
            _context = context;
        }

        public List<XpTransactionResponseDto> GetAllXpTransactions()
        {
            return _context.XpTransactions
                .Include(x => x.User)
                .Select(x => new XpTransactionResponseDto
                {
                    TransactionId = x.TransactionId,
                    UserId = x.UserId,
                    Username = x.User != null ? x.User.Username : null,
                    Amount = x.Amount,
                    Reason = x.Reason,
                    ReferenceId = x.ReferenceId,
                    CreatedAt = x.CreatedAt
                })
                .ToList();
        }

        public XpTransactionResponseDto? GetXpTransactionById(uint id)
        {
            return _context.XpTransactions
                .Include(x => x.User)
                .Where(x => x.TransactionId == id)
                .Select(x => new XpTransactionResponseDto
                {
                    TransactionId = x.TransactionId,
                    UserId = x.UserId,
                    Username = x.User != null ? x.User.Username : null,
                    Amount = x.Amount,
                    Reason = x.Reason,
                    ReferenceId = x.ReferenceId,
                    CreatedAt = x.CreatedAt
                })
                .FirstOrDefault();
        }

        public bool CreateXpTransaction(CreateXpTransactionDto dto)
        {
            var transaction = new XpTransaction
            {
                UserId = dto.UserId,
                Amount = dto.Amount,
                Reason = dto.Reason,
                ReferenceId = dto.ReferenceId,
                CreatedAt = DateTime.Now
            };

            _context.XpTransactions.Add(transaction);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateXpTransaction(uint id, UpdateXpTransactionDto dto)
        {
            var existing = _context.XpTransactions.FirstOrDefault(x => x.TransactionId == id);
            if (existing == null)
            {
                return false;
            }

            existing.Amount = dto.Amount;
            existing.Reason = dto.Reason;
            existing.ReferenceId = dto.ReferenceId;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteXpTransaction(uint id)
        {
            var existing = _context.XpTransactions.FirstOrDefault(x => x.TransactionId == id);
            if (existing == null)
            {
                return false;
            }

            _context.XpTransactions.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
