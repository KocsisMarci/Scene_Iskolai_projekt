﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class AccountService
    {
        private readonly SceneContext _context;

        public AccountService(SceneContext context)
        {
            _context = context;
        }

        public List<AccountResponseDto> GetAllAccounts()
        {
            return _context.Accounts
                .Select(a => new AccountResponseDto
                {
                    AccountId = a.AccountId,
                    AccountName = a.AccountName,
                    Email = a.Email,
                    DisplayName = a.DisplayName
                })
                .ToList();
        }

        public AccountResponseDto? GetAccountById(uint id)
        {
            return _context.Accounts
                .Where(a => a.AccountId == id)
                .Select(a => new AccountResponseDto
                {
                    AccountId = a.AccountId,
                    AccountName = a.AccountName,
                    Email = a.Email,
                    DisplayName = a.DisplayName
                })
                .FirstOrDefault();
        }

        public bool CreateAccount(CreateAccountDto dto)
        {
            var account = new Account
            {
                AccountName = dto.AccountName,
                Email = dto.Email,
                PasswordHash = dto.Password,
                DisplayName = dto.DisplayName
            };

            _context.Accounts.Add(account);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateAccount(uint id, UpdateAccountDto dto)
        {
            var existing = _context.Accounts.FirstOrDefault(a => a.AccountId == id);
            if (existing == null) return false;

            existing.AccountName = dto.AccountName;
            existing.Email = dto.Email;
            existing.DisplayName = dto.DisplayName;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteAccount(uint id)
        {
            var existing = _context.Accounts.FirstOrDefault(a => a.AccountId == id);
            if (existing == null) return false;

            _context.Accounts.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
