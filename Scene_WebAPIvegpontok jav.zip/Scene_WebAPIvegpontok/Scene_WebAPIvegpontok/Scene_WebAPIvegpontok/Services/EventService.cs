﻿using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Scene_WebAPIvegpontok.Services
{
    public class EventService
    {
        private readonly SceneContext _context;

        public EventService(SceneContext context)
        {
            _context = context;
        }

        public List<EventResponseDto> GetAllEvents()
        {
            return _context.Events
                .Select(e => new EventResponseDto
                {
                    EventId = e.EventId,
                    Name = e.Name,
                    Description = e.Description,
                    Location = e.Location,
                    OrganizerId = e.OrganizerId,
                    StartDate = e.StartDate,
                    EndDate = e.EndDate,
                    Category = e.Category,
                    Status = e.Status,
                    CoverImageUrl = e.CoverImageUrl
                })
                .ToList();
        }

        public EventResponseDto? GetEventById(uint id)
        {
            return _context.Events
                .Where(e => e.EventId == id)
                .Select(e => new EventResponseDto
                {
                    EventId = e.EventId,
                    Name = e.Name,
                    Description = e.Description,
                    Location = e.Location,
                    OrganizerId = e.OrganizerId,
                    StartDate = e.StartDate,
                    EndDate = e.EndDate,
                    Category = e.Category,
                    Status = e.Status,
                    CoverImageUrl = e.CoverImageUrl
                })
                .FirstOrDefault();
        }

        public bool CreateEvent(CreateEventDto dto)
        {
            var newEvent = new Event
            {
                Name = dto.Name,
                Description = dto.Description,
                Location = dto.Location,
                OrganizerId = dto.OrganizerId,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                Category = dto.Category,
                MaxCapacity = dto.MaxCapacity,
                Status = "Published",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.Events.Add(newEvent);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateEvent(uint id, UpdateEventDto dto)
        {
            var existingEvent = _context.Events.FirstOrDefault(e => e.EventId == id);
            if (existingEvent == null) return false;

            existingEvent.Name = dto.Name;
            existingEvent.Description = dto.Description;
            existingEvent.Location = dto.Location;
            existingEvent.StartDate = dto.StartDate;
            existingEvent.EndDate = dto.EndDate;
            existingEvent.Category = dto.Category;
            existingEvent.MaxCapacity = dto.MaxCapacity;
            existingEvent.UpdatedAt = DateTime.Now;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteEvent(uint id)
        {
            var existingEvent = _context.Events.FirstOrDefault(e => e.EventId == id);
            if (existingEvent == null) return false;

            _context.Events.Remove(existingEvent);
            return _context.SaveChanges() > 0;
        }
    }
}