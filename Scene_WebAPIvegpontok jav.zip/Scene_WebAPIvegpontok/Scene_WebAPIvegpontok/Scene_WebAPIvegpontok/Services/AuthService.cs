﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using BCrypt.Net;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class AuthService
    {
        private readonly SceneContext _context;
        private readonly IConfiguration _configuration;

        public AuthService(SceneContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // 1. Felhasználó regisztrációja BCrypt jelszó-hasheléssel
        public bool Register(CreateUserDto dto, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (_context.Users.Any(u => u.Username == dto.Username))
            {
                errorMessage = "A megadott felhasználónév már foglalt.";
                return false;
            }

            if (_context.Users.Any(u => u.Email == dto.Email))
            {
                errorMessage = "A megadott e-mail cím már regisztrálva van.";
                return false;
            }

            var now = DateTime.UtcNow;
            var user = new User
            {
                Username = dto.Username,
                Email = dto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                DisplayName = dto.DisplayName,
                AvatarImageUrl = dto.AvatarImageUrl,
                Bio = dto.Bio,
                Role = string.IsNullOrEmpty(dto.Role) ? "User" : dto.Role,
                AvatarLevel = 1,
                CurrentXP = 0,
                IsActive = true,
                CreatedAt = now,
                UpdatedAt = now
            };

            _context.Users.Add(user);
            return _context.SaveChanges() > 0;
        }

        // 2. Bejelentkezés és Token-pár generálása
        public TokenResponseDto? Login(LoginDto dto, out string errorMessage)
        {
            errorMessage = string.Empty;

            var user = _context.Users.FirstOrDefault(u =>
                u.Username == dto.UsernameOrEmail || u.Email == dto.UsernameOrEmail);

            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            {
                errorMessage = "Érvénytelen felhasználónév/e-mail vagy jelszó.";
                return null;
            }

            if (!user.IsActive)
            {
                errorMessage = "Ez a fiók fel van függesztve.";
                return null;
            }

            return GenerateTokensForUser(user);
        }

        // 3. JWT Access Token + Refresh Token generálása (JAVÍTVA: UtcNow használata)
        public TokenResponseDto GenerateTokensForUser(User user)
        {
            var jwtSettings = _configuration.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSettings["Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            // JAVÍTÁS: DateTime.UtcNow használata a DateTime.Now helyett
            var expiresAt = DateTime.UtcNow.AddMinutes(double.Parse(jwtSettings["DurationInMinutes"] ?? "60"));

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)
            };

            var token = new JwtSecurityToken(
                issuer: jwtSettings["Issuer"],
                audience: jwtSettings["Audience"],
                claims: claims,
                expires: expiresAt,
                signingCredentials: creds
            );

            var accessToken = new JwtSecurityTokenHandler().WriteToken(token);
            var refreshToken = GenerateAndSaveRefreshToken(user.UserId);

            return new TokenResponseDto
            {
                AccessToken = accessToken,
                RefreshToken = refreshToken,
                AccessTokenExpiresAt = expiresAt,
                Username = user.Username,
                Role = user.Role
            };
        }

        // 4. Refresh Token generálás és adatbázisba mentés (JAVÍTVA: UtcNow használata)
        private string GenerateAndSaveRefreshToken(uint userId)
        {
            var randomNumber = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomNumber);

            var token = Convert.ToBase64String(randomNumber);

            var refreshToken = new RefreshToken
            {
                UserId = userId,
                Token = token,
                ExpiresAt = DateTime.UtcNow.AddDays(7), // JAVÍTVA
                IsRevoked = false,
                CreatedAt = DateTime.UtcNow
            };

            _context.RefreshTokens.Add(refreshToken);
            _context.SaveChanges();

            return token;
        }

        // 5. Token frissítése Refresh Token segítségével
        public TokenResponseDto? RefreshAccessToken(string token, out string errorMessage)
        {
            errorMessage = string.Empty;

            var storedToken = _context.RefreshTokens
                .FirstOrDefault(r => r.Token == token && !r.IsRevoked);

            if (storedToken == null || storedToken.ExpiresAt <= DateTime.UtcNow)
            {
                errorMessage = "Érvénytelen vagy lejárt Refresh Token.";
                return null;
            }

            var user = _context.Users.FirstOrDefault(u => u.UserId == storedToken.UserId);
            if (user == null || !user.IsActive)
            {
                errorMessage = "A felhasználó nem található vagy inaktív.";
                return null;
            }

            // Régi Refresh Token visszavonása és új token-pár kiadása
            storedToken.IsRevoked = true;
            _context.SaveChanges();

            return GenerateTokensForUser(user);
        }

        // 6. Refresh Token visszavonása (Kijelentkezés)
        public bool RevokeRefreshToken(string token)
        {
            var storedToken = _context.RefreshTokens.FirstOrDefault(r => r.Token == token);
            if (storedToken == null) return false;

            storedToken.IsRevoked = true;
            return _context.SaveChanges() > 0;
        }
    }
}