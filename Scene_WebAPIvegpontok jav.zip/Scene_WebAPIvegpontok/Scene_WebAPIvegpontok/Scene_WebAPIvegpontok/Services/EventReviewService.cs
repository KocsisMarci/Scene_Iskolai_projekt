﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class EventReviewService
    {
        private readonly SceneContext _context;

        public EventReviewService(SceneContext context)
        {
            _context = context;
        }

        public List<EventReviewResponseDto> GetAllEventReviews()
        {
            return _context.EventReviews
                .Include(r => r.User)
                .Include(r => r.Event)
                .Select(r => new EventReviewResponseDto
                {
                    ReviewId = r.ReviewId,
                    EventId = r.EventId,
                    EventName = r.Event != null ? r.Event.Name : null,
                    UserId = r.UserId,
                    Username = r.User != null ? r.User.Username : null,
                    Rating = r.Rating,
                    Comment = r.Comment,
                    CreatedAt = r.CreatedAt
                })
                .ToList();
        }

        public EventReviewResponseDto? GetEventReviewById(uint id)
        {
            return _context.EventReviews
                .Include(r => r.User)
                .Include(r => r.Event)
                .Where(r => r.ReviewId == id)
                .Select(r => new EventReviewResponseDto
                {
                    ReviewId = r.ReviewId,
                    EventId = r.EventId,
                    EventName = r.Event != null ? r.Event.Name : null,
                    UserId = r.UserId,
                    Username = r.User != null ? r.User.Username : null,
                    Rating = r.Rating,
                    Comment = r.Comment,
                    CreatedAt = r.CreatedAt
                })
                .FirstOrDefault();
        }

        public bool CreateEventReview(CreateEventReviewDto dto)
        {
            var review = new EventReview
            {
                EventId = dto.EventId,
                UserId = dto.UserId,
                Rating = dto.Rating,
                Comment = dto.Comment,
                CreatedAt = DateTime.Now
            };

            _context.EventReviews.Add(review);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateEventReview(uint id, UpdateEventReviewDto dto)
        {
            var existingReview = _context.EventReviews.FirstOrDefault(r => r.ReviewId == id);
            if (existingReview == null)
            {
                return false;
            }

            existingReview.Rating = dto.Rating;
            existingReview.Comment = dto.Comment;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteEventReview(uint id)
        {
            var review = _context.EventReviews.FirstOrDefault(r => r.ReviewId == id);
            if (review == null)
            {
                return false;
            }

            _context.EventReviews.Remove(review);
            return _context.SaveChanges() > 0;
        }
    }
}
