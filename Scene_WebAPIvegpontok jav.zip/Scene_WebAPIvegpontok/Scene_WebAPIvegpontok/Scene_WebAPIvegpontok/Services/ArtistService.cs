﻿using System;
using System.Collections.Generic;
using System.Linq;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class ArtistService
    {
        private readonly SceneContext _context;

        public ArtistService(SceneContext context)
        {
            _context = context;
        }

        public List<ArtistResponseDto> GetAllArtists()
        {
            return _context.Artists
                .Select(a => new ArtistResponseDto
                {
                    ArtistId = a.ArtistId,
                    Name = a.Name,
                    Bio = a.Bio,
                    ImageUrl = a.ImageUrl,
                    SocialLinks = a.SocialLinks,
                    Genre = a.Genre
                })
                .ToList();
        }

        public ArtistResponseDto? GetArtistById(uint id)
        {
            return _context.Artists
                .Where(a => a.ArtistId == id)
                .Select(a => new ArtistResponseDto
                {
                    ArtistId = a.ArtistId,
                    Name = a.Name,
                    Bio = a.Bio,
                    ImageUrl = a.ImageUrl,
                    SocialLinks = a.SocialLinks,
                    Genre = a.Genre
                })
                .FirstOrDefault();
        }

        public bool CreateArtist(CreateArtistDto dto)
        {
            var artist = new Artist
            {
                Name = dto.Name,
                Bio = dto.Bio,
                ImageUrl = dto.ImageUrl,
                SocialLinks = dto.SocialLinks,
                Genre = dto.Genre
            };

            _context.Artists.Add(artist);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateArtist(uint id, UpdateArtistDto dto)
        {
            var existing = _context.Artists.FirstOrDefault(a => a.ArtistId == id);
            if (existing == null) return false;

            existing.Name = dto.Name;
            existing.Bio = dto.Bio;
            existing.ImageUrl = dto.ImageUrl;
            existing.SocialLinks = dto.SocialLinks;
            existing.Genre = dto.Genre;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteArtist(uint id)
        {
            var existing = _context.Artists.FirstOrDefault(a => a.ArtistId == id);
            if (existing == null) return false;

            _context.Artists.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
