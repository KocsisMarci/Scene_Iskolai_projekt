﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Scene_WebAPIvegpontok.DTOs;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class PerformanceService
    {
        private readonly SceneContext _context;

        public PerformanceService(SceneContext context)
        {
            _context = context;
        }

        public List<PerformanceResponseDto> GetAllPerformances()
        {
            return _context.Performances
                .Include(p => p.Event)
                .Include(p => p.Artist)
                .Select(p => new PerformanceResponseDto
                {
                    PerformanceId = p.PerformanceId,
                    EventId = p.EventId,
                    EventName = p.Event != null ? p.Event.Name : null,
                    ArtistId = p.ArtistId,
                    ArtistName = p.Artist != null ? p.Artist.Name : null,
                    StageName = p.StageName,
                    StartTime = p.StartTime,
                    EndTime = p.EndTime
                })
                .ToList();
        }

        public PerformanceResponseDto? GetPerformanceById(uint id)
        {
            return _context.Performances
                .Include(p => p.Event)
                .Include(p => p.Artist)
                .Where(p => p.PerformanceId == id)
                .Select(p => new PerformanceResponseDto
                {
                    PerformanceId = p.PerformanceId,
                    EventId = p.EventId,
                    EventName = p.Event != null ? p.Event.Name : null,
                    ArtistId = p.ArtistId,
                    ArtistName = p.Artist != null ? p.Artist.Name : null,
                    StageName = p.StageName,
                    StartTime = p.StartTime,
                    EndTime = p.EndTime
                })
                .FirstOrDefault();
        }

        public bool CreatePerformance(CreatePerformanceDto dto)
        {
            var performance = new Performance
            {
                EventId = dto.EventId,
                ArtistId = dto.ArtistId,
                StageName = dto.StageName,
                StartTime = dto.StartTime,
                EndTime = dto.EndTime
            };

            _context.Performances.Add(performance);
            return _context.SaveChanges() > 0;
        }

        public bool UpdatePerformance(uint id, UpdatePerformanceDto dto)
        {
            var existing = _context.Performances.FirstOrDefault(p => p.PerformanceId == id);
            if (existing == null)
            {
                return false;
            }

            existing.StageName = dto.StageName;
            existing.StartTime = dto.StartTime;
            existing.EndTime = dto.EndTime;

            return _context.SaveChanges() > 0;
        }

        public bool DeletePerformance(uint id)
        {
            var existing = _context.Performances.FirstOrDefault(p => p.PerformanceId == id);
            if (existing == null)
            {
                return false;
            }

            _context.Performances.Remove(existing);
            return _context.SaveChanges() > 0;
        }
    }
}
