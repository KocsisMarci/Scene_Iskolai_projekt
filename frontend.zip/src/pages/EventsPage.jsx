import React, { useState, useEffect } from 'react';
import EventCard from '../components/EventCard';
import axiosInstance from '../api/axiosInstance';

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        // Itt axiosInstance-t használunk, mert azzal lett importálva!
        const response = await axiosInstance.get('/Event');
        setEvents(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Hiba az adatok lekérésekor:', err);
        setError('Nem sikerült betölteni az eseményeket a szerverről.');
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px', fontSize: '16px' }}>Események betöltése...</div>;
  }

  if (error) {
    return <div style={{ textAlign: 'center', padding: '50px', color: 'red', fontSize: '16px' }}>{error}</div>;
  }

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '30px' }}>Események</h1>
      
     <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
  {events.map((event, index) => (
    <EventCard key={event.EventId || event.eventId || index} event={event} />
  ))}
</div>

      {events.length === 0 && (
        <p style={{ textAlign: 'center', color: '#777', marginTop: '30px' }}>Jelenleg nincsenek elérhető események.</p>
      )}
    </div>
  );
}