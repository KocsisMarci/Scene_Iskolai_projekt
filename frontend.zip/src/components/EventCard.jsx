import { Link } from 'react-router-dom';

export default function EventCard({ event }) {
  // Biztonságos mezőkiolvasás szövegekhez
  const name = event.Name || event.name;
  const description = event.Description || event.description;
  const location = event.Location || event.location;
  const startDate = event.StartDate || event.startDate;
  const category = event.Category || event.category;
  const eventId = event.EventId || event.eventId;

  // GOLYÓÁLLÓ KÉPKERESŐ: Megkeresi azt a mezőt az objektumban, aminek az értéke http-vel kezdődik (azaz a kép URL-je)
  const findImageUrl = (obj) => {
    if (!obj) return null;
    const matchingKey = Object.keys(obj).find(k => {
      const val = obj[k];
      return typeof val === 'string' && val.startsWith('http');
    });
    return matchingKey ? obj[matchingKey] : null;
  };

  const coverImage = findImageUrl(event);

  const formatDate = (dateString) => {
    if (!dateString) return 'Nincs időpont';
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? 'Érvénytelen dátum' : date.toLocaleString('hu-HU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div style={{ 
      border: '1px solid #ddd', 
      borderRadius: '8px', 
      overflow: 'hidden', 
      display: 'flex', 
      flexDirection: 'row', 
      background: '#fff',
      boxShadow: '0 2px 5px rgba(0,0,0,0.05)',
      marginBottom: '15px',
      maxWidth: '750px',
      margin: '0 auto 15px auto',
      alignItems: 'stretch'
    }}>
      {/* Kép megjelenítése */}
      {coverImage ? (
        <img 
          src={coverImage} 
          alt={name || 'Esemény kép'} 
          style={{ width: '220px', minHeight: '150px', objectFit: 'cover' }} 
        />
      ) : (
        <div style={{ width: '220px', backgroundColor: '#eef2f5', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#888', fontSize: '14px' }}>
          Nincs kép
        </div>
      )}

      <div style={{ padding: '15px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div>
          {category && (
            <span style={{ fontSize: '12px', background: '#e0f0ff', color: '#0066cc', padding: '3px 8px', borderRadius: '4px', fontWeight: 'bold' }}>
              {category}
            </span>
          )}
          <h3 style={{ margin: '8px 0 5px 0', fontSize: '18px' }}>{name}</h3>
          <p style={{ color: '#555', fontSize: '14px', margin: '5px 0' }}>{description}</p>
        </div>

        <div>
          <p style={{ fontSize: '13px', color: '#777', margin: '8px 0 5px 0' }}>
            📍 {location || 'Helyszín nélkül'} | 📅 {formatDate(startDate)}
          </p>
          {eventId && (
            <Link 
              to={`/events/${eventId}`} 
              style={{ display: 'inline-block', color: '#007bff', fontWeight: 'bold', textDecoration: 'none', fontSize: '14px' }}
            >
              Részletek megtekintése →
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}