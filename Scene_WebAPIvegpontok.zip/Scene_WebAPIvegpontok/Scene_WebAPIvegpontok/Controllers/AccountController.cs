﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Scene_WebAPIvegpontok.Models;
using Scene_WebAPIvegpontok.Services;

namespace Scene_WebAPIvegpontok.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly AccountService _accountService;

        public AccountController(AccountService accountService)
        {
            _accountService = accountService;
        }

        // GET: api/Account
        [HttpGet]
        public IActionResult GetAllAccount()
        {
            try
            {
                List<User> accounts = _accountService.GetAllUsers();
                return Ok(accounts);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba történt a fiókok lekérése során: {ex.Message}");
            }
        }

        // GET: api/Account/GetById/1
        [HttpGet("GetById/{id}")]
        public IActionResult GetAccountById(uint id)
        {
            try
            {
                User? account = _accountService.GetUserById(id);
                if (account != null)
                {
                    return Ok(account);
                }
                else
                {
                    return NotFound($"Nincs fiók a megadott azonosítóval: {id}");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a kérés teljesítése közben: {ex.Message}");
            }
        }

        // POST: api/Account
        [HttpPost]
        public IActionResult PostAccount([FromBody] User user)
        {
            try
            {
                bool siker = _accountService.CreateUser(user);
                if (siker)
                {
                    return Ok("A fiók sikeresen létrejött.");
                }
                else
                {
                    return BadRequest("Nem sikerült létrehozni a fiókot.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fiók létrehozása során: {ex.Message}");
            }
        }

        // PUT: api/Account/1
        [HttpPut("{id}")]
        public IActionResult PutAccount(uint id, [FromBody] User user)
        {
            try
            {
                bool siker = _accountService.UpdateUser(id, user);
                if (siker)
                {
                    return Ok("A fiók adatai sikeresen frissültek.");
                }
                else
                {
                    return NotFound($"Nincs fiók a megadott azonosítóval ({id}), vagy nem sikerült a módosítás.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fiók módosítása során: {ex.Message}");
            }
        }

        // DELETE: api/Account/1
        [HttpDelete("{id}")]
        public IActionResult DeleteAccount(uint id)
        {
            try
            {
                bool siker = _accountService.DeleteUser(id);
                if (siker)
                {
                    return Ok("A fiók sikeresen törölve lett.");
                }
                else
                {
                    return NotFound($"Nincs fiók a megadott azonosítóval: {id}");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"Hiba a fiók törlése során: {ex.Message}");
            }
        }
    }
}