﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class EventPhoto
    {
        public uint PhotoId { get; set; }
        public uint UserId { get; set; }
        public uint EventId { get; set; }
        public string ImageUrl { get; set; } = null!;
        public uint XPAwarded { get; set; } = 0;
        public string Status { get; set; } = "Pending";
        public DateTime UploadedAt { get; set; }

        public virtual User User { get; set; } = null!;
        public virtual Event Event { get; set; } = null!;
    }
}
