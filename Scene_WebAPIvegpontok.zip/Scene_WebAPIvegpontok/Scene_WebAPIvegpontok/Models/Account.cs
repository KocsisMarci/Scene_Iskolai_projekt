﻿namespace Scene_WebAPIvegpontok.Models
{
    public class Account
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string? DisplayName { get; set; }

        public override string ToString() =>
            $"Username: {Username}, Email: {Email}, DisplayName: {DisplayName ?? "-"}, {base.ToString()}";
    }
}
