﻿using Microsoft.Extensions.Logging;

namespace Scene_WebAPIvegpontok.Models
{
    public class Booking
    {
        public uint BookingId { get; set; }
        public uint UserId { get; set; }
        public uint EventId { get; set; }
        public string Status { get; set; } = "Interested";
        public DateTime CreatedAt { get; set; }

        public virtual User User { get; set; } = null!;
        public virtual Event Event { get; set; } = null!;
    }
}
