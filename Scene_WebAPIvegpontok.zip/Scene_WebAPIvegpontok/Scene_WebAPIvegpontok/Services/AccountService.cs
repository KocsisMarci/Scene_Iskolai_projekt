﻿using System.Collections.Generic;
using System.Linq;
using Scene_WebAPIvegpontok.Models;

namespace Scene_WebAPIvegpontok.Services
{
    public class AccountService
    {
        private readonly SceneContext _context;

        public AccountService(SceneContext context)
        {
            _context = context;
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public User? GetUserById(uint id)
        {
            return _context.Users.FirstOrDefault(u => u.UserId == id);
        }

        public bool CreateUser(User user)
        {
            _context.Users.Add(user);
            return _context.SaveChanges() > 0;
        }

        public bool UpdateUser(uint id, User updatedUser)
        {
            var existingUser = _context.Users.FirstOrDefault(u => u.UserId == id);
            if (existingUser == null)
            {
                return false;
            }

            existingUser.Username = updatedUser.Username;
            existingUser.Email = updatedUser.Email;
            existingUser.DisplayName = updatedUser.DisplayName;
            existingUser.AvatarLevel = updatedUser.AvatarLevel;
            existingUser.CurrentXP = updatedUser.CurrentXP;
            existingUser.AvatarImageUrl = updatedUser.AvatarImageUrl;
            existingUser.Bio = updatedUser.Bio;
            existingUser.Role = updatedUser.Role;
            existingUser.IsActive = updatedUser.IsActive;

            return _context.SaveChanges() > 0;
        }

        public bool DeleteUser(uint id)
        {
            var user = _context.Users.FirstOrDefault(u => u.UserId == id);
            if (user == null)
            {
                return false;
            }

            _context.Users.Remove(user);
            return _context.SaveChanges() > 0;
        }
    }
}