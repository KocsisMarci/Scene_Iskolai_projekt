﻿using System;
using System.Collections.Generic;
using System.Text.Json;

namespace Scene.AdminUI.Models
{
    public class ArtistDto
    {
        public uint ArtistId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Bio { get; set; }
        public string? ImageUrl { get; set; }
        public string Genre { get; set; } = "Other";

        // Külön mezők a WPF felülethez
        public string? Instagram { get; set; }
        public string? Spotify { get; set; }
        public string? YouTube { get; set; }
        public string? Facebook { get; set; }

        // A backendnek küldött / tőle kapott JSON tulajdonság
        public string? SocialLinks
        {
            get
            {
                var dict = new Dictionary<string, string>();
                if (!string.IsNullOrWhiteSpace(Instagram)) dict["instagram"] = Instagram.Trim();
                if (!string.IsNullOrWhiteSpace(Spotify)) dict["spotify"] = Spotify.Trim();
                if (!string.IsNullOrWhiteSpace(YouTube)) dict["youtube"] = YouTube.Trim();
                if (!string.IsNullOrWhiteSpace(Facebook)) dict["facebook"] = Facebook.Trim();

                return dict.Count > 0 ? JsonSerializer.Serialize(dict) : null;
            }
            set
            {
                Instagram = Spotify = YouTube = Facebook = null;
                if (string.IsNullOrWhiteSpace(value)) return;

                try
                {
                    var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(value);
                    if (dict != null)
                    {
                        if (dict.TryGetValue("instagram", out var ig)) Instagram = ig;
                        if (dict.TryGetValue("spotify", out var sp)) Spotify = sp;
                        if (dict.TryGetValue("youtube", out var yt)) YouTube = yt;
                        if (dict.TryGetValue("facebook", out var fb)) Facebook = fb;
                    }
                }
                catch { }
            }
        }
    }

    public class UserDto
    {
        public uint UserId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string? DisplayName { get; set; }
        public uint AvatarLevel { get; set; } = 1;
        public uint CurrentXP { get; set; } = 0;
        public string? AvatarImageUrl { get; set; }
        public string? Bio { get; set; }
        public string Role { get; set; } = "User";
        public bool IsActive { get; set; } = true;
    }

    public class EventPhotoDto
    {
        public uint PhotoId { get; set; }
        public uint UserId { get; set; }
        public string? Username { get; set; }
        public uint EventId { get; set; }
        public string ImageUrl { get; set; } = string.Empty;
        public int XPAwarded { get; set; }
        public string Status { get; set; } = string.Empty;
        public DateTime UploadedAt { get; set; }
    }

    public class EventReviewDto
    {
        public uint ReviewId { get; set; }
        public uint EventId { get; set; }
        public string? EventName { get; set; }
        public uint UserId { get; set; }
        public string? Username { get; set; }
        public byte Rating { get; set; }
        public string? Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}