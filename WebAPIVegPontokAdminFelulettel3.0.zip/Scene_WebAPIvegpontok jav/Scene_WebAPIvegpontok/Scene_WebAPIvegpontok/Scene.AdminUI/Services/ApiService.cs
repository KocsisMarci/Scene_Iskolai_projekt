﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Scene.AdminUI.Models;

namespace Scene.AdminUI.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService()
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };

            _httpClient = new HttpClient(handler)
            {
                BaseAddress = new Uri("https://localhost:7269/")
            };
        }

        // ==================== AUTH ====================
        public async Task<(bool IsSuccess, string ErrorMessage)> LoginAsync(string usernameOrEmail, string password)
        {
            try
            {
                var payload = new
                {
                    UsernameOrEmail = usernameOrEmail,
                    Password = password
                };

                var response = await _httpClient.PostAsJsonAsync("api/Auth/login", payload);

                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadFromJsonAsync<JsonElement>();

                    if (json.TryGetProperty("accessToken", out var tokenElement))
                    {
                        string? token = tokenElement.GetString();
                        if (!string.IsNullOrEmpty(token))
                        {
                            _httpClient.DefaultRequestHeaders.Authorization =
                                new AuthenticationHeaderValue("Bearer", token);
                            return (true, string.Empty);
                        }
                    }
                    return (false, "Sikeres válasz, de nem érkezett token.");
                }

                string serverError = await response.Content.ReadAsStringAsync();
                return (false, $"Szerver hiba ({(int)response.StatusCode}): {serverError}");
            }
            catch (HttpRequestException ex)
            {
                return (false, $"Nem érhető el az API! Fut a backend? ({ex.Message})");
            }
            catch (Exception ex)
            {
                return (false, $"Váratlan hiba: {ex.Message}");
            }
        }

        // Token visszaállítása mentett fiókból (gyorsbelépéshez)
        public void SetToken(string token)
        {
            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", token);
        }

        // 1. LÉPÉS: 6 jegyű kód kérése emailre
        public async Task<(bool IsSuccess, string ErrorMessage)> RequestAdminCodeAsync(string email)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/Auth/admin-request-code", new { Email = email });
                if (response.IsSuccessStatusCode) return (true, string.Empty);

                string err = await response.Content.ReadAsStringAsync();
                return (false, $"Hiba ({(int)response.StatusCode}): {err}");
            }
            catch (Exception ex)
            {
                return (false, $"Nem érhető el a szerver: {ex.Message}");
            }
        }

        // 2. LÉPÉS: 6 jegyű kód ellenőrzése és JWT token lekérése
        public async Task<(bool IsSuccess, string Token, string Username, string ErrorMessage)> VerifyAdminCodeAsync(string email, string code)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/Auth/admin-verify-code", new { Email = email, Code = code });
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadFromJsonAsync<JsonElement>();
                    string? token = json.TryGetProperty("accessToken", out var t) ? t.GetString() : null;
                    string? username = json.TryGetProperty("username", out var u) ? u.GetString() : email.Split('@')[0];

                    if (!string.IsNullOrEmpty(token))
                    {
                        SetToken(token);
                        return (true, token, username ?? email, string.Empty);
                    }
                    return (false, string.Empty, string.Empty, "Nem érkezett token a szervertől.");
                }

                string err = await response.Content.ReadAsStringAsync();
                return (false, string.Empty, string.Empty, $"Hibás kód ({(int)response.StatusCode}): {err}");
            }
            catch (Exception ex)
            {
                return (false, string.Empty, string.Empty, $"Hiba: {ex.Message}");
            }
        }





        // ==================== EVENTS ====================
        public async Task<List<EventDto>?> GetEventsAsync()
        {
            try { return await _httpClient.GetFromJsonAsync<List<EventDto>>("api/Event"); }
            catch { return null; }
        }

        public async Task<EventDto?> GetEventByIdAsync(uint id)
        {
            try { return await _httpClient.GetFromJsonAsync<EventDto>($"api/Event/GetById/{id}"); }
            catch { return null; }
        }

        public async Task<bool> CreateEventAsync(EventDto newEvent)
        {
            try { return (await _httpClient.PostAsJsonAsync("api/Event", newEvent)).IsSuccessStatusCode; }
            catch { return false; }
        }

        public async Task<bool> UpdateEventAsync(uint id, EventDto updatedEvent)
        {
            try { return (await _httpClient.PutAsJsonAsync($"api/Event/{id}", updatedEvent)).IsSuccessStatusCode; }
            catch { return false; }
        }

        public async Task<bool> DeleteEventAsync(uint eventId)
        {
            try { return (await _httpClient.DeleteAsync($"api/Event/{eventId}")).IsSuccessStatusCode; }
            catch { return false; }
        }

        // ==================== ARTISTS ====================
        public async Task<List<ArtistDto>?> GetArtistsAsync()
        {
            try { return await _httpClient.GetFromJsonAsync<List<ArtistDto>>("api/Artist"); }
            catch { return null; }
        }

        public async Task<bool> CreateArtistAsync(ArtistDto dto)
        {
            try
            {
                var res = await _httpClient.PostAsJsonAsync("api/Artist", new
                {
                    dto.Name,
                    dto.Bio,
                    dto.ImageUrl,
                    dto.SocialLinks,
                    dto.Genre
                });
                return res.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        public async Task<bool> UpdateArtistAsync(uint id, ArtistDto dto)
        {
            try
            {
                var res = await _httpClient.PutAsJsonAsync($"api/Artist/{id}", new
                {
                    dto.Name,
                    dto.Bio,
                    dto.ImageUrl,
                    dto.SocialLinks,
                    dto.Genre
                });
                return res.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        public async Task<bool> DeleteArtistAsync(uint id)
        {
            try { return (await _httpClient.DeleteAsync($"api/Artist/{id}")).IsSuccessStatusCode; }
            catch { return false; }
        }

        // ==================== USERS ====================
        public async Task<List<UserDto>?> GetUsersAsync()
        {
            try { return await _httpClient.GetFromJsonAsync<List<UserDto>>("api/User"); }
            catch { return null; }
        }

        public async Task<bool> CreateUserAsync(UserDto dto)
        {
            try
            {
                var res = await _httpClient.PostAsJsonAsync("api/User", new
                {
                    dto.Username,
                    dto.Email,
                    dto.Password,
                    dto.DisplayName,
                    dto.AvatarImageUrl,
                    dto.Bio,
                    dto.Role
                });
                return res.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        public async Task<bool> UpdateUserAsync(uint id, UserDto dto)
        {
            try
            {
                var res = await _httpClient.PutAsJsonAsync($"api/User/{id}", new
                {
                    dto.Email,
                    dto.DisplayName,
                    dto.AvatarImageUrl,
                    dto.Bio,
                    dto.AvatarLevel,
                    dto.CurrentXP,
                    dto.Role,
                    dto.IsActive
                });
                return res.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        public async Task<bool> DeleteUserAsync(uint id)
        {
            try { return (await _httpClient.DeleteAsync($"api/User/{id}")).IsSuccessStatusCode; }
            catch { return false; }
        }

        // ==================== MODERÁCIÓ (CSAK GET ÉS DELETE!) ====================
        public async Task<List<EventPhotoDto>?> GetEventPhotosAsync()
        {
            try { return await _httpClient.GetFromJsonAsync<List<EventPhotoDto>>("api/EventPhoto"); }
            catch { return null; }
        }

        public async Task<bool> DeleteEventPhotoAsync(uint photoId)
        {
            try { return (await _httpClient.DeleteAsync($"api/EventPhoto/{photoId}")).IsSuccessStatusCode; }
            catch { return false; }
        }

        public async Task<List<EventReviewDto>?> GetEventReviewsAsync()
        {
            try { return await _httpClient.GetFromJsonAsync<List<EventReviewDto>>("api/EventReview"); }
            catch { return null; }
        }

        public async Task<bool> DeleteEventReviewAsync(uint reviewId)
        {
            try { return (await _httpClient.DeleteAsync($"api/EventReview/{reviewId}")).IsSuccessStatusCode; }
            catch { return false; }
        }
    }
}