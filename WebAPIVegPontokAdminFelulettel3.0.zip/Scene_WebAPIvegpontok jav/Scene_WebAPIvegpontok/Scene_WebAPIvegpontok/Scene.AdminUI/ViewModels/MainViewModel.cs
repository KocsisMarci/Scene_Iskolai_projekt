﻿using Scene.AdminUI.Models;
using Scene.AdminUI.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Scene.AdminUI.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private ApiService _apiService;

        private List<EventPhotoDto> _allPhotos = new();
        private List<EventReviewDto> _allReviews = new();

        // ==================== 1. EVENTS ====================
        public ObservableCollection<EventDto> Events { get; set; } = new();
        public ObservableCollection<string> SearchFields { get; set; } = new() { "Név", "ID", "Kategória", "Helyszín" };

        public ObservableCollection<EventPhotoDto> SelectedEventPhotos { get; set; } = new();
        public ObservableCollection<EventReviewDto> SelectedEventReviews { get; set; } = new();
        public EventPhotoDto? SelectedEventPhoto { get; set; }
        public EventReviewDto? SelectedEventReview { get; set; }

        private EventDto? _selectedEvent;
        public EventDto? SelectedEvent
        {
            get => _selectedEvent;
            set
            {
                _selectedEvent = value;
                OnPropertyChanged();
                if (value != null)
                {
                    EditableEvent = new EventDto
                    {
                        EventId = value.EventId,
                        Name = value.Name,
                        Location = value.Location,
                        Category = value.Category,
                        StartDate = value.StartDate,
                        CurrentBookingsCount = value.CurrentBookingsCount
                    };
                    FilterEventRelatedItems(value.EventId);
                }
                else
                {
                    SelectedEventPhotos.Clear();
                    SelectedEventReviews.Clear();
                }
            }
        }

        private EventDto _editableEvent = new() { StartDate = DateTime.Now };
        public EventDto EditableEvent
        {
            get => _editableEvent;
            set { _editableEvent = value; OnPropertyChanged(); }
        }

        public string SelectedSearchField { get; set; } = "Név";
        public string SearchText { get; set; } = "";

        // ==================== 2. ARTISTS ====================
        public ObservableCollection<ArtistDto> Artists { get; set; } = new();
        public ObservableCollection<string> ArtistGenres { get; set; } = new()
        {
            "Musician", "DJ", "Dancer", "Comedian", "Magician", "Speaker", "Organization", "AnimalShow", "Workshop", "Other"
        };

        private ArtistDto? _selectedArtist;
        public ArtistDto? SelectedArtist
        {
            get => _selectedArtist;
            set
            {
                _selectedArtist = value;
                OnPropertyChanged();
                if (value != null)
                {
                    EditableArtist = new ArtistDto
                    {
                        ArtistId = value.ArtistId,
                        Name = value.Name,
                        Bio = value.Bio,
                        ImageUrl = value.ImageUrl,
                        Genre = string.IsNullOrEmpty(value.Genre) ? "Other" : value.Genre,
                        Instagram = value.Instagram,
                        Spotify = value.Spotify,
                        YouTube = value.YouTube,
                        Facebook = value.Facebook
                    };
                }
            }
        }

        private ArtistDto _editableArtist = new() { Genre = "Other" };
        public ArtistDto EditableArtist
        {
            get => _editableArtist;
            set { _editableArtist = value; OnPropertyChanged(); }
        }

        public string ArtistSearchText { get; set; } = "";

        // ==================== 3. USERS ====================
        public ObservableCollection<UserDto> Users { get; set; } = new();
        public ObservableCollection<string> UserRoles { get; set; } = new() { "User", "Admin" };

        public ObservableCollection<EventPhotoDto> SelectedUserPhotos { get; set; } = new();
        public ObservableCollection<EventReviewDto> SelectedUserReviews { get; set; } = new();
        public EventPhotoDto? SelectedUserPhoto { get; set; }
        public EventReviewDto? SelectedUserReview { get; set; }

        private UserDto? _selectedUser;
        public UserDto? SelectedUser
        {
            get => _selectedUser;
            set
            {
                _selectedUser = value;
                OnPropertyChanged();
                if (value != null)
                {
                    EditableUser = new UserDto
                    {
                        UserId = value.UserId,
                        Username = value.Username,
                        Email = value.Email,
                        DisplayName = value.DisplayName,
                        AvatarLevel = value.AvatarLevel,
                        CurrentXP = value.CurrentXP,
                        AvatarImageUrl = value.AvatarImageUrl,
                        Bio = value.Bio,
                        Role = string.IsNullOrEmpty(value.Role) ? "User" : value.Role,
                        IsActive = value.IsActive
                    };
                    FilterUserRelatedItems(value.UserId);
                }
                else
                {
                    SelectedUserPhotos.Clear();
                    SelectedUserReviews.Clear();
                }
            }
        }

        private UserDto _editableUser = new() { Role = "User", IsActive = true, AvatarLevel = 1 };
        public UserDto EditableUser
        {
            get => _editableUser;
            set { _editableUser = value; OnPropertyChanged(); }
        }

        public string UserSearchText { get; set; } = "";

        // ==================== STATUS & PARANCSOK ====================
        private string _statusMessage = "Kész";
        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        public ICommand LoadEventsCommand { get; }
        public ICommand DeleteSelectedEventCommand { get; }
        public ICommand SearchCommand { get; }
        public ICommand CreateEventCommand { get; }
        public ICommand UpdateEventCommand { get; }
        public ICommand ClearEditorCommand { get; }

        public ICommand LoadArtistsCommand { get; }
        public ICommand SearchArtistsCommand { get; }
        public ICommand CreateArtistCommand { get; }
        public ICommand UpdateArtistCommand { get; }
        public ICommand DeleteSelectedArtistCommand { get; }
        public ICommand ClearArtistEditorCommand { get; }

        public ICommand LoadUsersCommand { get; }
        public ICommand SearchUsersCommand { get; }
        public ICommand CreateUserCommand { get; }
        public ICommand UpdateUserCommand { get; }
        public ICommand DeleteSelectedUserCommand { get; }
        public ICommand ClearUserEditorCommand { get; }

        public ICommand DeleteEventPhotoCommand { get; }
        public ICommand DeleteEventReviewCommand { get; }
        public ICommand DeleteUserPhotoCommand { get; }
        public ICommand DeleteUserReviewCommand { get; }

        public MainViewModel()
        {
            _apiService = new ApiService();

            LoadEventsCommand = new RelayCommand(async _ => await LoadEvents());
            DeleteSelectedEventCommand = new RelayCommand(async _ => await DeleteSelectedEvent(), _ => SelectedEvent != null);
            SearchCommand = new RelayCommand(async _ => await PerformSearch());
            CreateEventCommand = new RelayCommand(async _ => await CreateEvent());
            UpdateEventCommand = new RelayCommand(async _ => await UpdateEvent(), _ => EditableEvent.EventId > 0);
            ClearEditorCommand = new RelayCommand(_ => ClearEventEditor());

            LoadArtistsCommand = new RelayCommand(async _ => await LoadArtists());
            SearchArtistsCommand = new RelayCommand(async _ => await SearchArtists());
            CreateArtistCommand = new RelayCommand(async _ => await CreateArtist());
            UpdateArtistCommand = new RelayCommand(async _ => await UpdateArtist(), _ => EditableArtist.ArtistId > 0);
            DeleteSelectedArtistCommand = new RelayCommand(async _ => await DeleteSelectedArtist(), _ => SelectedArtist != null);
            ClearArtistEditorCommand = new RelayCommand(_ => ClearArtistEditor());

            LoadUsersCommand = new RelayCommand(async _ => await LoadUsers());
            SearchUsersCommand = new RelayCommand(async _ => await SearchUsers());
            CreateUserCommand = new RelayCommand(async _ => await CreateUser());
            UpdateUserCommand = new RelayCommand(async _ => await UpdateUser(), _ => EditableUser.UserId > 0);
            DeleteSelectedUserCommand = new RelayCommand(async _ => await DeleteSelectedUser(), _ => SelectedUser != null);
            ClearUserEditorCommand = new RelayCommand(_ => ClearUserEditor());

            DeleteEventPhotoCommand = new RelayCommand(async _ => await DeletePhoto(SelectedEventPhoto), _ => SelectedEventPhoto != null);
            DeleteEventReviewCommand = new RelayCommand(async _ => await DeleteReview(SelectedEventReview), _ => SelectedEventReview != null);
            DeleteUserPhotoCommand = new RelayCommand(async _ => await DeletePhoto(SelectedUserPhoto), _ => SelectedUserPhoto != null);
            DeleteUserReviewCommand = new RelayCommand(async _ => await DeleteReview(SelectedUserReview), _ => SelectedUserReview != null);
        }

        public async Task InitializeAsync(ApiService authenticatedApiService)
        {
            _apiService = authenticatedApiService;
            await LoadEvents();
            await LoadArtists();
            await LoadUsers();
            await LoadModerationData();
        }

        // ==================== MODERÁCIÓ (GET & DELETE) ====================
        private async Task LoadModerationData()
        {
            _allPhotos = await _apiService.GetEventPhotosAsync() ?? new List<EventPhotoDto>();
            _allReviews = await _apiService.GetEventReviewsAsync() ?? new List<EventReviewDto>();

            if (SelectedEvent != null) FilterEventRelatedItems(SelectedEvent.EventId);
            if (SelectedUser != null) FilterUserRelatedItems(SelectedUser.UserId);
        }

        private void FilterEventRelatedItems(uint eventId)
        {
            SelectedEventPhotos.Clear();
            foreach (var p in _allPhotos.Where(x => x.EventId == eventId)) SelectedEventPhotos.Add(p);

            SelectedEventReviews.Clear();
            foreach (var r in _allReviews.Where(x => x.EventId == eventId)) SelectedEventReviews.Add(r);
        }

        private void FilterUserRelatedItems(uint userId)
        {
            SelectedUserPhotos.Clear();
            foreach (var p in _allPhotos.Where(x => x.UserId == userId)) SelectedUserPhotos.Add(p);

            SelectedUserReviews.Clear();
            foreach (var r in _allReviews.Where(x => x.UserId == userId)) SelectedUserReviews.Add(r);
        }

        private async Task DeletePhoto(EventPhotoDto? photo)
        {
            if (photo == null) return;
            if (await _apiService.DeleteEventPhotoAsync(photo.PhotoId))
            {
                StatusMessage = $"A(z) {photo.PhotoId} ID-jú kép törölve (DELETE).";
                await LoadModerationData();
            }
            else StatusMessage = "Hiba a kép törlése során!";
        }

        private async Task DeleteReview(EventReviewDto? review)
        {
            if (review == null) return;
            if (await _apiService.DeleteEventReviewAsync(review.ReviewId))
            {
                StatusMessage = $"A(z) {review.ReviewId} ID-jú vélemény törölve (DELETE).";
                await LoadModerationData();
            }
            else StatusMessage = "Hiba a vélemény törlése során!";
        }

        // ==================== EVENTS ====================
        private async Task LoadEvents()
        {
            StatusMessage = "Események betöltése...";
            var data = await _apiService.GetEventsAsync();
            if (data != null)
            {
                Events.Clear();
                foreach (var ev in data) Events.Add(ev);
                StatusMessage = $"{Events.Count} esemény betöltve.";
            }
            else StatusMessage = "Hiba az események betöltése során!";
        }

        private async Task PerformSearch()
        {
            if (string.IsNullOrWhiteSpace(SearchText)) { await LoadEvents(); return; }
            var all = await _apiService.GetEventsAsync();
            if (all != null)
            {
                var term = SearchText.Trim();
                var filtered = all.Where(e => SelectedSearchField switch
                {
                    "ID" => e.EventId.ToString().Contains(term),
                    "Név" => e.Name != null && e.Name.Contains(term, StringComparison.OrdinalIgnoreCase),
                    "Kategória" => e.Category != null && e.Category.Contains(term, StringComparison.OrdinalIgnoreCase),
                    "Helyszín" => e.Location != null && e.Location.Contains(term, StringComparison.OrdinalIgnoreCase),
                    _ => false
                }).ToList();

                Events.Clear();
                foreach (var ev in filtered) Events.Add(ev);
                StatusMessage = $"{Events.Count} esemény találat.";
            }
        }

        private async Task CreateEvent()
        {
            EditableEvent.EventId = 0;
            if (await _apiService.CreateEventAsync(EditableEvent))
            {
                StatusMessage = "Új esemény sikeresen hozzáadva (POST)!";
                ClearEventEditor();
                await LoadEvents();
            }
            else StatusMessage = "Hiba az új esemény hozzáadásakor!";
        }

        private async Task UpdateEvent()
        {
            if (EditableEvent.EventId == 0) return;
            if (await _apiService.UpdateEventAsync(EditableEvent.EventId, EditableEvent))
            {
                StatusMessage = $"A(z) {EditableEvent.EventId} ID-jú esemény módosítva (PUT)!";
                ClearEventEditor();
                await LoadEvents();
            }
            else StatusMessage = "Hiba az esemény módosítása során!";
        }

        private async Task DeleteSelectedEvent()
        {
            if (SelectedEvent == null) return;
            if (await _apiService.DeleteEventAsync(SelectedEvent.EventId))
            {
                StatusMessage = "Esemény törölve (DELETE).";
                ClearEventEditor();
                await LoadEvents();
            }
            else StatusMessage = "Hiba az esemény törlése során!";
        }

        private void ClearEventEditor()
        {
            EditableEvent = new EventDto { StartDate = DateTime.Now };
            SelectedEvent = null;
        }

        // ==================== ARTISTS ====================
        private async Task LoadArtists()
        {
            var data = await _apiService.GetArtistsAsync();
            if (data != null)
            {
                Artists.Clear();
                foreach (var a in data) Artists.Add(a);
                StatusMessage = $"{Artists.Count} előadó betöltve.";
            }
        }

        private async Task SearchArtists()
        {
            if (string.IsNullOrWhiteSpace(ArtistSearchText)) { await LoadArtists(); return; }
            var all = await _apiService.GetArtistsAsync();
            if (all != null)
            {
                var term = ArtistSearchText.Trim();
                Artists.Clear();
                foreach (var a in all.Where(x => x.Name.Contains(term, StringComparison.OrdinalIgnoreCase) || x.Genre.Contains(term, StringComparison.OrdinalIgnoreCase)))
                    Artists.Add(a);
                StatusMessage = $"{Artists.Count} előadó találat.";
            }
        }

        private async Task CreateArtist()
        {
            if (await _apiService.CreateArtistAsync(EditableArtist))
            {
                StatusMessage = "Új előadó sikeresen hozzáadva (POST)!";
                ClearArtistEditor();
                await LoadArtists();
            }
            else StatusMessage = "Hiba az előadó létrehozásakor!";
        }

        private async Task UpdateArtist()
        {
            if (EditableArtist.ArtistId == 0) return;
            if (await _apiService.UpdateArtistAsync(EditableArtist.ArtistId, EditableArtist))
            {
                StatusMessage = $"A(z) {EditableArtist.ArtistId} ID-jú előadó módosítva (PUT)!";
                ClearArtistEditor();
                await LoadArtists();
            }
            else StatusMessage = "Hiba az előadó módosítása során!";
        }

        private async Task DeleteSelectedArtist()
        {
            if (SelectedArtist == null) return;
            if (await _apiService.DeleteArtistAsync(SelectedArtist.ArtistId))
            {
                StatusMessage = "Előadó törölve (DELETE).";
                ClearArtistEditor();
                await LoadArtists();
            }
            else StatusMessage = "Hiba az előadó törlése során!";
        }

        private void ClearArtistEditor()
        {
            EditableArtist = new ArtistDto { Genre = "Other" };
            SelectedArtist = null;
        }

        // ==================== USERS ====================
        private async Task LoadUsers()
        {
            var data = await _apiService.GetUsersAsync();
            if (data != null)
            {
                Users.Clear();
                foreach (var u in data) Users.Add(u);
                StatusMessage = $"{Users.Count} felhasználó betöltve.";
            }
        }

        private async Task SearchUsers()
        {
            if (string.IsNullOrWhiteSpace(UserSearchText)) { await LoadUsers(); return; }
            var all = await _apiService.GetUsersAsync();
            if (all != null)
            {
                var term = UserSearchText.Trim();
                Users.Clear();
                foreach (var u in all.Where(x => x.Username.Contains(term, StringComparison.OrdinalIgnoreCase) || x.Email.Contains(term, StringComparison.OrdinalIgnoreCase)))
                    Users.Add(u);
                StatusMessage = $"{Users.Count} felhasználó találat.";
            }
        }

        private async Task CreateUser()
        {
            if (await _apiService.CreateUserAsync(EditableUser))
            {
                StatusMessage = "Új felhasználó sikeresen hozzáadva (POST)!";
                ClearUserEditor();
                await LoadUsers();
            }
            else StatusMessage = "Hiba a felhasználó létrehozásakor (ellenőrizd a jelszót és az egyedi emailt/nevet)!";
        }

        private async Task UpdateUser()
        {
            if (EditableUser.UserId == 0) return;
            if (await _apiService.UpdateUserAsync(EditableUser.UserId, EditableUser))
            {
                StatusMessage = $"A(z) {EditableUser.UserId} ID-jú felhasználó módosítva (PUT)!";
                ClearUserEditor();
                await LoadUsers();
            }
            else StatusMessage = "Hiba a felhasználó módosítása során!";
        }

        private async Task DeleteSelectedUser()
        {
            if (SelectedUser == null) return;
            if (await _apiService.DeleteUserAsync(SelectedUser.UserId))
            {
                StatusMessage = "Felhasználó törölve (DELETE).";
                ClearUserEditor();
                await LoadUsers();
            }
            else StatusMessage = "Hiba a felhasználó törlése során!";
        }

        private void ClearUserEditor()
        {
            EditableUser = new UserDto { Role = "User", IsActive = true, AvatarLevel = 1 };
            SelectedUser = null;
        }
    }
}