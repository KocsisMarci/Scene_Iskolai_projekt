﻿using Scene.AdminUI.Services;
using Scene.AdminUI.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace Scene.AdminUI.ViewModels
{
    public class SavedAdminProfile
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string AccessToken { get; set; } = string.Empty;
    }

    public class LoginViewModel : ViewModelBase
    {
        private readonly ApiService _apiService = new();
        private const string SaveFilePath = "saved_admins.json";

        public ObservableCollection<SavedAdminProfile> SavedAdmins { get; set; } = new();

        private string _email = string.Empty;
        public string Email
        {
            get => _email;
            set { _email = value; OnPropertyChanged(); }
        }

        private string _verificationCode = string.Empty;
        public string VerificationCode
        {
            get => _verificationCode;
            set { _verificationCode = value; OnPropertyChanged(); }
        }

        // 2. lépés (6 jegyű kód mező) láthatósága
        private bool _isCodeStepVisible;
        public bool IsCodeStepVisible
        {
            get => _isCodeStepVisible;
            set { _isCodeStepVisible = value; OnPropertyChanged(); }
        }

        // Szemecske gomb állapota (true = látható karakterek, false = pontok)
        private bool _isCodeVisible;
        public bool IsCodeVisible
        {
            get => _isCodeVisible;
            set
            {
                _isCodeVisible = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(IsCodeHidden));
            }
        }
        public bool IsCodeHidden => !IsCodeVisible;

        private string _statusMessage = string.Empty;
        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set { _isBusy = value; OnPropertyChanged(); }
        }

        public ICommand SendCodeCommand { get; }
        public ICommand VerifyCodeCommand { get; }
        public ICommand QuickLoginCommand { get; }
        public ICommand ToggleEyeCommand { get; }
        public ICommand ResetStepCommand { get; }

        public LoginViewModel()
        {
            LoadSavedAdmins();

            SendCodeCommand = new RelayCommand(async _ => await SendCodeAsync(), _ => !IsBusy && !string.IsNullOrWhiteSpace(Email));
            VerifyCodeCommand = new RelayCommand(async _ => await VerifyCodeAsync(), _ => !IsBusy && VerificationCode.Length == 6);
            QuickLoginCommand = new RelayCommand(async obj => await QuickLoginAsync(obj as SavedAdminProfile));
            ToggleEyeCommand = new RelayCommand(_ => IsCodeVisible = !IsCodeVisible);
            ResetStepCommand = new RelayCommand(_ =>
            {
                IsCodeStepVisible = false;
                VerificationCode = string.Empty;
                StatusMessage = string.Empty;
            });
        }

        // Korábban bejelentkezett admin kiválasztása -> azonnali belépés az első felületbe
        private async Task QuickLoginAsync(SavedAdminProfile? profile)
        {
            if (profile == null) return;
            IsBusy = true;
            StatusMessage = $"Belépés mint {profile.Username}...";

            _apiService.SetToken(profile.AccessToken);

            // Ellenőrizzük, él-e még a mentett token (pl. lekérjük a usereket, ami csak Adminnak megy)
            var test = await _apiService.GetUsersAsync();
            if (test != null)
            {
                await OpenMainWindowAsync();
            }
            else
            {
                // Ha lejárt a token, kitöltjük az emailt és kérünk egy új 6 jegyű kódot
                Email = profile.Email;
                StatusMessage = "A mentett munkamenet lejárt. Küldj egy új 6 jegyű kódot!";
                IsBusy = false;
            }
        }

        // 1. Lépés: Kód kérése az email címre
        private async Task SendCodeAsync()
        {
            IsBusy = true;
            StatusMessage = "6 jegyű kód küldése az email címre...";

            var result = await _apiService.RequestAdminCodeAsync(Email.Trim());
            if (result.IsSuccess)
            {
                IsCodeStepVisible = true;
                StatusMessage = "Kód elküldve! Írd be az emailben kapott 6 számjegyet.";
            }
            else
            {
                StatusMessage = result.ErrorMessage;
            }

            IsBusy = false;
        }

        // 2. Lépés: 6 jegyű kód ellenőrzése
        private async Task VerifyCodeAsync()
        {
            IsBusy = true;
            StatusMessage = "Kód ellenőrzése...";

            var result = await _apiService.VerifyAdminCodeAsync(Email.Trim(), VerificationCode.Trim());
            if (result.IsSuccess)
            {
                SaveAdminProfile(new SavedAdminProfile
                {
                    Username = result.Username,
                    Email = Email.Trim(),
                    AccessToken = result.Token
                });

                await OpenMainWindowAsync();
            }
            else
            {
                StatusMessage = result.ErrorMessage;
                IsBusy = false;
            }
        }

        private async Task OpenMainWindowAsync()
        {
            var mainWindow = new MainWindow();
            if (mainWindow.DataContext is MainViewModel mainVm)
            {
                await mainVm.InitializeAsync(_apiService);
            }
            mainWindow.Show();

            // Bezárjuk a LoginWindow-t
            foreach (Window win in Application.Current.Windows)
            {
                if (win is LoginWindow)
                {
                    win.Close();
                    break;
                }
            }
        }

        private void LoadSavedAdmins()
        {
            try
            {
                if (File.Exists(SaveFilePath))
                {
                    var json = File.ReadAllText(SaveFilePath);
                    var list = JsonSerializer.Deserialize<List<SavedAdminProfile>>(json);
                    if (list != null)
                    {
                        SavedAdmins.Clear();
                        foreach (var item in list) SavedAdmins.Add(item);
                    }
                }
            }
            catch { }
        }

        private void SaveAdminProfile(SavedAdminProfile profile)
        {
            var existing = SavedAdmins.FirstOrDefault(x => x.Email.Equals(profile.Email, StringComparison.OrdinalIgnoreCase));
            if (existing != null) SavedAdmins.Remove(existing);

            SavedAdmins.Insert(0, profile);
            try
            {
                File.WriteAllText(SaveFilePath, JsonSerializer.Serialize(SavedAdmins));
            }
            catch { }
        }
    }
}