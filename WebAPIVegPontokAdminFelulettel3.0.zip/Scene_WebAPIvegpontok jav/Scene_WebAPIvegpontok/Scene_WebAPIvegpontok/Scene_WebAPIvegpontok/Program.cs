using System;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Scene_WebAPIvegpontok.Models;
using Scene_WebAPIvegpontok.Services;

var builder = WebApplication.CreateBuilder(args);

// 1. DbContext
builder.Services.AddDbContext<SceneContext>();

// 2. CORS be�ll�t�sok (Frontend el�r�s enged�lyez�se)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

// 3. JWT Authentication regisztr�ci�ja
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.UTF8.GetBytes(jwtSettings["Key"]!);

builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ValidateIssuer = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidateAudience = true,
        ValidAudience = jwtSettings["Audience"],
        ValidateLifetime = true,
        ClockSkew = TimeSpan.Zero
    };

    // HIBAKERES�S: Ki�rja a konzolra, ha a token �rv�nytelen
    options.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            Console.WriteLine($"[JWT HIBA] Hiteles�t�s sikertelen: {context.Exception.Message}");
            return Task.CompletedTask;
        },
        OnChallenge = context =>
        {
            Console.WriteLine($"[JWT HIBA] Letiltva: {context.Error}, {context.ErrorDescription}");
            return Task.CompletedTask;
        }
    };
});

// 4. Szolg�ltat�sok (Services) regisztr�ci�ja
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<AccountService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<ArtistService>();
builder.Services.AddScoped<VendorService>();
builder.Services.AddScoped<EventService>();
builder.Services.AddScoped<PerformanceService>();
builder.Services.AddScoped<EventVendorService>();
builder.Services.AddScoped<BookingService>();
builder.Services.AddScoped<EventPhotoService>();
builder.Services.AddScoped<EventReviewService>();
builder.Services.AddScoped<XpTransactionService>();


builder.Services.AddDbContext<SceneContext>(options => {
    var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
    options.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
});



builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// 5. Swagger be�ll�t�sa a Bearer Token t�mogat�shoz (Automatikus Bearer el�taggal)
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "SCENE Web API", Version = "v1" });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Illeszd be az Access Tokent (a 'Bearer ' el�tagot a Swagger automatikusan hozz�adja):",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

// 1. CORS szolg�ltat�s regisztr�l�sa
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.WithOrigins("http://localhost:3000", "http://localhost:5173") // React (CRA / Vite) portok
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<SceneContext>();
        var authService = services.GetRequiredService<Scene_WebAPIvegpontok.Services.AuthService>();

        if (!context.Users.Any(u => u.Username == "admin"))
        {
            var adminDto = new Scene_WebAPIvegpontok.DTOs.CreateUserDto
            {
                Username = "admin",
                Email = "admin@scene.hu",
                Password = "Admin123!",
                DisplayName = "Rendszergazda",
                Role = "Admin"
            };

            bool success = authService.Register(adminDto, out string error);
            if (!success)
            {
                Console.WriteLine("Admin l�trehoz�sa sikertelen: " + error);
            }
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine("Seed hiba: " + ex.Message);
    }
}


// 2. Middleware bek�t�se (app.UseRouting() Ut�n, de app.UseAuthentication() EL�TT!)


// --- ADATB�ZIS INITIALIZATION / SEEDING BLOKK (IDE J�N!) ---
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<SceneContext>(); // A saj�t DbContext neved

    // Ha nem migr�ci�val fut az adatb�zis, l�trehozza a t�bl�kat ha nem l�teznek:
    context.Database.EnsureCreated();

    // Ellen�rizz�k, van-e m�r admin
    if (!context.Users.Any(u => u.Role == "Admin"))
    {
        var adminUser = new User
        {
            Username = "admin",
            Email = "admin@scene.hu",
            // Haszn�ld azt a jelsz�hashel� met�dust/szolg�ltat�st, amit a regisztr�ci�n�l haszn�lsz!
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Admin123!"),
            Role = "Admin"
        };

        context.Users.Add(adminUser);
        context.SaveChanges();
    }
}
// -------------------------------------------------------------------




app.UseCors("AllowFrontend");

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();

// CORS haszn�lata
app.UseCors("AllowAll");

// HITELES�T�S �S JOGOSULTS�GKEZEL�S PIPELINE (A Sorrend KULCSFONTOSS�G�!)
app.UseAuthentication(); // 1. Ki vagy te? (Token ellen�rz�s)
app.UseAuthorization();  // 2. Mit csin�lhatsz? (Role ellen�rz�s)
app.UseStaticFiles(); // Lehet�v� teszi a wwwroot mapp�b�l a k�pek el�r�s�t URL-en kereszt�l

app.MapControllers();

app.Run();