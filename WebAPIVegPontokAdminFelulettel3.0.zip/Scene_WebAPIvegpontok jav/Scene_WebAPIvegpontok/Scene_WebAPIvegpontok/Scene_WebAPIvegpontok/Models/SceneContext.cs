﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Scene_WebAPIvegpontok.Models
{
    public partial class SceneContext : DbContext
    {
        public SceneContext()
        {
        }

        public SceneContext(DbContextOptions<SceneContext> options)
            : base(options)
        {
        }

        // Táblák (DbSet gyűjtemények)
        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<Event> Events { get; set; }
        public virtual DbSet<Artist> Artists { get; set; }
        public virtual DbSet<Vendor> Vendors { get; set; }
        public virtual DbSet<Performance> Performances { get; set; }
        public virtual DbSet<Booking> Bookings { get; set; }
        public virtual DbSet<EventVendor> EventVendors { get; set; }
        public virtual DbSet<EventPhoto> EventPhotos { get; set; }
        public virtual DbSet<XpTransaction> XpTransactions { get; set; }
        public virtual DbSet<EventReview> EventReviews { get; set; }
        public virtual DbSet<RefreshToken> RefreshTokens { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Csatlakozási karakterlánc konfigurációja
                optionsBuilder.UseMySql(
                    "server=localhost;port=3306;database=scene_db;user=root;password=;",
                    ServerVersion.AutoDetect("server=localhost;port=3306;database=scene_db;user=root;password=;")
                );
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder
                .UseCollation("utf8mb4_unicode_ci")
                .HasCharSet("utf8mb4");

            // 1. USERS
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.HasIndex(e => e.Username).IsUnique();
                entity.HasIndex(e => e.Email).IsUnique();

                entity.Property(e => e.Username).HasMaxLength(50).IsRequired();
                entity.Property(e => e.Email).HasMaxLength(150).IsRequired();
                entity.Property(e => e.PasswordHash).HasMaxLength(255).IsRequired();
                entity.Property(e => e.DisplayName).HasMaxLength(100);
                entity.Property(e => e.AvatarLevel).HasDefaultValue(1u);
                entity.Property(e => e.CurrentXP).HasDefaultValue(0u);
                entity.Property(e => e.AvatarImageUrl).HasMaxLength(255);
                entity.Property(e => e.Bio).HasMaxLength(500);
                entity.Property(e => e.Role).HasColumnType("ENUM('User','Admin')").HasDefaultValue("User");
                entity.Property(e => e.IsActive).HasDefaultValue(true);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");
                entity.Property(e => e.UpdatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
            });

            modelBuilder.Entity<Account>(entity =>
            {
                entity.HasKey(e => e.AccountId);

                entity.Property(e => e.AccountName).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Email).HasMaxLength(150).IsRequired();
                entity.Property(e => e.PasswordHash).HasMaxLength(255).IsRequired();
                entity.Property(e => e.DisplayName).HasMaxLength(100);
            });

            // 2. EVENTS
            modelBuilder.Entity<Event>(entity =>
            {
                entity.HasKey(e => e.EventId);

                entity.HasIndex(e => e.StartDate, "idx_Events_StartDate");
                entity.HasIndex(e => e.Category, "idx_Events_Category");

                entity.Property(e => e.Name).HasMaxLength(150).IsRequired();
                entity.Property(e => e.Description).HasColumnType("TEXT");
                entity.Property(e => e.Location).HasMaxLength(255);
                entity.Property(e => e.Latitude).HasPrecision(9, 6);
                entity.Property(e => e.Longitude).HasPrecision(9, 6);
                entity.Property(e => e.Category).HasMaxLength(50);
                entity.Property(e => e.CoverImageUrl).HasMaxLength(255);
                entity.Property(e => e.Status).HasColumnType("ENUM('Published','Draft','Cancelled')").HasDefaultValue("Published");
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");
                entity.Property(e => e.UpdatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");

                entity.HasOne(d => d.CreatedByUser)
                    .WithMany(p => p.CreatedEvents)
                    .HasForeignKey(d => d.CreatedByUserId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .HasConstraintName("fk_Events_CreatedBy");
            });

            // 3. ARTISTS
            modelBuilder.Entity<Artist>(entity =>
            {
                entity.HasKey(e => e.ArtistId);

                entity.Property(e => e.Name).HasMaxLength(150).IsRequired();
                entity.Property(e => e.Bio).HasColumnType("TEXT");
                entity.Property(e => e.ImageUrl).HasMaxLength(255);
                entity.Property(e => e.SocialLinks).HasColumnType("json");
                entity.Property(e => e.Genre)
                    .HasColumnType("ENUM('Musician','DJ','Dancer','Comedian','Magician','Speaker','Organization','AnimalShow','Workshop','Other')")
                    .HasDefaultValue("Other");
            });

            // 4. VENDORS
            modelBuilder.Entity<Vendor>(entity =>
            {
                entity.HasKey(e => e.VendorId);

                entity.Property(e => e.Name).HasMaxLength(150).IsRequired();
                entity.Property(e => e.VendorType).HasMaxLength(50);
                entity.Property(e => e.Description).HasColumnType("TEXT");
                entity.Property(e => e.ContactEmail).HasMaxLength(150);
                entity.Property(e => e.ContactPhone).HasMaxLength(30);
                entity.Property(e => e.ImageUrl).HasMaxLength(255);
            });

            // 5. PERFORMANCES
            modelBuilder.Entity<Performance>(entity =>
            {
                entity.HasKey(e => e.PerformanceId);

                entity.HasIndex(e => new { e.EventId, e.ArtistId, e.StartTime }, "uq_Performance").IsUnique();

                entity.Property(e => e.StageName).HasMaxLength(100);

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.Performances)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Performances_Event");

                entity.HasOne(d => d.Artist)
                    .WithMany(p => p.Performances)
                    .HasForeignKey(d => d.ArtistId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Performances_Artist");
            });

            // 6. BOOKINGS
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(e => e.BookingId);

                entity.HasIndex(e => new { e.UserId, e.EventId }, "uq_Booking").IsUnique();
                entity.HasIndex(e => e.UserId, "idx_Bookings_UserId");
                entity.HasIndex(e => e.EventId, "idx_Bookings_EventId");

                entity.Property(e => e.Status).HasColumnType("ENUM('Interested','Going','Cancelled')").HasDefaultValue("Interested");
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Bookings_User");

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Bookings_Event");
            });

            // 7. EVENTVENDORS (Összetett kulcsos kapcsolótábla)
            modelBuilder.Entity<EventVendor>(entity =>
            {
                entity.HasKey(e => new { e.EventId, e.VendorId });

                entity.Property(e => e.SpotLabel).HasMaxLength(50);

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.EventVendors)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_EventVendors_Event");

                entity.HasOne(d => d.Vendor)
                    .WithMany(p => p.EventVendors)
                    .HasForeignKey(d => d.VendorId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_EventVendors_Vendor");
            });

            // 8. EVENTPHOTOS
            modelBuilder.Entity<EventPhoto>(entity =>
            {
                entity.HasKey(e => e.PhotoId);

                entity.HasIndex(e => e.EventId, "idx_EventPhotos_EventId");

                entity.Property(e => e.ImageUrl).HasMaxLength(255).IsRequired();
                entity.Property(e => e.XPAwarded).HasDefaultValue(0u);
                entity.Property(e => e.Status).HasColumnType("ENUM('Pending','Approved','Rejected')").HasDefaultValue("Pending");
                entity.Property(e => e.UploadedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.EventPhotos)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_EventPhotos_User");

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.EventPhotos)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_EventPhotos_Event");
            });

            // 9. XPTRANSACTIONS
            modelBuilder.Entity<XpTransaction>(entity =>
            {
                entity.ToTable("XPTransactions");
                entity.HasKey(e => e.TransactionId);

                entity.HasIndex(e => e.UserId, "idx_XPTransactions_UserId");

                entity.Property(e => e.Reason).HasMaxLength(100).IsRequired();
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.XpTransactions)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_XPTransactions_User");
            });

            // 10. EVENTREVIEWS
            modelBuilder.Entity<EventReview>(entity =>
            {
                entity.HasKey(e => e.ReviewId);

                entity.HasIndex(e => new { e.EventId, e.UserId }, "uq_User_Event_Review").IsUnique();

                entity.Property(e => e.Rating).IsRequired();
                entity.Property(e => e.Comment).HasColumnType("TEXT");
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.HasOne(d => d.Event)
                    .WithMany(p => p.EventReviews)
                    .HasForeignKey(d => d.EventId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Reviews_Event");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.EventReviews)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_Reviews_User");
            });

            modelBuilder.Entity<RefreshToken>(entity =>
            {
                entity.ToTable("refreshtokens");

                entity.HasKey(e => e.RefreshTokenId);

                entity.Property(e => e.Token).HasMaxLength(255).IsRequired();
                entity.Property(e => e.ExpiresAt).IsRequired();
                entity.Property(e => e.IsRevoked).HasDefaultValue(false);
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("CURRENT_TIMESTAMP");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.RefreshTokens)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("fk_RefreshTokens_User");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}