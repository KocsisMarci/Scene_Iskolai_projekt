﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Scene.AdminUI.Models;

namespace Scene.AdminUI.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        private string? _jwtToken;

        public ApiService()
        {
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };

            _httpClient = new HttpClient(handler)
            {
                BaseAddress = new Uri("https://localhost:7269/")
            };
        }

        public async Task<bool> LoginAsync(string username, string password)
        {
            try
            {
                var dto = new LoginRequestDto { UsernameOrEmail = username, Password = password };
                var response = await _httpClient.PostAsJsonAsync("api/auth/login", dto);

                if (!response.IsSuccessStatusCode) return false;

                var result = await response.Content.ReadFromJsonAsync<LoginResponseDto>();
                if (result == null || string.IsNullOrEmpty(result.Token)) return false;

                _jwtToken = result.Token;
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", _jwtToken);

                return true;
            }
            catch
            {
                return false;
            }
        }

        // --- GET ALL ---
        public async Task<List<EventDto>?> GetEventsAsync()
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<EventDto>>("api/Event");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Kivétel történt: {ex.Message}");
                return null;
            }
        }

        // --- GET BY ID ---
        public async Task<EventDto?> GetEventByIdAsync(uint id)
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<EventDto>($"api/Event/{id}");
            }
            catch
            {
                return null;
            }
        }

        // --- CREATE (POST) ---
        public async Task<bool> CreateEventAsync(EventDto newEvent)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("api/Event", newEvent);

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    System.Diagnostics.Debug.WriteLine($"POST Hiba StatusCode: {response.StatusCode}, Üzenet: {errorContent}");
                }

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Kivétel történt a POST során: {ex.Message}");
                return false;
            }
        }

        // --- UPDATE (PUT) ---
        public async Task<bool> UpdateEventAsync(uint id, EventDto updatedEvent)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync($"api/Event/{id}", updatedEvent);
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }

        // --- DELETE ---
        public async Task<bool> DeleteEventAsync(uint eventId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"api/Event/{eventId}");
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}