﻿using System;

namespace Scene.AdminUI.Models
{
    public class EventDto
    {
        public uint EventId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Category { get; set; } = string.Empty;
        public uint MaxCapacity { get; set; }
        public uint CurrentBookingsCount { get; set; }
        
        public string ImageUrl { get; set; } = string.Empty;
    }
}