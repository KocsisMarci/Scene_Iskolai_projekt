﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Scene.AdminUI.Services;

namespace Scene.AdminUI.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        private readonly ApiService _apiService;

        private string _username = string.Empty;
        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        private string _errorMessage = string.Empty;
        public string ErrorMessage
        {
            get => _errorMessage;
            set { _errorMessage = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }

        public LoginViewModel()
        {
            _apiService = new ApiService();
            LoginCommand = new RelayCommand(async obj => await ExecuteLogin(obj));
        }

        private async Task ExecuteLogin(object? parameter)
        {
            ErrorMessage = string.Empty;

            var passwordBox = parameter as PasswordBox;
            string password = passwordBox?.Password ?? string.Empty;

            // Kliens oldali ellenőrzés (ÁCSI!)
            if (string.IsNullOrWhiteSpace(Username) && string.IsNullOrWhiteSpace(password))
            {
                ErrorMessage = "Ácsi! A felhasználónév és a jelszó sem lehet üres!";
                return;
            }

            if (string.IsNullOrWhiteSpace(Username))
            {
                ErrorMessage = "Ácsi! Kérjük, add meg a felhasználónevet!";
                return;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                ErrorMessage = "Ácsi! Kérjük, add meg a jelszót!";
                return;
            }

            ErrorMessage = "Bejelentkezés folyamatban...";

            bool isSuccess = await _apiService.LoginAsync(Username, password);

            if (isSuccess)
            {
                MainWindow mainWindow = new MainWindow();

                if (mainWindow.DataContext is MainViewModel mainViewModel)
                {
                    await mainViewModel.InitializeAsync(_apiService);
                }

                mainWindow.Show();

                // LoginWindow bezárása
                foreach (Window window in Application.Current.Windows)
                {
                    if (window is Views.LoginWindow)
                    {
                        window.Close();
                        break;
                    }
                }
            }
            else
            {
                ErrorMessage = "Ácsi! Hibás felhasználónév vagy jelszó (vagy el se érhető az API)!";
            }
        }
    }
}