﻿using Scene.AdminUI.Models;
using Scene.AdminUI.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Scene.AdminUI.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private  ApiService _apiService;

        public ObservableCollection<EventDto> Events { get; set; } = new();
        public ObservableCollection<string> SearchFields { get; set; } = new() { "Név", "ID", "Kategória", "Helyszín" };

        private EventDto? _selectedEvent;
        public EventDto? SelectedEvent
        {
            get => _selectedEvent;
            set
            {
                _selectedEvent = value;
                OnPropertyChanged();
                if (value != null)
                {
                    // Kiválasztáskor áttöltjük az adatokat a szerkesztőbe
                    EditableEvent = new EventDto
                    {
                        EventId = value.EventId,
                        Name = value.Name,
                        Location = value.Location,
                        Category = value.Category,
                        StartDate = value.StartDate,
                        CurrentBookingsCount = value.CurrentBookingsCount
                    };
                }
            }
        }

        private EventDto _editableEvent = new() { StartDate = DateTime.Now };
        public EventDto EditableEvent
        {
            get => _editableEvent;
            set { _editableEvent = value; OnPropertyChanged(); }
        }

        public string SelectedSearchField { get; set; } = "Név";
        public string SearchText { get; set; } = "";

        private string _statusMessage = "Kész";
        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        // Parancsok
        public ICommand LoadEventsCommand { get; }
        public ICommand DeleteSelectedEventCommand { get; }
        public ICommand SearchCommand { get; }
        public ICommand CreateEventCommand { get; }
        public ICommand UpdateEventCommand { get; }
        public ICommand ClearEditorCommand { get; }


        public MainViewModel()
        {
            _apiService = new ApiService();

            LoadEventsCommand = new RelayCommand(async obj => await LoadEvents());
            DeleteSelectedEventCommand = new RelayCommand(async obj => await DeleteSelected(), obj => SelectedEvent != null);
            SearchCommand = new RelayCommand(async obj => await PerformSearch());
            CreateEventCommand = new RelayCommand(async obj => await CreateEvent());
            UpdateEventCommand = new RelayCommand(async obj => await UpdateEvent(), obj => EditableEvent.EventId > 0);
            ClearEditorCommand = new RelayCommand(obj => ClearEditor());
        }

        // Ezt hívjuk meg a LoginViewModel-ből a sikeres bejelentkezés után!
        public async Task InitializeAsync(ApiService authenticatedApiService)
        {
            _apiService = authenticatedApiService;
            await LoadEvents();
        }


        private async Task LoadEvents()
        {
            StatusMessage = "Betöltés...";
            var data = await _apiService.GetEventsAsync();
            if (data != null)
            {
                Events.Clear();
                foreach (var ev in data) Events.Add(ev);
                StatusMessage = $"{Events.Count} esemény betöltve.";
            }
            else
            {
                StatusMessage = "Hiba a betöltés során!";
            }
        }

        private async Task PerformSearch()
        {
            if (string.IsNullOrWhiteSpace(SearchText))
            {
                await LoadEvents();
                return;
            }

            var all = await _apiService.GetEventsAsync();
            if (all != null)
            {
                // LIKE jellegű, Case-Insensitive (kis/nagybetű független) szűrés
                var filtered = all.Where(e =>
                {
                    var term = SearchText.Trim();
                    return SelectedSearchField switch
                    {
                        "ID" => e.EventId.ToString().Contains(term),
                        "Név" => e.Name != null && e.Name.Contains(term, StringComparison.OrdinalIgnoreCase),
                        "Kategória" => e.Category != null && e.Category.Contains(term, StringComparison.OrdinalIgnoreCase),
                        "Helyszín" => e.Location != null && e.Location.Contains(term, StringComparison.OrdinalIgnoreCase),
                        _ => false
                    };
                }).ToList();

                Events.Clear();
                foreach (var ev in filtered) Events.Add(ev);
                StatusMessage = $"{Events.Count} találat a(z) '{SearchText}' keresésre.";
            }
        }

        private async Task CreateEvent()
        {
            // Új elem esetén az EventId legyen 0
            EditableEvent.EventId = 0;
            var success = await _apiService.CreateEventAsync(EditableEvent);
            if (success)
            {
                StatusMessage = "Új esemény sikeresen hozzáadva (POST)!";
                ClearEditor();
                await LoadEvents();
            }
            else
            {
                StatusMessage = "Hiba az új esemény hozzáadásakor!";
            }
        }

        private async Task UpdateEvent()
        {
            if (EditableEvent.EventId == 0) return;

            var success = await _apiService.UpdateEventAsync(EditableEvent.EventId, EditableEvent);
            if (success)
            {
                StatusMessage = $"A(z) {EditableEvent.EventId} ID-jú esemény módosítva (PUT)!";
                ClearEditor();
                await LoadEvents();
            }
            else
            {
                StatusMessage = "Hiba a módosítás során!";
            }
        }

        private async Task DeleteSelected()
        {
            if (SelectedEvent == null) return;
            var success = await _apiService.DeleteEventAsync(SelectedEvent.EventId);
            if (success)
            {
                StatusMessage = "Esemény törölve (DELETE).";
                ClearEditor();
                await LoadEvents();
            }
            else
            {
                StatusMessage = "Hiba a törlés során!";
            }
        }

        private void ClearEditor()
        {
            EditableEvent = new EventDto { StartDate = DateTime.Now };
            SelectedEvent = null;
        }
    }
}