﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Scene.AdminUI.Models;
using Scene.AdminUI.Services;

namespace Scene.AdminUI.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private readonly ApiService _apiService;

        [ObservableProperty]
        private ObservableCollection<EventDto> _events = new();

        [ObservableProperty]
        private EventDto? _selectedEvent;

        [ObservableProperty]
        private string _statusMessage = "Kész";

        public MainViewModel()
        {
            _apiService = new ApiService();
        }

        public MainViewModel(ApiService apiService)
        {
            _apiService = apiService;
        }

        [RelayCommand]
        public async Task LoadEventsAsync()
        {
            StatusMessage = "Események betöltése...";
            var list = await _apiService.GetEventsAsync();
            if (list != null)
            {
                Events = new ObservableCollection<EventDto>(list);
                StatusMessage = $"Sikeresen betöltve: {Events.Count} esemény.";
            }
            else
            {
                StatusMessage = "Hiba az események betöltésekor!";
            }
        }

        [RelayCommand]
        public async Task DeleteSelectedEventAsync()
        {
            if (SelectedEvent == null) return;

            StatusMessage = $"Esemény törlése (ID: {SelectedEvent.EventId})...";
            bool success = await _apiService.DeleteEventAsync(SelectedEvent.EventId);

            if (success)
            {
                Events.Remove(SelectedEvent);
                StatusMessage = "Esemény sikeresen törölve!";
            }
            else
            {
                StatusMessage = "Nem sikerült törölni az eseményt!";
            }
        }
    }
}