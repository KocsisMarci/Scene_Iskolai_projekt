﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Scene.AdminUI.Models;

namespace Scene.AdminUI.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;
        private string? _jwtToken;

        public ApiService()
        {
            // Létrehozunk egy kézi tanúsítvány-ellenőrzőt a helyi fejlesztéshez
            var handler = new HttpClientHandler
            {
                ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
            };

            _httpClient = new HttpClient(handler)
            {
                // Győződj meg róla, hogy a portszám megegyezik a Swagger-ben láthatóval!
                BaseAddress = new Uri("https://localhost:7269/")
            };
        }

        public async Task<bool> LoginAsync(string username, string password)
        {
            try
            {
                var dto = new LoginRequestDto { UsernameOrEmail = username, Password = password };
                var response = await _httpClient.PostAsJsonAsync("api/auth/login", dto);

                if (!response.IsSuccessStatusCode) return false;

                var result = await response.Content.ReadFromJsonAsync<LoginResponseDto>();
                if (result == null || string.IsNullOrEmpty(result.Token)) return false;

                _jwtToken = result.Token;

                // Beállítjuk a Bearer tokent minden további HTTP kéréshez
                _httpClient.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", _jwtToken);

                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<List<EventDto>?> GetEventsAsync()
        {
            try
            {
                return await _httpClient.GetFromJsonAsync<List<EventDto>>("api/Event");
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Kivétel történt: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> DeleteEventAsync(uint eventId)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"api/events/{eventId}");
                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}